import crypto from 'node:crypto';

const baseUrl = process.env.SELFTEST_BASE_URL || 'http://127.0.0.1:8080';
const identifier = process.env.ADMIN_EMAIL || process.env.ADMIN_USERNAME;
const password = process.env.ADMIN_PASSWORD;
if (!identifier || !password) throw new Error('生产闭环测试缺少管理员环境变量');

function crc32(bytes) {
  if (!crc32.table) crc32.table = Array.from({ length: 256 }, (_, index) => {
    let value = index;
    for (let bit = 0; bit < 8; bit += 1) value = (value & 1) ? 0xedb88320 ^ (value >>> 1) : value >>> 1;
    return value >>> 0;
  });
  let value = 0xffffffff;
  for (const byte of bytes) value = crc32.table[(value ^ byte) & 0xff] ^ (value >>> 8);
  return (value ^ 0xffffffff) >>> 0;
}

function storedZip(entries) {
  const encoder = new TextEncoder(); const local = []; const central = []; let offset = 0;
  const u16 = (view, at, value) => view.setUint16(at, value, true);
  const u32 = (view, at, value) => view.setUint32(at, value >>> 0, true);
  for (const entry of entries) {
    const nameBytes = encoder.encode(entry.name); const data = entry.bytes; const checksum = crc32(data);
    const header = new Uint8Array(30 + nameBytes.length); const view = new DataView(header.buffer);
    u32(view, 0, 0x04034b50); u16(view, 4, 20); u16(view, 6, 0x800); u16(view, 8, 0);
    u32(view, 14, checksum); u32(view, 18, data.length); u32(view, 22, data.length); u16(view, 26, nameBytes.length);
    header.set(nameBytes, 30); local.push(header, data);
    const record = new Uint8Array(46 + nameBytes.length); const centralView = new DataView(record.buffer);
    u32(centralView, 0, 0x02014b50); u16(centralView, 4, 20); u16(centralView, 6, 20); u16(centralView, 8, 0x800);
    u32(centralView, 16, checksum); u32(centralView, 20, data.length); u32(centralView, 24, data.length); u16(centralView, 28, nameBytes.length);
    u32(centralView, 42, offset); record.set(nameBytes, 46); central.push(record); offset += header.length + data.length;
  }
  const centralSize = central.reduce((total, item) => total + item.length, 0); const end = new Uint8Array(22); const endView = new DataView(end.buffer);
  u32(endView, 0, 0x06054b50); u16(endView, 8, entries.length); u16(endView, 10, entries.length); u32(endView, 12, centralSize); u32(endView, 16, offset);
  return new Blob([...local, ...central, end], { type: 'application/zip' });
}

async function request(path, { token, ...init } = {}) {
  const multipart = typeof FormData !== 'undefined' && init.body instanceof FormData;
  const response = await fetch(`${baseUrl}${path}`, {
    ...init,
    headers: {
      ...(multipart ? {} : init.body === undefined ? {} : { 'content-type': 'application/json' }),
      ...(token ? { authorization: `Bearer ${token}` } : {}),
      ...(init.headers || {})
    }
  });
  const text = await response.text();
  let body; try { body = text ? JSON.parse(text) : {}; } catch { body = { error: text }; }
  if (!response.ok) throw new Error(`${init.method || 'GET'} ${path} -> ${response.status}: ${body.error || text}`);
  return body;
}

const login = await request('/api/auth/login', {
  method: 'POST', body: JSON.stringify({ identifier, password })
});
const token = login.token;
const suffix = `${Date.now().toString(36)}-${crypto.randomBytes(3).toString('hex')}`;
let skill; let agent;

async function exists(type, id) {
  if (!id) return false;
  try { await request(`/api/admin/${type}/${id}`, { token }); return true; } catch { return false; }
}

async function destroy(type, product) {
  if (!product?.id || !(await exists(type, product.id))) return;
  await request(`/api/admin/${type}/${product.id}/permanent?confirm=${encodeURIComponent(product.slug)}`, { token, method: 'DELETE' });
}

try {
  const invalidZip = new FormData();
  invalidZip.append('package', storedZip([
    { name: 'manifest.json', bytes: new TextEncoder().encode('{"type":"skill"}\\n') },
    { name: 'SKILL.md', bytes: new TextEncoder().encode('# invalid manifest regression') }
  ]), 'invalid-manifest.zip');
  const invalidResponse = await fetch(`${baseUrl}/api/admin/skills/upload`, {
    method: 'POST', headers: { authorization: `Bearer ${token}` }, body: invalidZip
  });
  if (invalidResponse.status !== 400) throw new Error(`非法 ZIP 应返回 400，实际为 ${invalidResponse.status}`);
  await request('/health');

  const upload = new FormData();
  upload.append('publishMode', 'published');
  upload.append('skillName', '生命周期闭环测试技能');
  upload.append('skillSlug', `lifecycle-skill-${suffix}`);
  upload.append('skillCategory', '自动验收');
  upload.append('skillVersion', '1.0.0');
  upload.append('skillSummary', '验证文件上传、上架、下架和删除');
  upload.append('skillDescription', '该记录由生产部署自检创建并自动清理');
  upload.append('skillChangelog', '生产闭环测试');
  upload.append('package', storedZip([
    { name: 'manifest.json', bytes: new TextEncoder().encode(JSON.stringify({ type: 'skill', slug: 'must-be-overridden', name: '包内旧名称', version: '0.0.1' })) },
    { name: 'SKILL.md', bytes: new TextEncoder().encode('# 生命周期闭环测试技能\n\n所有结论必须可以核验。') },
    { name: 'references/checklist.txt', bytes: new TextEncoder().encode('生产文件夹上传辅助文件') }
  ]), 'skill-folder.zip');
  const uploaded = await request('/api/admin/skills/upload', { token, method: 'POST', body: upload });
  skill = uploaded.product;
  if (skill.status !== 'published' || skill.name !== '生命周期闭环测试技能' || skill.slug !== `lifecycle-skill-${suffix}`) {
    throw new Error('技能上传覆盖字段或直接上架未真实写入');
  }
  if (!(await request('/api/marketplace/skills')).items.some((item) => item.id === skill.id)) throw new Error('技能上架后公共目录不可见');

  agent = await request('/api/admin/agents', { token, method: 'POST', body: JSON.stringify({
    slug: `lifecycle-agent-${suffix}`, name: '生命周期闭环测试智能体', category: '自动验收',
    role: '生产生命周期与数据一致性验证员', summary: '验证一句话简介真实同步', description: '该记录由生产部署自检创建并自动清理',
    icon: 'bot', avatar: '', version: '1.0.0', status: 'published',
    systemPrompt: '你是生产生命周期验证员，只报告真实可核验的数据。', welcomeMessage: '开始验证',
    workspace: { goal: '验证完整发布链路', roleRules: '不得虚构', outputDirectory: 'outputs', memoryEnabled: true, allowWeb: false, allowFiles: true, allowTerminal: false },
    skillIds: [skill.id], changelog: '生产闭环测试'
  }) });
  const agentPublic = (await request('/api/marketplace/agents')).items.find((item) => item.id === agent.id);
  if (!agentPublic) throw new Error('智能体上架后公共目录不可见');
  const agentVersion = await request(`/api/marketplace/agents/${agent.id}/versions/${agentPublic.latestVersion.version}`);
  if (agentVersion.manifest.role !== '生产生命周期与数据一致性验证员' || agentVersion.manifest.summary !== '验证一句话简介真实同步') {
    throw new Error('智能体角色或一句话简介未进入公共 manifest');
  }

  const down = await request(`/api/admin/skills/${skill.id}/unpublish`, { token, method: 'POST' });
  if (down.status !== 'unpublished') throw new Error('技能下架状态未写入');
  if ((await request('/api/marketplace/skills')).items.some((item) => item.id === skill.id)) throw new Error('技能下架后仍在公共目录');
  const agentAfterDown = await request(`/api/admin/agents/${agent.id}`, { token });
  if (agentAfterDown.status !== 'published') throw new Error('技能下架错误级联修改了智能体');

  await request(`/api/admin/skills/${skill.id}/publish`, { token, method: 'POST' });
  const deletedSkill = await request(`/api/admin/skills/${skill.id}/permanent?confirm=${encodeURIComponent(skill.slug)}`, { token, method: 'DELETE' });
  if (!deletedSkill.permanentlyDeleted || !deletedSkill.affectedAgents.includes(agent.id)) throw new Error('技能真实删除或依赖解绑失败');
  skill = null;
  const agentAfterDelete = await request(`/api/admin/agents/${agent.id}`, { token });
  if (agentAfterDelete.status !== 'published' || agentAfterDelete.skillIds.length !== 0 || agentAfterDelete.latestVersion.manifest.skills.length !== 0) {
    throw new Error('技能删除后智能体状态或 manifest 不一致');
  }

  await destroy('agents', agent); agent = null;
  console.log('PRODUCTION_MARKETPLACE_E2E_OK role summary folder-upload publish unpublish direct-delete dependency-detach invalid-zip-survives');
} finally {
  await destroy('skills', skill).catch(() => {});
  await destroy('agents', agent).catch(() => {});
}
