export default async function healthRoutes(app) {
  app.get('/health', async () => ({ ok: true, service: 'shanman-api', version: '0.2.10', time: new Date().toISOString() }));
}
