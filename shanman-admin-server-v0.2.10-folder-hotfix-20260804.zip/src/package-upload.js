import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { TextDecoder } from 'node:util';
import yauzl from 'yauzl';
import { canonicalJson, sha256, validateProductDraft, validateVersionDraft } from './marketplace-utils.js';

export const MAX_PACKAGE_BYTES = 10 * 1024 * 1024;
const MAX_EXTRACTED_BYTES = 20 * 1024 * 1024;
const MAX_TEXT_BYTES = 1024 * 1024;
const MAX_ZIP_ENTRIES = 200;
const SAFE_FILE_EXTENSIONS = new Set(['.json', '.md', '.txt', '.png', '.jpg', '.jpeg', '.webp', '.gif', '.ico']);
const EXECUTABLE_EXTENSIONS = new Set([
  '.exe', '.dll', '.com', '.msi', '.msp', '.scr', '.cpl', '.sys', '.app', '.dmg', '.pkg', '.deb', '.rpm', '.so', '.dylib',
  '.bat', '.cmd', '.ps1', '.psm1', '.sh', '.bash', '.zsh', '.fish', '.js', '.mjs', '.cjs', '.ts', '.py', '.pyc', '.jar', '.class',
  '.vbs', '.vbe', '.wsf', '.wsh', '.hta', '.reg', '.lnk', '.url', '.scf', '.apk', '.ipa', '.docm', '.xlsm', '.pptm'
]);
const utf8 = new TextDecoder('utf-8', { fatal: true });

function httpError(message, statusCode = 400) {
  return Object.assign(new TypeError(message), { statusCode });
}

function decodeText(buffer, label) {
  try { return utf8.decode(buffer).replace(/^\uFEFF/, ''); }
  catch { throw httpError(`${label} 必须使用 UTF-8 编码`); }
}

function assertSafeJson(value, depth = 0) {
  if (depth > 20) throw httpError('manifest.json 嵌套层级过深');
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return;
  if (typeof value === 'number' && Number.isFinite(value)) return;
  if (Array.isArray(value)) return value.forEach((item) => assertSafeJson(item, depth + 1));
  if (!value || typeof value !== 'object') throw httpError('manifest.json 含有不支持的数据类型');
  for (const [key, item] of Object.entries(value)) {
    if (['__proto__', 'prototype', 'constructor'].includes(key)) throw httpError('manifest.json 含有危险字段');
    assertSafeJson(item, depth + 1);
  }
}

function parseJson(buffer, label) {
  let value;
  try { value = JSON.parse(decodeText(buffer, label)); }
  catch (error) { if (error.statusCode) throw error; throw httpError(`${label} 不是有效 JSON`); }
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw httpError(`${label} 必须是 JSON 对象`);
  assertSafeJson(value);
  return value;
}

export function validateArchivePath(fileName) {
  const name = String(fileName || '');
  if (!name || name.includes('\0') || name.includes('\\') || name.startsWith('/') || /^[A-Za-z]:/.test(name)) {
    throw httpError('ZIP 包含非法或绝对路径');
  }
  const withoutSlash = name.endsWith('/') ? name.slice(0, -1) : name;
  const segments = withoutSlash.split('/');
  if (!withoutSlash || segments.some((segment) => !segment || segment === '.' || segment === '..')) throw httpError('ZIP 包含路径穿越');
  if (path.posix.normalize(withoutSlash) !== withoutSlash) throw httpError('ZIP 包含非规范路径');
  return name;
}

function validateArchiveFile(entry) {
  const fileName = validateArchivePath(entry.fileName);
  if (fileName.endsWith('/')) return;
  const mode = (entry.externalFileAttributes >>> 16) & 0xffff;
  if ((mode & 0o170000) === 0o120000) throw httpError('ZIP 不允许符号链接');
  if ((entry.generalPurposeBitFlag & 0x1) !== 0) throw httpError('ZIP 不允许加密文件');
  const extension = path.posix.extname(fileName).toLowerCase();
  if (EXECUTABLE_EXTENSIONS.has(extension)) throw httpError(`ZIP 不允许可执行文件：${fileName}`);
  if (!SAFE_FILE_EXTENSIONS.has(extension)) throw httpError(`ZIP 文件类型不受支持：${fileName}`);
  if (entry.uncompressedSize > MAX_PACKAGE_BYTES) throw httpError(`ZIP 单个文件过大：${fileName}`, 413);
  if (entry.uncompressedSize > 1024 * 1024 && entry.compressedSize > 0 && entry.uncompressedSize / entry.compressedSize > 200) {
    throw httpError(`ZIP 文件压缩比异常：${fileName}`);
  }
}

function openZip(buffer) {
  return new Promise((resolve, reject) => {
    yauzl.fromBuffer(buffer, { lazyEntries: true, decodeStrings: true, strictFileNames: true, validateEntrySizes: true }, (error, zip) => {
      if (error) reject(httpError(`ZIP 无法解析：${error.message}`)); else resolve(zip);
    });
  });
}

function readZipEntry(zip, entry, limit = MAX_TEXT_BYTES) {
  return new Promise((resolve, reject) => {
    zip.openReadStream(entry, (error, stream) => {
      if (error) return reject(httpError(`ZIP 文件读取失败：${error.message}`));
      const chunks = []; let size = 0;
      stream.on('data', (chunk) => {
        size += chunk.length;
        if (size > limit) stream.destroy(httpError('manifest 或说明文件不能超过 1MB', 413));
        else chunks.push(chunk);
      });
      stream.once('error', reject);
      stream.once('end', () => resolve(Buffer.concat(chunks)));
    });
  });
}

async function extractZipMetadata(buffer, type) {
  const zip = await openZip(buffer);
  const requiredContent = type === 'agents' ? 'system-prompt.md' : 'skill.md';
  const found = new Map(); let entryCount = 0; let extractedSize = 0;
  return new Promise((resolve, reject) => {
    let finished = false;
    const fail = (error) => {
      if (finished) return;
      finished = true;
      try { zip.close(); } catch {}
      reject(error.statusCode ? error : httpError(`ZIP 无法解析：${error.message}`));
    };
    zip.once('error', fail);
    zip.once('end', () => {
      if (finished) return;
      try {
        const manifestBuffer = found.get('manifest.json'); const contentBuffer = found.get(requiredContent);
        if (!manifestBuffer) throw httpError('ZIP 根目录或单一子目录中缺少 manifest.json');
        if (!contentBuffer) throw httpError(`ZIP 中缺少 ${type === 'agents' ? 'system-prompt.md' : 'SKILL.md'}`);
        const result = { manifest: parseJson(manifestBuffer, 'manifest.json'), content: decodeText(contentBuffer, requiredContent) };
        finished = true;
        resolve(result);
      } catch (error) { fail(error); }
    });
    zip.on('entry', (entry) => {
      void (async () => {
        entryCount += 1;
        if (entryCount > MAX_ZIP_ENTRIES) throw httpError('ZIP 文件数量不能超过 200', 413);
        validateArchiveFile(entry);
        if (!entry.fileName.endsWith('/')) extractedSize += entry.uncompressedSize;
        if (extractedSize > MAX_EXTRACTED_BYTES) throw httpError('ZIP 解压后总大小不能超过 20MB', 413);
        const baseName = path.posix.basename(entry.fileName).toLowerCase();
        if (baseName === 'manifest.json' || baseName === requiredContent) {
          if (found.has(baseName)) throw httpError(`ZIP 中存在重复文件：${baseName}`);
          found.set(baseName, await readZipEntry(zip, entry));
        }
        zip.readEntry();
      })().catch(fail);
    });
    zip.readEntry();
  });
}

function validateContent(content, type) {
  const value = String(content ?? '').replace(/^\uFEFF/, '').trim();
  const label = type === 'agents' ? 'system-prompt.md' : 'SKILL.md';
  if (!value) throw httpError(`${label} 不能为空`);
  if (value.includes('\0')) throw httpError(`${label} 含有非法字符`);
  if (Buffer.byteLength(value, 'utf8') > MAX_TEXT_BYTES) throw httpError(`${label} 不能超过 1MB`, 413);
  return value;
}

function normalizePackage(type, format, originalBuffer, manifest, content) {
  if (type !== 'agents' && type !== 'skills') throw httpError('上传类型无效');
  const declaredType = String(manifest.type || '').toLowerCase();
  if (declaredType && !new Set([type, type.slice(0, -1)]).has(declaredType)) throw httpError('manifest.json 的 type 与上传入口不一致');
  const product = validateProductDraft({
    slug: manifest.slug, name: manifest.name, summary: manifest.summary, description: manifest.description, icon: manifest.icon
  });
  const normalizedContent = validateContent(content, type);
  const version = validateVersionDraft({ version: manifest.version, manifest, changelog: manifest.changelog });
  return {
    type, format, originalBuffer, product, version, content: normalizedContent,
    contentFileName: type === 'agents' ? 'system-prompt.md' : 'SKILL.md',
    packageSha256: sha256(originalBuffer), packageSize: originalBuffer.length
  };
}

export async function parseMarketplacePackage(buffer, { type, filename = '' } = {}) {
  if (!Buffer.isBuffer(buffer) || buffer.length === 0) throw httpError('上传包不能为空');
  if (buffer.length > MAX_PACKAGE_BYTES) throw httpError('上传包不能超过 10MB', 413);
  const first = buffer.subarray(0, 4); const firstText = buffer.toString('utf8', 0, Math.min(buffer.length, 256)).replace(/^\uFEFF/, '').trimStart();
  const isZip = first[0] === 0x50 && first[1] === 0x4b && [0x03, 0x05, 0x07].includes(first[2]);
  const isJson = firstText.startsWith('{');
  if (!isZip && !isJson) throw httpError('仅支持 ZIP 或 JSON 包');
  const extension = path.extname(String(filename || '')).toLowerCase();
  if (extension && extension !== (isZip ? '.zip' : '.json')) throw httpError('文件扩展名与实际包格式不一致');
  if (isZip) {
    const extracted = await extractZipMetadata(buffer, type);
    return normalizePackage(type, 'zip', buffer, extracted.manifest, extracted.content);
  }
  const jsonPackage = parseJson(buffer, 'JSON 包');
  const manifest = jsonPackage.manifest;
  if (!manifest || typeof manifest !== 'object' || Array.isArray(manifest)) throw httpError('JSON 包缺少 manifest 对象');
  const content = type === 'agents'
    ? jsonPackage.systemPrompt ?? jsonPackage['system-prompt.md']
    : jsonPackage.skillMarkdown ?? jsonPackage['SKILL.md'];
  return normalizePackage(type, 'json', buffer, manifest, content);
}

/**
 * 管理员表单是发布数据的最终来源。此前只有文件夹/JSON 会在浏览器里重写
 * manifest，直接上传 ZIP 时填写的名称、slug 和版本全部被忽略，造成“上传了
 * 但实际上架的还是旧技能”。统一在服务端应用覆盖值后，三种上传方式语义一致。
 */
export function applySkillUploadOverrides(packageData, fields = {}) {
  if (!packageData || packageData.type !== 'skills') return packageData;
  const source = fields && typeof fields === 'object' && !Array.isArray(fields) ? fields : {};
  const has = (key) => Object.prototype.hasOwnProperty.call(source, key);
  const value = (key, fallback) => has(key) ? String(source[key] ?? '').trim() : fallback;
  const oldManifest = packageData.version.manifest || {};
  const category = value('skillCategory', String(oldManifest.category || '通用').trim() || '通用') || String(oldManifest.category || '通用').trim() || '通用';
  if (category.length > 80) throw httpError('技能分类超过长度限制');
  const product = validateProductDraft({
    slug: value('skillSlug', packageData.product.slug),
    name: value('skillName', packageData.product.name),
    summary: value('skillSummary', packageData.product.summary || ''),
    description: value('skillDescription', packageData.product.description || ''),
    icon: 'bot'
  });
  const versionName = value('skillVersion', packageData.version.version);
  const changelog = value('skillChangelog', packageData.version.changelog || '');
  const manifest = {
    ...oldManifest,
    type: 'skill', slug: product.slug, name: product.name,
    summary: product.summary, description: product.description,
    category, version: versionName, changelog
  };
  const version = validateVersionDraft({ version: versionName, manifest, changelog });
  return { ...packageData, product, version };
}

export function resolveStoragePath(storageRoot, relativePath) {
  const root = path.resolve(storageRoot); const value = String(relativePath || '').replaceAll('\\', '/');
  if (!value || value.startsWith('/') || value.split('/').some((segment) => !segment || segment === '.' || segment === '..')) throw httpError('存储路径无效');
  const absolute = path.resolve(root, ...value.split('/'));
  if (!absolute.startsWith(`${root}${path.sep}`)) throw httpError('存储路径越界');
  return absolute;
}

export async function writePackageToStorage(packageData, storageRoot) {
  const relativeDirectory = ['packages', packageData.type, packageData.product.slug, packageData.version.version, packageData.packageSha256].join('/');
  const finalDirectory = resolveStoragePath(storageRoot, relativeDirectory);
  const temporaryRelative = ['.tmp', crypto.randomUUID()].join('/');
  const temporaryDirectory = resolveStoragePath(storageRoot, temporaryRelative);
  await fs.mkdir(temporaryDirectory, { recursive: true });
  try {
    const packageFileName = `package.${packageData.format}`;
    await Promise.all([
      fs.writeFile(path.join(temporaryDirectory, packageFileName), packageData.originalBuffer, { flag: 'wx', mode: 0o600 }),
      fs.writeFile(path.join(temporaryDirectory, 'manifest.json'), `${JSON.stringify(packageData.version.manifest, null, 2)}\n`, { flag: 'wx', mode: 0o600 }),
      fs.writeFile(path.join(temporaryDirectory, packageData.contentFileName), `${packageData.content}\n`, { flag: 'wx', mode: 0o600 })
    ]);
    await fs.mkdir(path.dirname(finalDirectory), { recursive: true });
    await fs.rename(temporaryDirectory, finalDirectory);
    return {
      directory: relativeDirectory,
      packagePath: `${relativeDirectory}/${packageFileName}`,
      contentPath: `${relativeDirectory}/${packageData.contentFileName}`
    };
  } catch (error) {
    await fs.rm(temporaryDirectory, { recursive: true, force: true }).catch(() => {});
    if (error.code === 'EEXIST' || error.code === 'ENOTEMPTY') throw httpError('该版本上传包已存在', 409);
    throw error;
  }
}

export async function removeStoredDirectory(storageRoot, relativeDirectory) {
  const target = resolveStoragePath(storageRoot, relativeDirectory);
  await fs.rm(target, { recursive: true, force: true });
}

export function packageManifestJson(packageData) {
  return canonicalJson(packageData.version.manifest);
}
