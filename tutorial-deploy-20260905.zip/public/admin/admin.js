const TOKEN_KEY='shanman-admin-token';
const API_BASE_KEY='shanman-admin-api-base';
const isGitHubPages=location.hostname.endsWith('.github.io');
const configuredApiBase=String(globalThis.SHANMAN_API_BASE||'').trim();
const initialApiBase=localStorage.getItem(API_BASE_KEY)||configuredApiBase||(isGitHubPages?'':location.origin);
const state={token:sessionStorage.getItem(TOKEN_KEY)||'',user:null,page:'dashboard',apiBase:initialApiBase.replace(/\/$/,''),catalogSkills:[],tutorials:[],productFilters:{agents:'active',skills:'active'},licenseMachineFilter:'',packagePolicies:{}};
let loginCharacterScene;
const $=(selector)=>document.querySelector(selector);
const content=$('#content');
const pageMeta={dashboard:['OVERVIEW','平台概览'],agents:['AGENTS','智能体管理'],skills:['SKILLS','技能管理'],tutorials:['TUTORIALS','教程发布'],users:['USERS & LICENSES','用户与授权'],admins:['ADMINISTRATORS','管理员账号'],audit:['AUDIT & USAGE','操作与统计']};
const eventLabels={app_started:'客户端启动',agent_created:'创建智能体',agent_installed:'安装智能体',skill_enabled:'启用技能',skill_disabled:'停用技能',chat_completed:'对话成功',chat_failed:'对话失败',channel_connected:'手机通道连接',channel_failed:'手机通道失败'};
const statusLabels={draft:'草稿',published:'已上架',unpublished:'已下架',deleted:'已删除',active:'有效',disabled:'已停用',revoked:'已吊销',expired:'已过期'};
const statusHints={draft:'仅后台可见',published:'客户端市场可见',unpublished:'客户端已隐藏',deleted:'已软删除',active:'当前可使用',disabled:'无法登录后台',revoked:'已停止使用',expired:'已过有效期'};
const marketplaceCategories=Object.freeze(['通用','漫剧','设计','视频','软件','写作','运营','电商','高级']);
const legacyMarketplaceCategoryAliases=Object.freeze({研究:'软件',数据:'运营',效率:'电商'});
const advancedCategoryPasswords=new WeakMap();

function esc(value=''){return String(value).replace(/[&<>'"]/g,(char)=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[char]))}
function date(value){if(!value)return '—';const parsed=new Date(value);return Number.isFinite(parsed.getTime())?parsed.toLocaleString('zh-CN'):'—'}
function status(value){return `<span class="status ${esc(value)}"><i></i>${esc(statusLabels[value]||value||'未知')}</span>`}
function statusBlock(value){return `<div class="status-block">${status(value)}<small>${esc(statusHints[value]||'状态未知')}</small></div>`}
function empty(text){return `<div class="empty">${esc(text)}</div>`}
function notice(message,isError=false){const el=$('#notice');el.textContent=message;el.hidden=!message;el.classList.toggle('error-note',isError);if(message)setTimeout(()=>{if(el.textContent===message)el.hidden=true},5000)}
function loading(){content.innerHTML='<div class="loading">正在加载…</div>'}
function canonicalMarketplaceCategory(value='通用'){const category=String(value||'通用').trim()||'通用';return legacyMarketplaceCategoryAliases[category]||category}
function categoryOptions(current='漫剧'){const selectedCategory=canonicalMarketplaceCategory(current||'漫剧');const values=marketplaceCategories.includes(selectedCategory)?marketplaceCategories:[selectedCategory,...marketplaceCategories];return values.map(item=>`<option value="${esc(item)}"${item===selectedCategory?' selected':''}>${esc(item)}</option>`).join('')}

const skillCategoryGlyphs=Object.freeze({
 通用:'<path d="m5 19 10-10 4 4L9 23z"/><path d="m13 7 4 4"/><path d="M6 3v4M4 5h4M18 2v3M16.5 3.5h3"/>',
 漫剧:'<rect x="4" y="7" width="16" height="12" rx="2"/><path d="m5 7 3-4h4L9 7M13 7l3-4h3l1 4M8 12h8"/>',
 设计:'<path d="M12 3a9 9 0 1 0 0 18h1.2a2 2 0 0 0 0-4H12a2 2 0 0 1 0-4h4a5 5 0 0 0 5-5c0-2.8-4-5-9-5Z"/><circle cx="7.5" cy="10" r=".8"/><circle cx="10" cy="6.8" r=".8"/><circle cx="14" cy="6.5" r=".8"/>',
 视频:'<rect x="3" y="6" width="13" height="12" rx="2"/><path d="m16 10 5-3v10l-5-3z"/><path d="M7 10h5M7 14h3"/>',
 软件:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 8h18M7 6h.01M10 6h.01M8 13l-2 2 2 2M16 13l2 2-2 2M14 11l-4 8"/>',
 写作:'<path d="m12 3 7 7-8.5 8.5-5 1 1-5Z"/><path d="m13.5 8.5-7 7M5.5 19.5l3-3"/>',
 运营:'<path d="M4 20h16"/><path d="M6 20v-7h3v7M11 20V8h3v12M16 20V4h3v16"/>',
 电商:'<circle cx="9" cy="20" r="1"/><circle cx="18" cy="20" r="1"/><path d="M3 4h2l2.4 10.2a2 2 0 0 0 2 1.5h7.8a2 2 0 0 0 1.9-1.4L21 8H7"/>',
 高级:'<path d="m9 8-4 4 4 4M15 8l4 4-4 4M13 5l-2 14"/>'
});
const skillCategoryTones=Object.freeze({通用:'general',漫剧:'story',设计:'design',视频:'video',软件:'research',写作:'writing',运营:'data',电商:'productivity',高级:'advanced'});
const skillCategoryAccents=Object.freeze({通用:'sky',漫剧:'rose',设计:'cyan',视频:'indigo',软件:'lilac',写作:'coral',运营:'plum',电商:'amber',高级:'slate'});
function skillCategoryKey(value){const category=canonicalMarketplaceCategory(value);if(marketplaceCategories.includes(category))return category;if(/漫剧|漫画|剧本|故事/.test(category))return '漫剧';if(/设计|视觉|插画/.test(category))return '设计';if(/视频|影像|动画/.test(category))return '视频';if(/软件|研究|知识|搜索|文献/.test(category))return '软件';if(/写作|文案|内容|自媒体/.test(category))return '写作';if(/运营|数据|分析|表格|图表/.test(category))return '运营';if(/电商|效率|办公|协作|管理|运维|自动化/.test(category))return '电商';if(/高级|开发|代码/.test(category))return '高级';return '通用'}
function skillCategoryMark(value){const category=skillCategoryKey(value);const accent=skillCategoryAccents[category];return `<span class="skill-category-mark skill-category-${skillCategoryTones[category]} skill-accent-${accent}" data-skill-category="${esc(category)}" data-skill-accent="${accent}" aria-hidden="true"><span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round">${skillCategoryGlyphs[category]}</svg></span></span>`}

function requestAdvancedCategoryPassword(){
 return new Promise((resolve)=>{
  const modal=document.createElement('dialog');modal.className='advanced-password-modal';modal.setAttribute('data-advanced-password-dialog','');modal.setAttribute('aria-labelledby','advancedPasswordTitle');modal.innerHTML=`<form method="dialog" class="advanced-password-card" data-advanced-password-form><header><span class="advanced-lock-mark" aria-hidden="true">◆</span><div><p class="eyebrow">RESTRICTED CATEGORY</p><h2 id="advancedPasswordTitle">验证高级分类密码</h2><p>只有通过验证后才能将资源归入“高级”，密码不会保存在浏览器。</p></div></header><label class="field">高级分类密码<input name="password" type="password" maxlength="128" autocomplete="off" spellcheck="false" required placeholder="请输入密码"></label><p class="advanced-password-error" role="alert" aria-live="polite"></p><div class="dialog-actions"><button class="secondary" type="button" data-advanced-cancel>取消</button><button class="primary" type="submit" value="verify">验证并选择</button></div></form>`;
  document.body.append(modal);const form=modal.querySelector('form');const input=form.elements.password;const error=modal.querySelector('.advanced-password-error');let settled=false;
  const finish=(password='')=>{if(settled)return;settled=true;if(modal.open)modal.close();modal.remove();resolve(password)};
  modal.addEventListener('cancel',(event)=>{event.preventDefault();finish()});modal.addEventListener('click',(event)=>{if(event.target===modal)finish()});modal.querySelector('[data-advanced-cancel]').addEventListener('click',()=>finish());
  form.addEventListener('submit',async(event)=>{event.preventDefault();const password=String(input.value||'');const submit=form.querySelector('button[type="submit"]');error.textContent='';submit.disabled=true;submit.textContent='正在验证…';try{await api('/api/admin/advanced-category/verify',{method:'POST',body:JSON.stringify({password})});finish(password)}catch(reason){error.textContent=reason.message||'密码验证失败';input.select()}finally{if(modal.isConnected){submit.disabled=false;submit.textContent='验证并选择'}}});
  modal.showModal();requestAnimationFrame(()=>input.focus());
 });
}

function bindAdvancedCategoryPassword(form,categoryField){
 const category=form?.elements?.[categoryField];if(!category)return;let previousCategory=category.value==='高级'?'漫剧':category.value;
 category.addEventListener('change',async()=>{const nextCategory=category.value;if(nextCategory!=='高级'){advancedCategoryPasswords.delete(form);previousCategory=nextCategory;return}category.disabled=true;const password=await requestAdvancedCategoryPassword();if(password){advancedCategoryPasswords.set(form,password);previousCategory='高级'}else{advancedCategoryPasswords.delete(form);category.value=previousCategory==='高级'?'漫剧':previousCategory}category.disabled=false;category.focus()});
}

async function advancedCategoryPasswordForSubmission(form,categoryField){
 const category=form?.elements?.[categoryField];if(!category||category.value!=='高级')return '';
 const verified=advancedCategoryPasswords.get(form);if(verified)return verified;
 const password=await requestAdvancedCategoryPassword();if(!password){category.value='漫剧';throw new Error('已取消高级分类，请选择其他分类')};advancedCategoryPasswords.set(form,password);return password;
}

async function api(path,options={}){
 if(!state.apiBase)throw new Error('后台 API 尚未配置。GitHub Pages 只负责显示界面，请先填写 HTTPS 后台地址。');
 const hasBody=options.body!==undefined&&options.body!==null;
 const isFormData=hasBody&&options.body instanceof FormData;
 const headers={...(hasBody&&!isFormData?{'content-type':'application/json'}:{}),...(state.token?{authorization:`Bearer ${state.token}`}:{}) ,...(options.headers||{})};
 const response=await fetch(`${state.apiBase}${path}`,{cache:'no-store',...options,headers});
 const text=await response.text();let data={};try{data=text?JSON.parse(text):{}}catch{data={error:text}}
 if(response.status===401&&state.token){logout();throw new Error('登录已过期，请重新登录')}
 if(!response.ok)throw new Error(data.message||data.error||`请求失败（${response.status}）`);
 return data;
}

async function apiAllPages(path){
 const items=[];let cursor='';
 for(let page=0;page<100;page+=1){
  const separator=path.includes('?')?'&':'?';
  const query=`${path}${separator}limit=200${cursor?`&cursor=${encodeURIComponent(cursor)}`:''}`;
  const result=await api(query);items.push(...(result.items||[]));
  if(!result.nextCursor)return {...result,items};
  if(result.nextCursor===cursor)throw new Error('服务器分页游标未前进');
  cursor=result.nextCursor;
 }
 throw new Error('记录数量过多，分页读取超过安全上限');
}

function showLogin(message=''){$('#appView').hidden=true;$('#loginView').hidden=false;$('#loginError').textContent=message;loginCharacterScene?.start()}
function showApp(){loginCharacterScene?.stop();$('#loginView').hidden=true;$('#appView').hidden=false;$('#adminIdentity').textContent=state.user?.username||state.user?.email||'管理员';void navigate(state.page)}
function logout(){state.token='';state.user=null;sessionStorage.removeItem(TOKEN_KEY);showLogin()}

async function navigate(page){
 if(state.page==='tutorials'&&window.TutorialPublisher&&!window.TutorialPublisher.canLeave())return;
 if(state.page==='tutorials'&&window.TutorialPublisher)window.TutorialPublisher.dispose();
 document.body.dataset.adminPage=page;content.classList.remove('tutorial-publisher');content.onclick=null;content.oninput=null;content.onchange=null;content.onsubmit=null;content.ondragover=null;content.ondragleave=null;content.ondrop=null;content.onpaste=null;
 state.page=page;const meta=pageMeta[page]||pageMeta.dashboard;$('#pageEyebrow').textContent=meta[0];$('#pageTitle').textContent=meta[1];
 document.querySelectorAll('#navigation button').forEach((button)=>button.classList.toggle('active',button.dataset.page===page));
 $('.sidebar').classList.remove('open');loading();
 try{if(page==='dashboard')await renderDashboard();else if(page==='agents'||page==='skills')await renderProducts(page);else if(page==='tutorials')await renderTutorials();else if(page==='users')await renderUsers();else if(page==='admins')await renderAdmins();else await renderAudit()}catch(error){content.innerHTML=empty(error.message);notice(error.message,true)}
}

async function renderDashboard(){
 const [data,usage,audit]=await Promise.all([api('/api/admin/dashboard'),api('/api/admin/telemetry?days=30'),api('/api/admin/audit?limit=7')]);
 const max=Math.max(1,...usage.byEvent.map((item)=>item.count));
 content.innerHTML=`<section class="dashboard-hero"><div><span class="eyebrow">CONTROL CENTER</span><h2>欢迎回来，${esc(state.user?.username||'管理员')}</h2><p>在一个页面掌握内容上架、客户使用和服务运行情况。</p></div><div class="server-health"><i></i><span><strong>服务运行正常</strong><small>市场 API 已连接</small></span></div><div class="hero-actions"><button class="primary" data-action="dashboard-nav" data-page="agents">新建智能体</button><button class="secondary" data-action="dashboard-nav" data-page="skills">管理技能</button></div></section>
 <div class="stats dashboard-stats">
  ${statCard('注册用户',data.users,'累计平台注册','users')}${statCard('上架智能体',data.agents.published,`共 ${data.agents.total} 个管理中`,'agents')}${statCard('上架技能',data.skills.published,`共 ${data.skills.total} 个管理中`,'skills')}
  ${statCard('有效授权',data.activeLicenses,'当前可验证','licenses')}${statCard('24 小时事件',data.events24h,'客户端活动','events')}${statCard('30 天活跃端',data.installations30d,'去重安装量','devices')}
 </div>
 <div class="overview-grid"><section class="panel publication-panel"><div class="panel-head"><div><h2>内容发布概况</h2><p>状态变化会决定客户应用市场是否可见</p></div><span class="live-badge"><i></i>实时数据</span></div>
 ${publicationRow('智能体',data.agents,'agents')}${publicationRow('技能',data.skills,'skills')}
 <div class="sync-note"><span>↻</span><div><strong>客户端同步规则</strong><p>已上架内容会在客户打开或刷新市场时同步；草稿、下架和删除内容不会出现在市场。</p></div></div></section>
 <section class="panel activity-panel"><div class="panel-head"><div><h2>最近操作</h2><p>管理员最新变更记录</p></div><button class="text-action" data-action="dashboard-nav" data-page="audit">查看全部</button></div>${recentActivity(audit.items)}</section></div>
 <div class="overview-grid lower"><section class="panel"><div class="panel-head"><div><h2>近 30 天使用情况</h2><p>匿名聚合事件，不保存聊天正文或密钥</p></div></div>
 <div class="event-bars">${usage.byEvent.length?usage.byEvent.map((item)=>`<div class="event-row"><span>${esc(eventLabels[item.name]||item.name)}</span><div class="bar"><i style="width:${Math.max(3,item.count/max*100)}%"></i></div><strong>${item.count}</strong></div>`).join(''):empty('还没有客户端统计')}</div></section>
 <section class="panel quick-guide"><div class="panel-head"><div><h2>推荐发布流程</h2><p>避免未检查内容直接进入客户市场</p></div></div><ol><li><b>1</b><span><strong>创建为草稿</strong><small>补齐头像、介绍、提示词和技能</small></span></li><li><b>2</b><span><strong>本机检查测试</strong><small>确认角色行为和技能可用</small></span></li><li><b>3</b><span><strong>确认后上架</strong><small>客户刷新市场即可获取</small></span></li></ol></section></div>`;
}
function statCard(label,value,tip='',tone=''){return `<article class="stat ${esc(tone)}"><span class="stat-icon"></span><div><small>${esc(label)}</small><strong>${esc(value)}</strong>${tip?`<small>${esc(tip)}</small>`:''}</div></article>`}
function publicationRow(label,data,page){const total=Math.max(1,Number(data.total||0)+Number(data.deleted||0));const segment=(key)=>Math.max(0,Number(data[key]||0)/total*100);return `<div class="publication-row"><div class="publication-title"><strong>${esc(label)}</strong><button class="text-action" data-action="dashboard-nav" data-page="${page}">进入管理 →</button></div><div class="publication-counts"><span class="published"><b>${data.published||0}</b> 已上架</span><span class="draft"><b>${data.draft||0}</b> 草稿</span><span class="unpublished"><b>${data.unpublished||0}</b> 已下架</span><span class="deleted"><b>${data.deleted||0}</b> 已删除</span></div><div class="status-track"><i class="published" style="width:${segment('published')}%"></i><i class="draft" style="width:${segment('draft')}%"></i><i class="unpublished" style="width:${segment('unpublished')}%"></i><i class="deleted" style="width:${segment('deleted')}%"></i></div></div>`}
function recentActivity(items){if(!items?.length)return empty('还没有操作记录');return `<div class="activity-list">${items.map((item)=>`<div class="activity-item"><span class="activity-dot"></span><div><strong>${esc(actionLabel(item.action))}</strong><small>${esc(item.entity_type||'系统')} · ${date(item.created_at)}</small></div></div>`).join('')}</div>`}
function actionLabel(value=''){const action=String(value);if(action.includes('publish')&&!action.includes('unpublish'))return '内容已上架';if(action.includes('unpublish'))return '内容已下架';if(action.includes('delete'))return '内容已删除';if(action.includes('avatar'))return '上传智能体头像';if(action.includes('upload'))return '上传资源包';if(action.includes('create'))return '创建新资源';if(action.includes('update'))return '更新资源配置';return action||'后台操作'}

async function renderProducts(type){
  const label=type==='agents'?'智能体':'技能';
  const [data,skills]=type==='agents'?await Promise.all([api('/api/admin/agents'),api('/api/admin/skills')]):[await api('/api/admin/skills'),null];
  if(skills)state.catalogSkills=skills.items.filter((item)=>item.status!=='deleted');
  const filter=state.productFilters[type]||'active';const counts=countStatuses(data.items);const visible=data.items.filter((item)=>filter==='active'?item.status!=='deleted':item.status===filter);
  const builder=type==='agents'?`<section class="panel agent-builder-hero"><div><span class="eyebrow">AGENT BUILDER</span><h2>直接在网页制作智能体</h2><p>用更清晰的四步完成头像、角色、工作区和专属技能配置。</p><div class="builder-points"><span>真实头像</span><span>角色提示词</span><span>独立工作区</span><span>专属技能</span></div></div><button class="primary builder-create" type="button" data-action="create-agent">+  新建智能体</button></section>`:'';
  const sourceNote=type==='skills'?`<section class="panel cloud-scope-note"><strong>这里管理的是云端技能</strong><p>客户端随安装包提供的平台内置技能不会出现在本表，也不会被后台上下架。即使名称相同，云端技能仍以独立产品 ID 安装和停用。</p></section>`:'';
  content.innerHTML=`${builder}${uploadPanel(type)}${sourceNote}
  <section class="panel product-panel"><div class="panel-head"><div><h2>${label}列表</h2><p>状态与客户可见性已明确标注，删除项单独归档</p></div><div class="catalog-total"><strong>${data.items.length}</strong><small>全部${label}</small></div></div>${productSummary(counts)}${productFilters(type,filter,counts)}${productTable(visible,type)}</section>`;
  bindUploadForm($('#uploadForm'));
 }

function uploadPanel(type){
  if(type==='agents')return `<section class="panel skill-upload-panel"><div class="panel-head"><div><h2>上传现有智能体</h2><p>可以直接选择智能体文件夹，也可以上传 JSON / ZIP。文件夹需包含 <b>manifest.json</b> 和 <b>system-prompt.md</b>；默认支持 256MB 压缩包、10000 个目录项，超出时会明确提示。</p></div><span class="upload-limit">默认上限 256MB</span></div><form id="uploadForm" class="skill-upload-form agent-package-upload" data-type="agents"><div class="skill-source-grid"><label class="skill-source-card folder-source"><span class="source-icon">⌁</span><span><strong>选择智能体文件夹</strong><small>自动保留工作区中的全部普通文件</small></span><input id="agentFolder" name="folder" type="file" webkitdirectory directory multiple></label><label class="skill-source-card package-source"><span class="source-icon">⇧</span><span><strong>选择 JSON / ZIP 包</strong><small>已有标准安装包可直接上传</small></span><input name="package" type="file" accept=".json,.zip,application/json,application/zip"></label></div><p id="agentFolderMeta" class="skill-folder-meta">尚未选择文件夹。文件夹中的路径结构和辅助文件会原样打包。</p><div class="skill-upload-footer"><span></span><button class="primary skill-upload-submit" type="submit">上传智能体</button></div></form></section>`;
  return `<section class="panel skill-upload-panel"><div class="panel-head"><div><h2>上传技能</h2><p>可以直接选择技能文件夹，也可以继续上传 JSON / ZIP。文件夹至少要包含 <b>SKILL.md</b>，脚本和其他普通文件会一并打包保存；默认支持 256MB 压缩包、10000 个目录项，超出时会明确提示。</p></div><span class="upload-limit">默认上限 256MB</span></div>
  <form id="uploadForm" class="skill-upload-form" data-type="skills">
   <div class="skill-upload-fields"><label class="field"><span>技能名称 <b>*</b></span><input name="skillName" maxlength="120" required placeholder="例如：小红书内容策划"><small>支持中文或英文名称</small></label><label class="field"><span>技能标识 <b>*</b></span><input name="skillSlug" maxlength="64" required placeholder="例如：小红书-内容策划"><small>支持中文、英文字母、数字和连字符</small></label><label class="field"><span>分类 <b>*</b></span><select class="select" name="skillCategory" required>${categoryOptions('漫剧')}</select></label><label class="field"><span>版本 <b>*</b></span><input name="skillVersion" value="1.0.0" pattern="\\d+\\.\\d+\\.\\d+" required placeholder="1.0.0"></label><label class="field span-2"><span>卡片摘要</span><input name="skillSummary" maxlength="500" placeholder="告诉客户这个技能适合解决什么问题"><small>客户端技能卡片只显示这里，不会再被详情内容覆盖</small></label><label class="field span-2"><span>详情介绍</span><textarea name="skillDescription" rows="2" maxlength="50000" placeholder="可选，客户端技能详情页展示"></textarea><small>用于技能详情页的适用场景说明，不替代卡片摘要</small></label><label class="field span-2"><span>更新说明</span><input name="skillChangelog" maxlength="20000" placeholder="例如：首次发布"></label></div>
   <div class="skill-source-grid"><label class="skill-source-card folder-source"><span class="source-icon">⌁</span><span><strong>选择技能文件夹</strong><small>推荐：自动读取 SKILL.md 和 manifest.json</small></span><input id="skillFolder" name="folder" type="file" webkitdirectory directory multiple></label><label class="skill-source-card package-source"><span class="source-icon">⇧</span><span><strong>选择 JSON / ZIP 包</strong><small>已有标准安装包可直接上传</small></span><input name="package" type="file" accept=".json,.zip,application/json,application/zip"></label></div>
   <p id="skillFolderMeta" class="skill-folder-meta">尚未选择文件夹。文件夹上传时，上面的名称、标识和发布选项会覆盖 manifest 对应字段。</p>
   <div class="skill-upload-footer"><div class="publish-mode"><strong>上传后状态</strong><label class="selected-draft"><input type="radio" name="publishMode" value="draft" checked><span><b>保存为草稿</b><small>仅管理员可见，确认后再上架</small></span></label><label class="selected-published"><input type="radio" name="publishMode" value="published"><span><b>上传后直接上架</b><small>完成校验后立即同步到客户端市场</small></span></label></div><button class="primary skill-upload-submit" type="submit">上传技能</button></div>
  </form></section>`;
}

const tutorialCategoryLabels=Object.freeze({'getting-started':'新手入门',agents:'智能体使用','skills-tools':'技能与工具','files-knowledge':'文件与知识','company-collaboration':'一人公司协作','comic-workflow':'漫剧工作流',models:'模型配置',mobile:'手机端连接',troubleshooting:'故障排查'});
const tutorialActionLabels=Object.freeze({'':'不设置快捷入口',agents:'AI 员工',market:'AI 超市',skills:'技能',settings:'模型配置','settings-mobile':'手机端连接'});
function tutorialOptions(current='',values=tutorialCategoryLabels){return Object.entries(values).map(([value,label])=>`<option value="${esc(value)}"${value===current?' selected':''}>${esc(label)}</option>`).join('')}
function lines(value){return Array.isArray(value)?value.join('\n'):''}
function tutorialStatusActions(item){return item.status==='published'?`<button class="table-action amber" data-action="tutorial-status" data-status="unpublished" data-id="${esc(item.id)}">下架</button>`:`<button class="table-action green" data-action="tutorial-status" data-status="published" data-id="${esc(item.id)}">发布</button>`}

async function renderTutorials(){
 if(window.TutorialPublisher)return window.TutorialPublisher.mount({root:content,api,base:()=>state.apiBase,token:()=>state.token});
 const data=await api('/api/admin/tutorials');state.tutorials=data.items||[];
 const published=state.tutorials.filter(item=>item.status==='published').length;
 content.innerHTML=`<section class="panel tutorial-admin-hero"><div><span class="eyebrow">TUTORIAL PUBLISHER</span><h2>教程发布中心</h2><p>按客户端现有教程结构填写：准备内容、分步操作、注意事项和完成标准。发布后，客户端重新打开“教程”即会合并展示；离线时内置教程仍然可用。</p></div><div class="tutorial-admin-actions"><span><b>${published}</b> 篇已发布</span><button class="primary" type="button" data-action="create-tutorial">＋ 新建教程</button></div></section>
 <section class="panel"><div class="panel-head"><div><h2>教程列表</h2><p>草稿仅后台可见，已发布内容会通过公开教程接口进入客户端</p></div><div class="catalog-total"><strong>${state.tutorials.length}</strong><small>全部教程</small></div></div>${tutorialTable(state.tutorials)}</section>`;
}

function tutorialTable(items){if(!items.length)return empty('还没有后台教程，点击“新建教程”填写第一篇。');return `<div class="table-wrap tutorial-table"><table><thead><tr><th>教程</th><th>分类</th><th>结构</th><th>排序</th><th>状态</th><th>更新时间</th><th>操作</th></tr></thead><tbody>${items.map(item=>`<tr><td><strong>${esc(item.title)}</strong><br><span class="subtle mono">${esc(item.slug)}</span><br><small class="subtle">${esc(item.summary)}</small></td><td><span class="category-pill">${esc(tutorialCategoryLabels[item.category]||item.category)}</span></td><td>${item.steps?.length||0} 个步骤<br><small class="subtle">${item.preparation?.length||0} 项准备 · ${item.completion?.length||0} 项验收</small></td><td>${Number(item.sortOrder)||0}</td><td>${statusBlock(item.status)}</td><td>${date(item.updatedAt)}</td><td><div class="actions"><button class="table-action" data-action="edit-tutorial" data-id="${esc(item.id)}">编辑</button>${tutorialStatusActions(item)}<button class="table-action danger" data-action="delete-tutorial" data-id="${esc(item.id)}" data-name="${esc(item.title)}">删除</button></div></td></tr>`).join('')}</tbody></table></div>`}

function tutorialStepEditor(step={},index=0){return `<div class="tutorial-step-editor"><header><strong>步骤 ${index+1}</strong><button class="ghost" type="button" data-action="remove-tutorial-step" aria-label="删除该步骤">删除</button></header><div class="tutorial-step-fields"><label class="field">步骤标题<input name="stepTitle" maxlength="120" value="${esc(step.title||'')}" placeholder="例如：打开模型配置"></label><label class="field span-2">详细操作<textarea name="stepBody" rows="3" maxlength="4000" placeholder="写清点哪里、填什么、看到什么结果">${esc(step.body||'')}</textarea></label><label class="field span-2">本步验收提示（可选）<input name="stepCheck" maxlength="1000" value="${esc(step.check||'')}" placeholder="例如：必须看到真实测试成功"></label></div></div>`}

function openTutorialDialog(item={}){
 const editing=Boolean(item.id);const defaultSteps=editing?(item.steps||[]):[{},{},{}];
 $('#dialogRoot').innerHTML=`<div class="dialog-backdrop tutorial-editor-backdrop"><div class="dialog tutorial-editor-dialog" role="dialog" aria-modal="true" aria-labelledby="tutorialEditorTitle"><header class="builder-header"><div><span class="eyebrow">TUTORIAL TEMPLATE</span><h2 id="tutorialEditorTitle">${editing?'编辑教程':'新建教程'}</h2><p>这个模板与客户端教程详情一致，填写后可先存草稿，确认再发布。</p></div><button class="dialog-close" type="button" data-action="close-dialog" aria-label="关闭">×</button></header><form id="tutorialForm" data-id="${esc(item.id||'')}">
 <section class="builder-section"><div class="section-title"><span>01</span><div><h3>基本信息</h3><p>标题和简介会显示在教程目录中</p></div></div><div class="builder-grid three"><label class="field">教程标题<input name="title" maxlength="160" value="${esc(item.title||'')}" required placeholder="例如：如何上传并读取文件"></label><label class="field">英文标识<input name="slug" maxlength="80" pattern="[a-z0-9]+(?:-[a-z0-9]+)*" value="${esc(item.slug||'')}" required placeholder="file-upload-guide"></label><label class="field">所属分类<select name="category" required>${tutorialOptions(item.category||'getting-started')}</select></label><label class="field">预计时长<input name="duration" maxlength="40" value="${esc(item.duration||'约 3 分钟')}" required></label><label class="field">分类内排序<input name="sortOrder" type="number" min="-100000" max="100000" step="1" value="${Number(item.sortOrder)||0}" required></label><label class="field">保存状态<select name="status"><option value="draft"${selected('draft',item.status||'draft')}>草稿</option><option value="unpublished"${selected('unpublished',item.status)}>已下架</option><option value="published"${selected('published',item.status)}>直接发布</option></select></label><label class="field span-3">一句话简介<textarea name="summary" rows="2" maxlength="500" required placeholder="说清这篇教程帮客户完成什么">${esc(item.summary||'')}</textarea></label></div></section>
 <section class="builder-section"><div class="section-title"><span>02</span><div><h3>开始前与操作步骤</h3><p>准备内容每行一项；步骤可继续添加、删除和调整文字</p></div></div><label class="field">开始前准备（每行一项）<textarea name="preparation" rows="3" maxlength="20000" placeholder="准备可用的账号\n准备需要处理的文件">${esc(lines(item.preparation))}</textarea></label><div id="tutorialSteps" class="tutorial-steps-editor">${defaultSteps.map(tutorialStepEditor).join('')}</div><button class="secondary add-tutorial-step" type="button" data-action="add-tutorial-step">＋ 添加一个步骤</button></section>
 <section class="builder-section"><div class="section-title"><span>03</span><div><h3>提示、验收与快捷入口</h3><p>让客户知道哪些情况需要注意，以及什么才算完成</p></div></div><div class="builder-grid"><label class="field">注意事项（每行一项）<textarea name="tips" rows="4" maxlength="20000">${esc(lines(item.tips))}</textarea></label><label class="field">完成标准（每行一项）<textarea name="completion" rows="4" maxlength="20000">${esc(lines(item.completion))}</textarea></label><label class="field">看完后打开<select name="actionTarget">${tutorialOptions(item.action?.target||'',tutorialActionLabels)}</select></label><label class="field">快捷按钮文案<input name="actionLabel" maxlength="80" value="${esc(item.action?.label||'')}" placeholder="例如：打开模型配置"></label></div></section>
 <div class="dialog-actions sticky"><button class="secondary" type="button" data-action="close-dialog">取消</button><span class="save-hint">建议先保存草稿，核对后再发布</span><button class="primary" type="submit">${editing?'保存教程':'创建教程'}</button></div></form></div></div>`;
}

function tutorialPayload(form){
 const data=new FormData(form);const titles=data.getAll('stepTitle');const bodies=data.getAll('stepBody');const checks=data.getAll('stepCheck');
 const steps=titles.map((title,index)=>({title:String(title||'').trim(),body:String(bodies[index]||'').trim(),check:String(checks[index]||'').trim()})).filter(step=>step.title||step.body);
 if(!steps.length)throw new Error('请至少填写一个完整的操作步骤');
 if(steps.some(step=>!step.title||!step.body))throw new Error('每个已填写的步骤都需要标题和详细操作');
 const list=name=>String(data.get(name)||'').split(/\r?\n/).map(value=>value.trim()).filter(Boolean);const actionTarget=String(data.get('actionTarget')||'');const actionLabel=String(data.get('actionLabel')||'').trim();
 if(Boolean(actionTarget)!==Boolean(actionLabel))throw new Error('快捷入口的位置和按钮文案需要同时填写');
 return {title:data.get('title'),slug:data.get('slug'),category:data.get('category'),duration:data.get('duration'),summary:data.get('summary'),sortOrder:Number(data.get('sortOrder')),status:data.get('status'),preparation:list('preparation'),steps,tips:list('tips'),completion:list('completion'),action:actionTarget?{target:actionTarget,label:actionLabel}:null};
}

function normalizeSkillSlug(value){
  const normalized=Array.from(String(value||'').normalize('NFKC').replace(/[^\p{L}\p{N}\s_-]/gu,'').replace(/[\s_]+/g,'-').replace(/-+/g,'-').replace(/^-|-$/g,'').toLowerCase()).slice(0,64).join('');
  return normalized||`skill-${Date.now().toString(36)}`;
}

function uploadRoot(files){
  const roots=[...files].map(file=>String(file.webkitRelativePath||'').split('/')[0]).filter(Boolean);
  return roots[0]||'';
}

function relativeUploadPath(file,root){
  let value=String(file.webkitRelativePath||file.name||'').replaceAll('\\','/').replace(/^\/+|\/+$/g,'');
  if(root&&value.startsWith(`${root}/`))value=value.slice(root.length+1);
  if(!value||value.split('/').some(part=>!part||part==='.'||part==='..'))throw new Error('上传文件夹包含无效路径');
  return value;
}

async function folderUploadPolicy(type){
  if(!state.packagePolicies[type])state.packagePolicies[type]=api(`/api/admin/${type}/upload-policy`).then((value)=>value.package).catch((error)=>{delete state.packagePolicies[type];throw error});
  return state.packagePolicies[type];
}

function validateFolderSelection(type,files,policy){
  if(!files.length)throw new Error(type==='skills'?'请选择技能文件夹':'请选择智能体文件夹');
  if(files.length>Number(policy.maxEntries))throw new Error(`文件夹文件数量超过 ${policy.maxEntries} 项`);
  const root=uploadRoot(files);const entries=[];const seen=new Set();let total=0;
  for(const file of files){const relativePath=relativeUploadPath(file,root);const key=relativePath.toLowerCase();if(seen.has(key))throw new Error(`文件夹中存在重复路径：${relativePath}`);seen.add(key);const size=Number(file.size||0);if(!Number.isSafeInteger(size)||size<0)throw new Error(`文件大小无效：${relativePath}`);if(size>Number(policy.maxEntryBytes))throw new Error(`单个文件超过 ${Math.round(Number(policy.maxEntryBytes)/1024/1024)}MB：${relativePath}`);total+=size;if(!Number.isSafeInteger(total)||total>Number(policy.maxExtractedBytes))throw new Error(`文件夹总大小超过 ${Math.round(Number(policy.maxExtractedBytes)/1024/1024)}MB`);entries.push({file,relativePath})}
  const names=entries.map((entry)=>entry.relativePath.split('/').pop().toLowerCase());
  if(type==='skills'&&!names.includes('skill.md'))throw new Error('技能文件夹中缺少 SKILL.md');
  if(type==='agents'&&!names.includes('manifest.json'))throw new Error('智能体文件夹中缺少 manifest.json');
  if(type==='agents'&&!names.includes('system-prompt.md'))throw new Error('智能体文件夹中缺少 system-prompt.md');
  return {entries,total,root};
}

function appendSkillUploadFields(body,form,advancedCategoryPassword){
  body.append('publishMode',String(form.elements.publishMode?.value||'draft'));
  for(const field of ['skillName','skillSlug','skillCategory','skillVersion','skillSummary','skillDescription','skillChangelog'])body.append(field,String(form.elements[field]?.value||''));
  body.append('advancedCategoryPassword',advancedCategoryPassword||'');
}

async function folderUploadBody(type,form,files,advancedCategoryPassword=''){
  const selection=validateFolderSelection(type,files,await folderUploadPolicy(type));const body=new FormData();body.append('uploadMode','folder');
  if(type==='skills')appendSkillUploadFields(body,form,advancedCategoryPassword);
  for(const entry of selection.entries){body.append('folderPath',entry.relativePath);body.append('folderFile',entry.file,entry.file.name||'file')}
  return body;
}

async function skillJsonPackage(form,file){
  if(!file.name.toLowerCase().endsWith('.json'))return file;
  try{const value=JSON.parse(await file.text());if(!value||typeof value!=='object'||!value.manifest)return file;const data=new FormData(form);const manifest={...value.manifest,type:'skill',name:String(data.get('skillName')||value.manifest.name||'').trim(),slug:normalizeSkillSlug(data.get('skillSlug')||value.manifest.slug),summary:String(data.get('skillSummary')||value.manifest.summary||'').trim(),description:String(data.get('skillDescription')||value.manifest.description||'').trim(),category:String(data.get('skillCategory')||value.manifest.category||'通用').trim(),version:String(data.get('skillVersion')||value.manifest.version||'1.0.0').trim(),changelog:String(data.get('skillChangelog')||value.manifest.changelog||'').trim()};return new File([JSON.stringify({...value,manifest})],`${manifest.slug}.json`,{type:'application/json'})}catch{throw new Error('JSON 技能包不是有效格式')}
}

function bindUploadForm(form){
  if(!form)return;if(form.dataset.type==='skills')bindAdvancedCategoryPassword(form,'skillCategory');const folder=form.elements.folder;if(form.dataset.type==='agents'){const meta=form.querySelector('#agentFolderMeta');folder.addEventListener('change',()=>{const files=[...folder.files];const root=uploadRoot(files);meta.textContent=files.length?`已选择“${root||'智能体文件夹'}”，共 ${files.length} 个文件；提交时会自动打包并校验 manifest.json 与 system-prompt.md。`:'尚未选择文件夹。文件夹中的路径结构和辅助文件会原样打包。'});return}if(form.dataset.type!=='skills')return;const name=form.elements.skillName;const slug=form.elements.skillSlug;const meta=form.querySelector('#skillFolderMeta');
  name.addEventListener('input',()=>{name.dataset.auto='false'});slug.addEventListener('input',()=>{slug.dataset.auto='false'});
  folder.addEventListener('change',()=>{const files=[...folder.files];const root=uploadRoot(files);if(root&&!name.value){name.value=root;name.dataset.auto='true'}if(root&&(!slug.value||slug.dataset.auto==='true')){slug.value=normalizeSkillSlug(root);slug.dataset.auto='true'}meta.textContent=files.length?`已选择“${root||'技能文件夹'}”，共 ${files.length} 个文件；提交时会自动打包并校验 SKILL.md。`:'尚未选择文件夹。文件夹上传时，上面的名称、标识和发布选项会覆盖 manifest 对应字段。'});
}
function countStatuses(items){return items.reduce((result,item)=>{result[item.status]=(result[item.status]||0)+1;return result},{draft:0,published:0,unpublished:0,deleted:0})}
function productSummary(counts){return `<div class="product-summary"><div class="published"><i></i><span><strong>${counts.published}</strong><small>已上架 · 客户可见</small></span></div><div class="draft"><i></i><span><strong>${counts.draft}</strong><small>草稿 · 仅后台</small></span></div><div class="unpublished"><i></i><span><strong>${counts.unpublished}</strong><small>已下架 · 已隐藏</small></span></div><div class="deleted"><i></i><span><strong>${counts.deleted}</strong><small>历史删除 · 待清理</small></span></div></div>`}
function productFilters(type,current,counts){return `<div class="product-filters"><button class="${current==='active'?'active':''}" data-action="filter-products" data-type="${type}" data-filter="active">管理中 <b>${counts.published+counts.draft+counts.unpublished}</b></button>${['published','draft','unpublished','deleted'].map((key)=>`<button class="${current===key?'active':''}" data-action="filter-products" data-type="${type}" data-filter="${key}">${statusLabels[key]} <b>${counts[key]}</b></button>`).join('')}</div>`}
function avatarUrl(value){const raw=String(value||'').trim();if(!raw)return '';if(/^https?:\/\//i.test(raw)||raw.startsWith('data:')||raw.startsWith('blob:'))return raw;return `${state.apiBase}${raw.startsWith('/')?'':'/'}${raw}`}
function productTable(items,type){
 if(!items.length)return empty('当前状态下暂无内容');
  return `<div class="table-wrap product-table"><table><thead><tr><th>名称</th><th>标识</th><th>${type==='agents'?'分类 / 技能':'分类 / 来源'}</th><th>版本</th><th>发布状态</th><th>更新时间</th><th>操作</th></tr></thead><tbody>${items.map((item)=>{const latest=item.latestVersion||item.latest_version;const updated=item.updatedAt||item.updated_at;const editAction=type==='agents'?'edit-agent':'edit-product';const deleted=item.status==='deleted';const image=type==='agents'?avatarUrl(item.avatar):'';const itemCategory=canonicalMarketplaceCategory(item.category||latest?.manifest?.category||'通用');const identity=`data-type="${type}" data-id="${item.id}" data-name="${esc(item.name)}" data-slug="${esc(item.slug)}"`;return `<tr class="state-${esc(item.status)}"><td><div class="product-identity">${type==='agents'?`<span class="product-avatar">${image?`<img src="${esc(image)}" alt="">`:'AI'}</span>`:skillCategoryMark(itemCategory)}<span><strong>${esc(item.name)}</strong><small>${esc(type==='agents'?(item.role||item.summary||'未填写角色'):(item.summary||'无摘要'))}</small></span></div></td><td class="mono">${esc(item.slug)}</td><td>${type==='agents'?`<span class="category-pill">${esc(itemCategory)}</span><br><span class="subtle">${(item.skills||[]).length} 个技能</span>`:`<span class="category-pill">${esc(itemCategory)}</span><br><span class="subtle">云端独立产品</span>`}</td><td><b class="version-tag">v${esc(latest?.version||'—')}</b></td><td>${statusBlock(item.status)}</td><td>${date(updated)}</td><td>${deleted?`<div class="actions archived-actions"><span class="archived-label">历史删除记录</span><button class="table-action danger" data-action="permanent-delete" ${identity}>永久删除</button></div>`:`<div class="actions"><button class="table-action" data-action="${editAction}" ${identity}${type==='skills'?` data-summary="${esc(item.summary||'')}" data-description="${esc(item.description||'')}"`:''}>编辑</button>${type==='agents'?`<button class="table-action" data-action="clone-agent" data-id="${item.id}">复制</button>`:''}${item.status==='published'?`<button class="table-action amber" data-action="unpublish" ${identity}>立即下架</button>`:`<button class="table-action green" data-action="publish" ${identity}>上架</button>`}<button class="table-action danger" data-action="permanent-delete" ${identity}>删除</button></div>`}</td></tr>`}).join('')}</tbody></table></div>`;
}

async function verifyProductState(type,id,expected){
 const [admin,market]=await Promise.all([api(`/api/admin/${type}/${id}`),api(`/api/marketplace/${type}`)]);
 if(admin.status!==expected)throw new Error(`服务器状态校验失败：期望 ${statusLabels[expected]||expected}，实际 ${statusLabels[admin.status]||admin.status}`);
 const visible=(market.items||[]).some((item)=>item.id===id);
 if(visible!==(expected==='published'))throw new Error(expected==='published'?'服务器已上架，但客户端市场尚未显示':'服务器状态已修改，但客户端市场仍可见');
 return admin;
}
async function verifyProductGone(type,id){
 const [admin,market]=await Promise.all([api(`/api/admin/${type}`),api(`/api/marketplace/${type}`)]);
 if((admin.items||[]).some((item)=>item.id===id)||(market.items||[]).some((item)=>item.id===id))throw new Error('永久删除校验失败，服务器仍返回该资源');
}

function normalizeLicenseMachine(value=''){return String(value).trim().toLowerCase()}
function validLicenseMachine(value=''){return /^[a-f0-9]{32}$/.test(normalizeLicenseMachine(value))}
function licenseKeyPrefix(item){const current=String(item.license_key_prefix||'').trim();if(current)return current;const key=String(item.licenseKey||'').trim();return key.length>18?`${key.slice(0,18)}…`:(key||'—')}

async function renderUsers(){
 const machine=normalizeLicenseMachine(state.licenseMachineFilter);const deviceRequest=machine?api(`/api/admin/licenses/device/${encodeURIComponent(machine)}`):Promise.resolve(null);
 const [users,licenses,capabilities,deviceLicenses]=await Promise.all([apiAllPages('/api/admin/users'),apiAllPages('/api/admin/licenses'),api('/api/admin/licenses/capabilities'),deviceRequest]);const licenseItems=machine?(deviceLicenses?.items||[]):licenses.items;
 content.innerHTML=`<section class="device-license-hero"><div><p class="eyebrow">DEVICE LICENSE CENTER</p><h2>设备码授权中心</h2><p>每台客户设备只保留一个当前有效 Key。重新生成时旧 Key 自动吊销，历史记录仍永久保存在 PostgreSQL。</p></div><div class="signer-state ${capabilities.canSign?'ready':'missing'}"><i></i><span><strong>${capabilities.canSign?'签名服务可用':'签名私钥未配置'}</strong><small>${capabilities.canSign?'设备专属 Key 可立即生成':'请先恢复服务器签名私钥'}</small></span></div></section>
 <div class="license-workspace"><section class="panel license-issue-panel"><div class="panel-head"><div><h2>生成设备专属 Key</h2><p>输入客户激活页显示的 32 位设备码</p></div><span class="step-chip">1 个设备 · 1 个有效 Key</span></div><form id="licenseForm" class="device-license-form">
 <label class="field machine-field">设备码<input id="licenseMachine" name="machine" minlength="32" maxlength="32" pattern="[A-Fa-f0-9]{32}" required placeholder="粘贴 32 位设备码" autocomplete="off" spellcheck="false"></label>
 <label class="field">客户 / 授权名称<input name="name" maxlength="200" required placeholder="例如：木子工作室"></label>
 <label class="field">关联用户<select name="userId"><option value="">不关联用户</option>${users.items.map((u)=>`<option value="${u.id}">${esc(u.username)} · ${esc(u.email)}</option>`).join('')}</select></label>
 <label class="field">授权期限<select name="validity"><option value="30">1 个月（30 天）</option><option value="365">1 年</option><option value="1095">3 年</option><option value="3650">10 年</option><option value="permanent">永久</option></select></label>
 <button class="primary generate-key-button" type="submit"${capabilities.canSign?'':' disabled'}><span>＋</span>生成新的专属 Key</button></form><div id="licenseResult"></div></section>
 <section class="panel license-search-panel"><div class="panel-head"><div><h2>按设备码查询完整 Key</h2><p>用于找回和复制当前或历史授权 Key</p></div></div><form id="licenseSearchForm" class="license-search-form"><input id="licenseKeySearch" name="machine" minlength="32" maxlength="32" pattern="[A-Fa-f0-9]{32}" required placeholder="输入完整的 32 位设备码" autocomplete="off" spellcheck="false"><button class="secondary" type="submit">查询完整 Key</button></form><div id="licenseSearchResult" class="license-search-result"><div class="license-search-empty"><span>⌕</span><strong>输入设备码即可查询</strong><small>完整 Key 只向已登录管理员显示</small></div></div></section></div>
 <section class="panel license-record-panel"><div class="panel-head license-record-head"><div><h2>设备授权记录</h2><p>${machine?'已按完整设备码显示该设备的全部历史授权':'输入完整的 32 位设备码，可精确查看该设备的全部历史状态'}</p></div><div class="license-record-tools"><form id="licenseRecordSearchForm" class="license-record-search"><input id="deviceLicenseSearch" name="machine" minlength="32" maxlength="32" pattern="[A-Fa-f0-9]{32}" required value="${esc(machine)}" placeholder="输入完整的 32 位设备码" autocomplete="off" spellcheck="false" aria-label="按32位设备码精确查询"><button class="secondary" type="submit">查询</button>${machine?'<button class="ghost" type="button" data-action="clear-license-filter">清除</button>':''}</form><span class="record-count">${licenseItems.length} 条${machine?'历史':''}记录</span></div></div>${licenseTable(licenseItems,{filtered:Boolean(machine)})}</section>
 <section class="panel"><div class="panel-head"><div><h2>平台用户</h2><p>不显示密码，使用统计仅为匿名事件计数</p></div></div>${userTable(users.items)}</section>`;
}

async function renderAdmins(){
 const data=await api('/api/admin/admins');const items=Array.isArray(data)?data:(data.items||[]);
 content.innerHTML=`<section class="panel admin-account-intro"><div><span class="eyebrow">ACCOUNT DELIVERY</span><h2>后台管理员账号下发</h2><p>为需要进入后台的管理人员设置独立账号和密码。密码只在创建或重置时提交，列表中不会显示。</p></div><span class="admin-count"><strong>${items.length}</strong><small>管理员</small></span></section>
 <section class="panel"><div class="panel-head"><div><h2>添加管理员</h2><p>账号、邮箱和初始密码由你自行设置</p></div></div><form id="adminCreateForm" class="admin-create-form" autocomplete="off"><label class="field">管理员账号 <b>*</b><input name="username" minlength="3" maxlength="20" required autocomplete="off" placeholder="例如：editor01"></label><label class="field">联系邮箱（可选）<input name="email" type="email" maxlength="254" autocomplete="off" placeholder="name@example.com"></label><label class="field">初始密码 <b>*</b><input name="password" type="password" minlength="8" maxlength="128" required autocomplete="new-password" placeholder="至少 8 位"></label><label class="field">确认密码 <b>*</b><input name="passwordConfirm" type="password" minlength="8" maxlength="128" required autocomplete="new-password" placeholder="再次输入密码"></label><button class="primary" type="submit">下发管理员账号</button></form></section>
 <section class="panel"><div class="panel-head"><div><h2>管理员列表</h2><p>可重置密码或停用不再需要的账号</p></div><span class="record-count">${items.length} 个账号</span></div>${adminAccountTable(items)}</section>`;
}

function adminAccountTable(items){
 if(!items.length)return empty('还没有可管理的后台账号');
 return `<div class="table-wrap admin-account-table"><table><thead><tr><th>管理员</th><th>邮箱</th><th>状态</th><th>创建时间</th><th>操作</th></tr></thead><tbody>${items.map((item)=>{const current=Boolean(item.isCurrent||item.id===state.user?.id);return `<tr><td><strong>${esc(item.username||'未命名管理员')}</strong>${current?'<br><span class="current-admin-badge">当前账号</span>':''}</td><td>${esc(item.email||'未设置')}</td><td>${statusBlock('active')}</td><td>${date(item.createdAt||item.created_at)}</td><td><div class="actions"><button class="table-action" type="button" data-action="reset-admin-password" data-id="${esc(item.id)}" data-name="${esc(item.username||item.email||'管理员')}">重置密码</button><button class="table-action warn" type="button" data-action="delete-admin" data-id="${esc(item.id)}" data-name="${esc(item.username||item.email||'管理员')}"${current?' disabled title="不能停用当前登录账号"':''}>停用并移除</button></div></td></tr>`}).join('')}</tbody></table></div>`;
}

function adminPasswordResetDialog(button){
 $('#dialogRoot').innerHTML=`<div class="dialog-backdrop"><div class="dialog admin-reset-dialog" role="dialog" aria-modal="true" aria-labelledby="adminResetTitle"><h2 id="adminResetTitle">重置“${esc(button.dataset.name)}”的密码</h2><p class="subtle">保存后旧密码和旧登录会话将失效，请将新密码安全地交给该管理员。</p><form id="adminPasswordResetForm" data-id="${esc(button.dataset.id)}"><label class="field">新密码<input name="password" type="password" minlength="8" maxlength="128" required autocomplete="new-password" placeholder="至少 8 位"></label><label class="field">确认新密码<input name="passwordConfirm" type="password" minlength="8" maxlength="128" required autocomplete="new-password" placeholder="再次输入新密码"></label><div class="dialog-actions"><button class="secondary" type="button" data-action="close-dialog">取消</button><button class="primary" type="submit">确认重置</button></div></form></div></div>`;
 $('#adminPasswordResetForm input[name="password"]')?.focus();
}

function userTable(items){if(!items.length)return empty('暂无用户');return `<div class="table-wrap"><table><thead><tr><th>用户</th><th>角色</th><th>授权数</th><th>使用事件</th><th>最近使用</th><th>注册时间</th></tr></thead><tbody>${items.map((u)=>`<tr><td><strong>${esc(u.username)}</strong><br><span class="subtle">${esc(u.email)}</span></td><td>${esc(u.role)}</td><td>${u.license_count}</td><td>${u.event_count}</td><td>${date(u.last_seen_at)}</td><td>${date(u.created_at)}</td></tr>`).join('')}</tbody></table></div>`}
function licenseTable(items,{filtered=false}={}){if(!items.length)return empty(filtered?'该设备暂无授权记录':'暂无设备授权');return `<div class="table-wrap license-table"><table><thead><tr><th>客户</th><th>设备码</th><th>Key 前缀</th><th>状态</th><th>激活情况</th><th>到期</th><th>操作</th></tr></thead><tbody>${items.map((item)=>{const canDelete=item.status==='revoked'||item.status==='expired';return `<tr><td><strong>${esc(item.display_name||item.username||'未命名授权')}</strong><br><span class="subtle">${esc(item.username||item.email||'未关联用户')}</span></td><td><code class="machine-code">${esc(item.machine_fingerprint||'非绑定授权')}</code></td><td class="mono">${esc(licenseKeyPrefix(item))}</td><td>${statusBlock(item.status)}</td><td>${item.activated_at?`<span class="activation-state used"><i></i>已激活</span><br><small class="subtle">${date(item.activated_at)}</small>`:'<span class="activation-state pending"><i></i>等待激活</span>'}</td><td>${item.expires_at?date(item.expires_at):'永久'}</td><td>${item.status==='active'?`<button class="table-action warn" data-action="revoke-license" data-id="${esc(item.id)}">吊销</button>`:canDelete?`<button class="table-action danger" data-action="delete-license" data-id="${esc(item.id)}">删除</button>`:'—'}</td></tr>`}).join('')}</tbody></table></div>`}
function issuedLicenseCard(result){return `<div class="issued-license-card"><div class="issued-license-heading"><span>✓</span><div><strong>新的设备专属 Key 已生成</strong><small>已持久化到服务器，可随时按设备码找回</small></div></div><div class="issued-device"><span>设备码</span><code>${esc(result.machine_fingerprint||result.payload?.machine||'')}</code></div><div class="license-key-box"><textarea readonly spellcheck="false">${esc(result.licenseKey)}</textarea><button class="primary" data-action="copy-license" type="button">复制授权 Key</button></div></div>`}
function searchedLicenseCards(data){if(!data.items?.length)return `<div class="license-search-empty not-found"><span>!</span><strong>未找到该设备的授权</strong><small>请检查设备码，或在左侧为它生成新的 Key</small></div>`;return `<div class="device-query-head"><span>设备码</span><code>${esc(data.machine)}</code><b>${data.items.length} 条记录</b></div><div class="device-license-history">${data.items.map((item,index)=>`<article class="device-license-record ${index===0?'latest':''}"><header><div><strong>${esc(item.display_name||'设备授权')}</strong><small>${date(item.created_at)}</small></div>${status(item.status)}</header><div class="license-key-box"><textarea readonly spellcheck="false">${esc(item.licenseKey)}</textarea><button class="secondary" data-action="copy-license" type="button">复制 Key</button></div><footer><span>${item.activated_at?'已激活':'未激活'}</span><span>${item.expires_at?`到期 ${date(item.expires_at)}`:'永久授权'}</span>${index===0?'<b>最新</b>':''}</footer></article>`).join('')}</div>`}

async function renderAudit(){
 const [audit,usage]=await Promise.all([api('/api/admin/audit'),api('/api/admin/telemetry?days=30')]);const max=Math.max(1,...usage.byEvent.map((item)=>item.count));
 content.innerHTML=`<section class="panel"><div class="panel-head"><div><h2>匿名使用统计</h2><p>近 ${usage.days} 天，按事件类型聚合</p></div></div><div class="event-bars">${usage.byEvent.length?usage.byEvent.map((item)=>`<div class="event-row"><span>${esc(eventLabels[item.name]||item.name)}</span><div class="bar"><i style="width:${Math.max(3,item.count/max*100)}%"></i></div><strong>${item.count}</strong></div>`).join(''):empty('暂无统计')}</div></section>
 <section class="panel"><div class="panel-head"><div><h2>管理员操作日志</h2><p>最近 ${audit.items.length} 条</p></div><button class="danger clear-audit-button" type="button" data-action="clear-audit">清空操作日志</button></div>${auditTable(audit.items)}</section>`;
}
function auditTable(items){if(!items.length)return empty('暂无操作日志');return `<div class="table-wrap"><table><thead><tr><th>时间</th><th>管理员</th><th>操作</th><th>对象</th><th>摘要</th></tr></thead><tbody>${items.map((item)=>`<tr><td>${date(item.created_at)}</td><td>${esc(item.username||item.email||'系统')}</td><td class="mono">${esc(item.action)}</td><td>${esc(item.entity_type||'—')}</td><td class="subtle">${esc(JSON.stringify(item.metadata||{})).slice(0,180)}</td></tr>`).join('')}</tbody></table></div>`}

function editDialog(button){
 $('#dialogRoot').innerHTML=`<div class="dialog-backdrop"><div class="dialog" role="dialog" aria-modal="true"><h2>编辑资源</h2><form id="editProductForm" data-type="${button.dataset.type}" data-id="${button.dataset.id}"><label class="field">名称<input name="name" maxlength="120" value="${esc(button.dataset.name)}" required></label><label class="field"><span>卡片摘要</span><textarea name="summary" maxlength="500">${esc(button.dataset.summary)}</textarea><small>客户端技能卡片使用</small></label><label class="field"><span>详情介绍</span><textarea name="description" rows="5" maxlength="50000">${esc(button.dataset.description)}</textarea><small>客户端技能详情页使用，不覆盖卡片摘要</small></label><div class="dialog-actions"><button class="secondary" type="button" data-action="close-dialog">取消</button><button class="primary" type="submit">保存</button></div></form></div></div>`;
}

function checked(value){return value?' checked':''}
function selected(value,current){return value===current?' selected':''}
const DEFAULT_STARTER_PROMPTS=['请介绍你的能力和工作方式','帮我拆解当前任务并给出执行计划','先向我确认完成任务需要的信息'];
function starterPromptValues(agent={}){const source=Array.isArray(agent.starterPrompts)?agent.starterPrompts:[];return DEFAULT_STARTER_PROMPTS.map((fallback,index)=>String(source[index]||fallback).trim()||fallback)}
function agentSkillSelector(selectedIds=[]){
 const active=new Set(selectedIds||[]);
 if(!state.catalogSkills.length)return '<div class="builder-empty">还没有可选技能。请先在“技能”页上传技能包。</div>';
 return `<div class="skill-picker">${state.catalogSkills.map((skill)=>{const version=skill.latestVersion||skill.latest_version;return `<label class="skill-option"><input type="checkbox" name="skillIds" value="${skill.id}"${checked(active.has(skill.id))}><span><strong>${esc(skill.name)}</strong><small>${esc(skill.summary||'无摘要')} · ${esc(version?.version||'无版本')}</small></span>${status(skill.status)}</label>`}).join('')}</div>`;
}

async function openAgentBuilder({id='',clone=false}={}){
 let agent={workspace:{}};
 if(id)agent=await api(`/api/admin/agents/${id}`);
 const latest=agent.latestVersion||agent.latest_version||agent.versions?.[0];
 const workspace=agent.workspace||{};
 const editing=Boolean(id&&!clone);
 const cloneSuffix=Date.now().toString().slice(-6);
 const slug=clone?`${String(agent.slug||'agent').slice(0,56).replace(/-+$/,'')}-${cloneSuffix}`:agent.slug||`agent-${cloneSuffix}`;
 const name=clone?`${agent.name||'智能体'} 副本`:agent.name||'';
 const version=clone?'1.0.0':latest?.version||'1.0.0';
 const starterPrompts=starterPromptValues(agent);
 const avatar=clone?'':agent.avatar||'';const avatarPreview=avatarUrl(avatar);const currentStatus=clone?'draft':agent.status||'draft';
 $('#dialogRoot').innerHTML=`<div class="dialog-backdrop agent-builder-backdrop"><div class="dialog agent-builder-dialog" role="dialog" aria-modal="true" aria-labelledby="agentBuilderTitle">
  <header class="builder-header"><div><span class="eyebrow">AGENT BUILDER</span><h2 id="agentBuilderTitle">${editing?'编辑智能体':clone?'复制智能体':'新建智能体'}</h2><p>设定它是谁、如何工作、可以使用哪些技能与工具。</p></div><button class="dialog-close" type="button" data-action="close-dialog" aria-label="关闭">×</button></header>
  <form id="agentBuilderForm" data-id="${editing?id:''}">
   <section class="builder-section"><div class="section-title"><span>01</span><div><h3>形象与基本信息</h3><p>这些内容会直接展示在客户应用的智能体市场</p></div></div><div class="builder-profile">
    <div class="avatar-editor"><div class="avatar-preview${avatarPreview?' has-image':''}" id="avatarPreview">${avatarPreview?`<img src="${esc(avatarPreview)}" alt="智能体头像">`:'<span>AI</span>'}</div><input type="hidden" name="avatar" value="${esc(avatar)}"><input type="hidden" name="icon" value="${esc(agent.icon||'bot')}"><input class="avatar-file" id="avatarFile" name="avatarFile" type="file" accept="image/png,image/jpeg,image/webp"><label class="secondary avatar-upload-button" for="avatarFile">上传真实头像</label><small id="avatarUploadStatus">PNG / JPG / WEBP，最大 3MB</small></div>
    <div class="builder-grid three profile-fields">
     <label class="field">名称<input name="name" maxlength="120" value="${esc(name)}" required placeholder="例：新媒体内容总监"></label>
     <label class="field">唯一标识 Slug<input name="slug" maxlength="64" pattern="[a-z0-9][a-z0-9-]*" value="${esc(slug)}" required placeholder="content-director"></label>
     <label class="field">分类<select class="select" name="category" required>${categoryOptions(agent.category||'漫剧')}</select></label>
     <label class="field span-3">一句话简介<input name="summary" maxlength="500" value="${esc(agent.summary||'')}" placeholder="一句话说清它能解决什么问题"></label>
     <label class="field span-3">详细介绍<textarea name="description" rows="3" maxlength="50000" placeholder="介绍职责、适用场景与交付物">${esc(agent.description||'')}</textarea></label>
    </div>
   </div></section>
   <section class="builder-section"><div class="section-title"><span>02</span><div><h3>角色设定</h3><p>角色名称用于客户端展示，系统提示词决定真实对话行为</p></div></div><div class="builder-grid">
    <label class="field span-2">角色名称<input name="role" maxlength="200" value="${esc(agent.role||agent.summary||'')}" required placeholder="例：新媒体内容策略与交付负责人"></label>
    <label class="field span-2">系统提示词<textarea name="systemPrompt" rows="9" maxlength="200000" required placeholder="你是……\n\n职责：……\n工作流程：……\n输出标准：……">${esc(agent.systemPrompt||'')}</textarea></label>
    <label class="field span-2">欢迎语<textarea name="welcomeMessage" rows="3" maxlength="10000" placeholder="用户打开智能体时看到的第一句话">${esc(agent.welcomeMessage||'')}</textarea></label>
    <fieldset class="fieldset starter-prompt-fieldset span-2"><legend class="fieldset-legend">开场提示词</legend><p class="label">客户端欢迎页展示三个可直接点击的示例任务</p><div class="starter-prompt-grid"><label class="field"><span>示例 1</span><input class="input" name="starterPrompt1" maxlength="500" value="${esc(starterPrompts[0])}" required placeholder="输入用户可直接发送的任务"></label><label class="field"><span>示例 2</span><input class="input" name="starterPrompt2" maxlength="500" value="${esc(starterPrompts[1])}" required placeholder="输入用户可直接发送的任务"></label><label class="field"><span>示例 3</span><input class="input" name="starterPrompt3" maxlength="500" value="${esc(starterPrompts[2])}" required placeholder="输入用户可直接发送的任务"></label></div></fieldset>
   </div></section>
   <section class="builder-section"><div class="section-title"><span>03</span><div><h3>工作区与权限</h3><p>设定长期目标、交付目录与记忆；运行能力由客户端统一管理</p></div></div><div class="builder-grid">
    <label class="field span-2">工作目标<textarea name="workspaceGoal" rows="3" maxlength="20000" placeholder="它在这个工作区需要持续达成的目标">${esc(workspace.goal||'')}</textarea></label>
    <label class="field span-2">角色规则<textarea name="workspaceRoleRules" rows="4" maxlength="50000" placeholder="例：每次修改前先备份；交付文件必须放入指定目录">${esc(workspace.roleRules||'')}</textarea></label>
    <label class="field">默认交付目录<input name="outputDirectory" maxlength="500" value="${esc(workspace.outputDirectory||'outputs')}" placeholder="outputs"></label>
    <div class="permission-grid span-2">
     <label><input type="checkbox" name="memoryEnabled"${checked(workspace.memoryEnabled!==false)}><span><strong>启用长期记忆</strong><small>保留该智能体的独立工作记忆</small></span></label>
     <label><input type="checkbox" name="allowFiles"${checked(workspace.allowFiles!==false)}><span><strong>允许文件</strong><small>可以读写工作区文件</small></span></label>
    </div>
    <div class="runtime-capability-note span-2" role="note" aria-label="客户端运行能力说明">
     <div><i aria-hidden="true"></i><span><strong>联网默认开启</strong><small>智能体可搜索和读取公开网络内容，无需在后台逐个授权。</small></span></div>
     <div><i aria-hidden="true"></i><span><strong>终端跟随桌面端电脑权限</strong><small>用户在桌面端开启电脑权限后，当前智能体才能使用 PowerShell、CMD 与 CLI。</small></span></div>
    </div>
   </div></section>
   <section class="builder-section compact"><div class="section-title"><span>04</span><div><h3>技能与发布</h3><p>选择专属技能，并明确保存后的市场状态</p></div></div><div class="skill-subheading"><strong>专属技能</strong><small>勾选后写入智能体配置</small></div>${agentSkillSelector(agent.skillIds||[])}<div class="publish-settings"><div class="builder-grid"><label class="field">版本<input name="version" value="${esc(version)}" pattern="(0|[1-9][0-9]*)\\.(0|[1-9][0-9]*)\\.(0|[1-9][0-9]*)" required></label><label class="field">版本说明<input name="changelog" maxlength="20000" placeholder="本次更新内容"></label></div><div><div class="skill-subheading"><strong>保存后状态</strong><small>“已上架”会立即对客户端可见</small></div><div class="publish-choices"><label class="draft"><input type="radio" name="status" value="draft"${checked(currentStatus==='draft')}><span><strong>保存为草稿</strong><small>仅后台可见，适合继续编辑</small></span></label><label class="unpublished"><input type="radio" name="status" value="unpublished"${checked(currentStatus==='unpublished')}><span><strong>保持下架</strong><small>客户端市场中隐藏</small></span></label><label class="published"><input type="radio" name="status" value="published"${checked(currentStatus==='published')}><span><strong>直接上架</strong><small>客户端刷新后可见</small></span></label></div></div></div></section>
   <div class="dialog-actions sticky"><button class="secondary" type="button" data-action="close-dialog">取消</button><span class="save-hint">保存后会自动生成市场 manifest</span><button class="primary" type="submit">${editing?'保存智能体':'创建智能体'}</button></div>
  </form></div></div>`;
 const builderForm=$('#agentBuilderForm');bindAdvancedCategoryPassword(builderForm,'category');const avatarInput=builderForm?.querySelector('input[name="avatarFile"]');avatarInput?.addEventListener('change',async()=>{const file=avatarInput.files?.[0];if(!file)return;const statusEl=$('#avatarUploadStatus');const hidden=$('#agentBuilderForm input[name="avatar"]');const preview=$('#avatarPreview');if(file.size>3*1024*1024){avatarInput.value='';statusEl.textContent='图片超过 3MB，请压缩后重试';statusEl.classList.add('upload-error');return}if(!['image/png','image/jpeg','image/webp'].includes(file.type)){avatarInput.value='';statusEl.textContent='仅支持 PNG、JPG 或 WEBP';statusEl.classList.add('upload-error');return}statusEl.textContent='正在安全上传…';statusEl.classList.remove('upload-error');const body=new FormData();body.append('avatar',file);try{const result=await api('/api/admin/agents/avatar',{method:'POST',body});hidden.value=result.url;preview.classList.add('has-image');preview.innerHTML=`<img src="${esc(avatarUrl(result.url))}" alt="智能体头像">`;statusEl.textContent='头像已上传，保存智能体后生效';notice('头像上传成功')}catch(error){statusEl.textContent=error.message;statusEl.classList.add('upload-error');notice(error.message,true)}});
}

const LOGIN_INTERACTION_MODE=Object.freeze({IDLE:'idle',MOUSE_TRACKING:'mouse-tracking',USERNAME_HOVER:'username-hover',USERNAME_FOCUS:'username-focus',PASSWORD_FOCUS:'password-focus'});
const LOGIN_CHARACTER_CONFIG=Object.freeze({
  violet:{maxEyeX:7.5,maxEyeY:5.5,sensitivity:.018,minFollow:.14,baseFollow:.17,maxFollow:.38,velocityFactor:.0045,peekFollow:.34,returnFollow:.17,parallax:3.2,bodyRotate:6,targetOffset:{x:-2,y:-2},typingTilt:.45},
  charcoal:{maxEyeX:6.5,maxEyeY:5,sensitivity:.017,minFollow:.08,baseFollow:.16,maxFollow:.35,velocityFactor:.004,peekFollow:.09,returnFollow:.16,parallax:2.3,bodyRotate:5,targetOffset:{x:4,y:3},typingTilt:-.35},
  orange:{maxEyeX:4,maxEyeY:3.2,sensitivity:.015,minFollow:.14,baseFollow:.19,maxFollow:.4,velocityFactor:.0048,peekFollow:.16,returnFollow:.18,parallax:4,bodyRotate:4,targetOffset:{x:1,y:2},typingTilt:.25},
  yellow:{maxEyeX:4,maxEyeY:3.2,sensitivity:.016,minFollow:.13,baseFollow:.18,maxFollow:.37,velocityFactor:.0043,peekFollow:.14,returnFollow:.17,parallax:3.3,bodyRotate:4.5,targetOffset:{x:5,y:-1},typingTilt:-.28}
});

function clampLoginMotion(value,min,max){return Math.min(max,Math.max(min,value))}
function computeBoundedGaze(eye,target,config,weight=1){
 const dx=target.x-eye.x;const dy=target.y-eye.y;const angle=Math.atan2(dy,dx);const strength=Math.min(1,Math.hypot(dx,dy)*config.sensitivity)*weight;
 return {x:Math.cos(angle)*config.maxEyeX*strength,y:Math.sin(angle)*config.maxEyeY*strength};
}
function computeVelocityFollow(mouseSpeed,config){return clampLoginMotion(config.baseFollow+clampLoginMotion(mouseSpeed,0,80)*config.velocityFactor,config.minFollow,config.maxFollow)}

function initLoginCharacterScene(){
 const scene=document.querySelector('[data-character-scene]');
 const usernameInput=document.querySelector('[data-login-field="identifier"]');
 const passwordInput=document.querySelector('[data-login-field="password"]');
 if(!scene||!usernameInput||!passwordInput)return {start(){},stop(){},destroy(){}};
 const reducedQuery=globalThis.matchMedia?.('(prefers-reduced-motion: reduce)')||{matches:false,addEventListener(){},removeEventListener(){}};
 const characters=[...scene.querySelectorAll('[data-character]')].map((element)=>{
  const config=LOGIN_CHARACTER_CONFIG[element.dataset.character];
  const eyes=[...element.querySelectorAll('[data-eye]')].map((eye)=>({element:eye,pupil:eye.querySelector('.character-pupil'),center:{x:0,y:0},x:0,y:0}));
  const motion=element.querySelector('[data-character-motion]');
  return {element,motion,config,eyes,bodyX:0,bodyY:0,bodyR:0,typingImpulse:0};
 }).filter((character)=>character.motion&&character.config&&character.eyes.every((eye)=>eye.pupil));
 let mode=LOGIN_INTERACTION_MODE.IDLE;let usernameFocused=false;let usernameHovered=false;let passwordFocused=false;let pointerInside=false;
 let sceneRect={left:0,top:0,right:0,width:1,height:1};let usernameRect={left:0,top:0,width:1,height:1};let geometryDirty=true;
 let targetPointer={x:0,y:0};let sampledPointer={x:0,y:0};let pointerInitialized=false;let smoothSpeed=0;
 let animationFrame=0;let running=false;let lastFrameTime=0;let usernameFocusStartedAt=0;let focusPhase='idle';
 const entryAnimations=new Set(['shanman-entry-charcoal-smooth','shanman-entry-yellow-smooth','shanman-entry-violet-smooth','shanman-entry-orange-smooth']);
 const entryElements=[...scene.querySelectorAll('[data-character-entry]')];
 scene.dataset.intro=reducedQuery.matches?'complete':'running';
 scene.dataset.focusPhase='idle';
 if(reducedQuery.matches)for(const entry of entryElements)entry.dataset.entryComplete='true';

 const resolveMode=()=>{
  if(usernameFocused)return LOGIN_INTERACTION_MODE.USERNAME_FOCUS;
  if(passwordFocused)return LOGIN_INTERACTION_MODE.PASSWORD_FOCUS;
  if(usernameHovered)return LOGIN_INTERACTION_MODE.USERNAME_HOVER;
  if(pointerInside&&!reducedQuery.matches)return LOGIN_INTERACTION_MODE.MOUSE_TRACKING;
  return LOGIN_INTERACTION_MODE.IDLE;
 };
 const setFocusPhase=(next)=>{if(next===focusPhase)return;focusPhase=next;scene.dataset.focusPhase=next};
 const updateMode=()=>{const next=resolveMode();if(next===mode)return;mode=next;scene.dataset.interactionMode=mode;if(mode===LOGIN_INTERACTION_MODE.USERNAME_FOCUS)geometryDirty=true;else setFocusPhase('idle')};
 const updateFocusPhase=(timestamp)=>{
  if(mode!==LOGIN_INTERACTION_MODE.USERNAME_FOCUS){setFocusPhase('idle');return}
  const elapsed=Math.max(0,timestamp-usernameFocusStartedAt);
  setFocusPhase(elapsed<220?'violet-check':elapsed<480?'charcoal-reply':'field-lock');
 };
 const refreshGeometry=()=>{
  sceneRect=scene.getBoundingClientRect();usernameRect=usernameInput.getBoundingClientRect();
  for(const character of characters){for(const eye of character.eyes){const rect=eye.element.getBoundingClientRect();eye.center={x:rect.left+rect.width/2,y:rect.top+rect.height/2}}}
  if(!pointerInitialized){targetPointer={x:sceneRect.left+sceneRect.width*.58,y:sceneRect.top+sceneRect.height*.46};sampledPointer={...targetPointer};pointerInitialized=true}
  geometryDirty=false;
 };
  const characterLookPoint=(key)=>{
   const match=characters.find((candidate)=>candidate.element.dataset.character===key);
   if(!match?.eyes.length)return {x:usernameRect.left+44,y:usernameRect.top+usernameRect.height/2};
   return {x:match.eyes.reduce((sum,item)=>sum+item.center.x,0)/match.eyes.length,y:match.eyes.reduce((sum,item)=>sum+item.center.y,0)/match.eyes.length};
  };
  const gazeTarget=(eye,character)=>{
   if(mode===LOGIN_INTERACTION_MODE.USERNAME_FOCUS){
    const key=character.element.dataset.character;
    if(focusPhase==='violet-check'&&key==='violet')return {...characterLookPoint('charcoal'),weight:1};
    if(focusPhase==='charcoal-reply'&&(key==='violet'||key==='charcoal'))return {...characterLookPoint(key==='violet'?'charcoal':'violet'),weight:1};
    const weight=focusPhase!=='field-lock'&&(key==='orange'||key==='yellow') ? .48 : 1;
    return {x:usernameRect.left+44+character.config.targetOffset.x,y:usernameRect.top+usernameRect.height/2+character.config.targetOffset.y,weight};
   }
   if(mode===LOGIN_INTERACTION_MODE.USERNAME_HOVER)return {x:usernameRect.left+44+character.config.targetOffset.x,y:usernameRect.top+usernameRect.height/2+character.config.targetOffset.y,weight:.28};
  if(mode===LOGIN_INTERACTION_MODE.PASSWORD_FOCUS)return {x:eye.center.x-90+character.config.targetOffset.x,y:eye.center.y-58+character.config.targetOffset.y,weight:.68};
  if(mode===LOGIN_INTERACTION_MODE.MOUSE_TRACKING)return {x:targetPointer.x,y:targetPointer.y,weight:1};
  return {x:sceneRect.right+80,y:sceneRect.top+sceneRect.height*.43+character.config.targetOffset.y,weight:.42};
 };
 const animate=(timestamp)=>{
  if(!running)return;
  updateFocusPhase(timestamp);
  if(scene.dataset.intro!=='complete'){lastFrameTime=timestamp;animationFrame=requestAnimationFrame(animate);return}
  if(geometryDirty)refreshGeometry();
  const frameScale=clampLoginMotion((timestamp-(lastFrameTime||timestamp))/16.667,.5,2);lastFrameTime=timestamp;
  const rawSpeed=Math.hypot(targetPointer.x-sampledPointer.x,targetPointer.y-sampledPointer.y);sampledPointer={...targetPointer};smoothSpeed+=(clampLoginMotion(rawSpeed,0,80)-smoothSpeed)*.2;
  const normalizedX=clampLoginMotion((targetPointer.x-sceneRect.left)/Math.max(sceneRect.width,1)-.5,-.5,.5);const normalizedY=clampLoginMotion((targetPointer.y-sceneRect.top)/Math.max(sceneRect.height,1)-.5,-.5,.5);
  for(const character of characters){
   const config=character.config;let follow=mode===LOGIN_INTERACTION_MODE.USERNAME_FOCUS?config.peekFollow:mode===LOGIN_INTERACTION_MODE.IDLE||mode===LOGIN_INTERACTION_MODE.PASSWORD_FOCUS?config.returnFollow:computeVelocityFollow(smoothSpeed,config);
   if(reducedQuery.matches)follow=1;const effectiveFollow=1-Math.pow(1-follow,frameScale);
    for(const eye of character.eyes){const target=gazeTarget(eye,character);const gaze=computeBoundedGaze(eye.center,target,config,target.weight);eye.x+=(gaze.x-eye.x)*effectiveFollow;eye.y+=(gaze.y-eye.y)*effectiveFollow;eye.pupil.style.setProperty('--eye-x',`${eye.x.toFixed(2)}px`);eye.pupil.style.setProperty('--eye-y',`${eye.y.toFixed(2)}px`)}
   const tracking=mode===LOGIN_INTERACTION_MODE.MOUSE_TRACKING&&!reducedQuery.matches;const targetBodyX=tracking?normalizedX*config.parallax*2:0;const targetBodyY=tracking?normalizedY*config.parallax*2:0;const targetBodyR=tracking?normalizedX*config.bodyRotate*2:0;
   const bodyFollow=1-Math.pow(.9,frameScale);character.bodyX+=(targetBodyX-character.bodyX)*bodyFollow;character.bodyY+=(targetBodyY-character.bodyY)*bodyFollow;character.bodyR+=(targetBodyR-character.bodyR)*bodyFollow;character.typingImpulse*=Math.pow(.82,frameScale);
   character.motion.style.setProperty('--body-x',`${character.bodyX.toFixed(2)}px`);character.motion.style.setProperty('--body-y',`${character.bodyY.toFixed(2)}px`);character.motion.style.setProperty('--body-r',`${character.bodyR.toFixed(3)}deg`);character.motion.style.setProperty('--typing-r',`${(character.typingImpulse*config.typingTilt).toFixed(3)}deg`);
  }
  animationFrame=requestAnimationFrame(animate);
 };
 const onPointerMove=(event)=>{targetPointer={x:event.clientX,y:event.clientY};pointerInitialized=true};
 const onPointerEnter=()=>{pointerInside=true;updateMode()};
 const onPointerLeave=()=>{pointerInside=false;updateMode()};
 const onUsernameEnter=()=>{usernameHovered=true;updateMode()};
 const onUsernameLeave=()=>{usernameHovered=false;updateMode()};
 const onUsernameFocus=()=>{usernameFocused=true;passwordFocused=false;usernameFocusStartedAt=performance.now();setFocusPhase('violet-check');geometryDirty=true;updateMode()};
 const onUsernameBlur=()=>{usernameFocused=false;updateMode()};
 const onUsernameInput=()=>{if(usernameFocused)for(const character of characters)character.typingImpulse=1};
 const onPasswordFocus=()=>{passwordFocused=true;usernameFocused=false;updateMode()};
 const onPasswordBlur=()=>{passwordFocused=false;updateMode()};
 const onLayoutChange=()=>{geometryDirty=true};
 const onEntryAnimationEnd=(event)=>{if(!entryAnimations.has(event.animationName)||!event.target?.matches?.('[data-character-entry]'))return;event.target.dataset.entryComplete='true';if(entryElements.every((entry)=>entry.dataset.entryComplete==='true')){scene.dataset.intro='complete';geometryDirty=true}};
 const onReducedMotionChange=()=>{if(reducedQuery.matches){for(const entry of entryElements)entry.dataset.entryComplete='true';scene.dataset.intro='complete'}geometryDirty=true;updateMode()};
 scene.addEventListener('pointermove',onPointerMove,{passive:true});scene.addEventListener('pointerenter',onPointerEnter,{passive:true});scene.addEventListener('pointerleave',onPointerLeave,{passive:true});
 scene.addEventListener('animationend',onEntryAnimationEnd);
 usernameInput.addEventListener('mouseenter',onUsernameEnter);usernameInput.addEventListener('mouseleave',onUsernameLeave);usernameInput.addEventListener('focus',onUsernameFocus);usernameInput.addEventListener('blur',onUsernameBlur);usernameInput.addEventListener('input',onUsernameInput);
 passwordInput.addEventListener('focus',onPasswordFocus);passwordInput.addEventListener('blur',onPasswordBlur);window.addEventListener('resize',onLayoutChange,{passive:true});reducedQuery.addEventListener('change',onReducedMotionChange);
 const resizeObserver=globalThis.ResizeObserver?new ResizeObserver(onLayoutChange):null;resizeObserver?.observe(scene);resizeObserver?.observe(usernameInput);
 const controller={
  start(){if(running)return;running=true;lastFrameTime=0;geometryDirty=true;animationFrame=requestAnimationFrame(animate)},
  stop(){running=false;if(animationFrame)cancelAnimationFrame(animationFrame);animationFrame=0},
  destroy(){this.stop();resizeObserver?.disconnect();scene.removeEventListener('pointermove',onPointerMove);scene.removeEventListener('pointerenter',onPointerEnter);scene.removeEventListener('pointerleave',onPointerLeave);scene.removeEventListener('animationend',onEntryAnimationEnd);usernameInput.removeEventListener('mouseenter',onUsernameEnter);usernameInput.removeEventListener('mouseleave',onUsernameLeave);usernameInput.removeEventListener('focus',onUsernameFocus);usernameInput.removeEventListener('blur',onUsernameBlur);usernameInput.removeEventListener('input',onUsernameInput);passwordInput.removeEventListener('focus',onPasswordFocus);passwordInput.removeEventListener('blur',onPasswordBlur);window.removeEventListener('resize',onLayoutChange);reducedQuery.removeEventListener('change',onReducedMotionChange)}
 };
 window.addEventListener('pagehide',()=>controller.destroy(),{once:true});return controller;
}

function normalizeApiBase(value){
 const raw=String(value||'').trim().replace(/\/$/,'');if(!raw)return '';
 let parsed;try{parsed=new URL(raw)}catch{throw new Error('请输入完整的后台地址，例如 https://api.example.com')}
 const local=['localhost','127.0.0.1','::1'].includes(parsed.hostname);
 if(parsed.protocol!=='https:'&&!(local&&parsed.protocol==='http:'))throw new Error('公网后台必须使用 HTTPS，避免管理员密码和令牌被窃取');
 return parsed.origin+parsed.pathname.replace(/\/$/,'');
}

const apiBaseField=$('#apiBaseField');const apiBaseInput=$('#apiBaseInput');
if(!state.apiBase)apiBaseField.hidden=false;
apiBaseInput.value=state.apiBase;
loginCharacterScene=initLoginCharacterScene();

$('#loginForm').addEventListener('submit',async(event)=>{
 event.preventDefault();const formElement=event.currentTarget;const form=new FormData(formElement);const submit=formElement.querySelector('[data-login-submit]');const original=submit.innerHTML;$('#loginError').textContent='';submit.disabled=true;submit.setAttribute('aria-busy','true');submit.textContent='正在安全登录…';
 try{const nextApiBase=normalizeApiBase(form.get('apiBase')||state.apiBase);if(nextApiBase!==state.apiBase){state.apiBase=nextApiBase;state.token='';sessionStorage.removeItem(TOKEN_KEY);if(nextApiBase)localStorage.setItem(API_BASE_KEY,nextApiBase);else localStorage.removeItem(API_BASE_KEY)}const data=await api('/api/auth/login',{method:'POST',body:JSON.stringify({identifier:form.get('identifier'),password:form.get('password')})});if(data.user?.role!=='admin')throw new Error('该账号不是管理员');state.token=data.token;state.user=data.user;sessionStorage.setItem(TOKEN_KEY,data.token);showApp()}catch(error){$('#loginError').textContent=error.message}finally{submit.disabled=false;submit.removeAttribute('aria-busy');submit.innerHTML=original}
});
$('#navigation').addEventListener('click',(event)=>{const button=event.target.closest('[data-page]');if(button)void navigate(button.dataset.page)});
$('#logoutButton').addEventListener('click',logout);$('#refreshButton').addEventListener('click',()=>void navigate(state.page));$('#menuButton').addEventListener('click',()=>$('.sidebar').classList.toggle('open'));

content.addEventListener('submit',async(event)=>{
 event.preventDefault();const form=event.target;
 try{
   if(form.id==='uploadForm'){
     const type=form.dataset.type;let body;
     if(type==='skills'){
      const advancedCategoryPassword=await advancedCategoryPasswordForSubmission(form,'skillCategory');
      const folderFiles=[...(form.elements.folder?.files||[])];const packageFile=form.elements.package?.files?.[0];
      if(folderFiles.length)body=await folderUploadBody(type,form,folderFiles,advancedCategoryPassword);else if(packageFile){body=new FormData();body.append('uploadMode','package');appendSkillUploadFields(body,form,advancedCategoryPassword);const file=await skillJsonPackage(form,packageFile);body.append('package',file,file.name)}else throw new Error('请选择技能文件夹或 JSON / ZIP 安装包');
      }else{const folderFiles=[...(form.elements.folder?.files||[])];const packageFile=form.elements.package?.files?.[0];if(folderFiles.length)body=await folderUploadBody(type,form,folderFiles);else if(packageFile){body=new FormData();body.append('uploadMode','package');body.append('package',packageFile,packageFile.name)}else throw new Error('请选择智能体文件夹或 JSON / ZIP 安装包')}
     let result;try{result=await api(`/api/admin/${type}/upload`,{method:'POST',body})}catch(error){if(type!=='agents'||!String(error.message||'').includes('高级'))throw error;const password=await requestAdvancedCategoryPassword();if(!password)throw new Error('已取消高级分类验证，本次上传未提交');body.set('advancedCategoryPassword',password);result=await api(`/api/admin/${type}/upload`,{method:'POST',body})}const id=result.product?.id||result.id;if(!id)throw new Error('上传成功但服务器没有返回资源 ID');
     const expected=type==='skills'?String(form.elements.publishMode?.value||'draft'):'draft';if(type==='skills'&&expected==='published'&&result.product?.status!=='published')await api(`/api/admin/${type}/${id}/publish`,{method:'POST'});const verified=await verifyProductState(type,id,expected);advancedCategoryPasswords.delete(form);notice(expected==='published'?`技能“${verified.name}”已写入数据库并上架，公共目录已确认可见（${verified.slug} · v${verified.latestVersion?.version||verified.latest_version?.version||'—'}）`:`技能“${verified.name}”已写入数据库并保存为草稿，公共目录已确认隐藏`);await navigate(type);return;
    }
   if(form.id==='adminCreateForm'){const data=new FormData(form);const password=String(data.get('password')||'');const passwordConfirm=String(data.get('passwordConfirm')||'');if(password!==passwordConfirm)throw new Error('两次输入的密码不一致');const submit=form.querySelector('button[type="submit"]');submit.disabled=true;try{await api('/api/admin/admins',{method:'POST',body:JSON.stringify({username:String(data.get('username')||'').trim(),email:String(data.get('email')||'').trim()||undefined,password,passwordConfirm})});form.reset();notice('管理员账号已下发');await renderAdmins()}finally{submit.disabled=false}return}
  if(form.id==='licenseForm'){const data=new FormData(form);const machine=String(data.get('machine')||'').trim().toLowerCase();const validity=String(data.get('validity')||'365');const payload={name:data.get('name'),userId:data.get('userId')||undefined,machine,...(validity==='permanent'?{permanent:true}:{days:Number(validity)})};const submit=form.querySelector('button[type="submit"]');if(submit)submit.disabled=true;try{const result=await api('/api/admin/licenses',{method:'POST',body:JSON.stringify(payload)});$('#licenseResult').innerHTML=issuedLicenseCard(result);notice('设备专属 Key 已生成并保存到服务器')}finally{if(submit)submit.disabled=false}return}
  if(form.id==='licenseSearchForm'){const data=new FormData(form);const machine=normalizeLicenseMachine(data.get('machine'));if(!validLicenseMachine(machine))throw new Error('请输入完整的 32 位设备码');const target=$('#licenseSearchResult');target.innerHTML='<div class="loading compact">正在查询设备授权…</div>';const result=await api(`/api/admin/licenses/device/${encodeURIComponent(machine)}`);target.innerHTML=searchedLicenseCards(result);return}
  if(form.id==='licenseRecordSearchForm'){const data=new FormData(form);const machine=normalizeLicenseMachine(data.get('machine'));if(!validLicenseMachine(machine))throw new Error('请输入完整的 32 位设备码');const submit=form.querySelector('button[type="submit"]');const previous=state.licenseMachineFilter;if(submit){submit.disabled=true;submit.textContent='查询中…'}state.licenseMachineFilter=machine;try{await renderUsers()}catch(error){state.licenseMachineFilter=previous;throw error}finally{if(submit?.isConnected){submit.disabled=false;submit.textContent='查询'}}return}
 }catch(error){notice(error.message,true)}
});

$('#dialogRoot').addEventListener('submit',async(event)=>{
 event.preventDefault();const form=event.target;const data=new FormData(form);
 try{
  if(form.id==='editProductForm'){
   await api(`/api/admin/${form.dataset.type}/${form.dataset.id}`,{method:'PATCH',body:JSON.stringify({name:data.get('name'),summary:data.get('summary'),description:data.get('description')})});
   $('#dialogRoot').innerHTML='';notice('保存成功');await navigate(form.dataset.type);return;
  }
  if(form.id==='agentBuilderForm'){
    const submit=form.querySelector('button[type="submit"]');if(submit)submit.disabled=true;
    const advancedCategoryPassword=await advancedCategoryPasswordForSubmission(form,'category');
    const payload={
     name:data.get('name'),slug:data.get('slug'),category:data.get('category'),advancedCategoryPassword,summary:data.get('summary'),description:data.get('description'),icon:data.get('icon'),avatar:data.get('avatar'),
    role:data.get('role'),systemPrompt:data.get('systemPrompt'),welcomeMessage:data.get('welcomeMessage'),starterPrompts:[data.get('starterPrompt1'),data.get('starterPrompt2'),data.get('starterPrompt3')],
     workspace:{goal:data.get('workspaceGoal'),roleRules:data.get('workspaceRoleRules'),outputDirectory:data.get('outputDirectory'),memoryEnabled:data.has('memoryEnabled'),allowWeb:true,allowFiles:data.has('allowFiles'),allowTerminal:true},
    skillIds:data.getAll('skillIds'),version:data.get('version'),status:data.get('status'),changelog:data.get('changelog')
   };
   const id=form.dataset.id;await api(id?`/api/admin/agents/${id}`:'/api/admin/agents',{method:id?'PATCH':'POST',body:JSON.stringify(payload)});
    advancedCategoryPasswords.delete(form);$('#dialogRoot').innerHTML='';notice(id?'智能体已保存':'智能体已创建');await navigate('agents');return;
   }
   if(form.id==='tutorialForm'){
    const submit=form.querySelector('button[type="submit"]');if(submit)submit.disabled=true;
    const payload=tutorialPayload(form);const id=form.dataset.id;
    await api(id?`/api/admin/tutorials/${id}`:'/api/admin/tutorials',{method:id?'PATCH':'POST',body:JSON.stringify(payload)});
    $('#dialogRoot').innerHTML='';notice(payload.status==='published'?'教程已保存并发布到客户端':'教程已保存');await navigate('tutorials');return;
   }
   if(form.id==='adminPasswordResetForm'){
    const password=String(data.get('password')||'');const passwordConfirm=String(data.get('passwordConfirm')||'');if(password!==passwordConfirm)throw new Error('两次输入的密码不一致');const submit=form.querySelector('button[type="submit"]');submit.disabled=true;await api(`/api/admin/admins/${form.dataset.id}/reset-password`,{method:'POST',body:JSON.stringify({password,passwordConfirm})});$('#dialogRoot').innerHTML='';notice('管理员密码已重置，旧登录会话已失效');await navigate('admins');return;
   }
 }catch(error){const submit=form.querySelector('button[type="submit"]');if(submit)submit.disabled=false;notice(error.message,true)}
});

document.addEventListener('click',async(event)=>{
 const button=event.target.closest('[data-action]');if(!button)return;const action=button.dataset.action;
 if(action==='dashboard-nav'){void navigate(button.dataset.page);return}
 if(action==='filter-products'){state.productFilters[button.dataset.type]=button.dataset.filter;void navigate(button.dataset.type);return}
 if(action==='close-dialog'){$('#dialogRoot').innerHTML='';return}if(action==='edit-product'){editDialog(button);return}
 if(action==='reset-admin-password'){adminPasswordResetDialog(button);return}
 if(action==='create-agent'||action==='edit-agent'||action==='clone-agent'){
  try{await openAgentBuilder({id:button.dataset.id||'',clone:action==='clone-agent'})}catch(error){notice(error.message,true)}return;
 }
 if(action==='create-tutorial'){openTutorialDialog();return}
 if(action==='edit-tutorial'){const item=state.tutorials.find(entry=>entry.id===button.dataset.id);if(!item){notice('教程记录不存在，请刷新后重试',true);return}openTutorialDialog(item);return}
 if(action==='add-tutorial-step'){const root=$('#tutorialSteps');if(!root)return;const count=root.querySelectorAll('.tutorial-step-editor').length;root.insertAdjacentHTML('beforeend',tutorialStepEditor({},count));root.lastElementChild?.querySelector('input')?.focus();return}
 if(action==='remove-tutorial-step'){button.closest('.tutorial-step-editor')?.remove();[...document.querySelectorAll('#tutorialSteps .tutorial-step-editor')].forEach((row,index)=>{const label=row.querySelector('header strong');if(label)label.textContent=`步骤 ${index+1}`});return}
 if(action==='copy-license'){const value=button.closest('.license-key-box')?.querySelector('textarea')?.value||'';try{await navigator.clipboard.writeText(value);notice('已复制授权 Key')}catch{notice('复制失败，请手动复制',true)}return}
 try{
  if(action==='tutorial-status'){
   const next=button.dataset.status;button.disabled=true;try{await api(`/api/admin/tutorials/${button.dataset.id}/status`,{method:'POST',body:JSON.stringify({status:next})});notice(next==='published'?'教程已发布，客户端重新打开教程即可获取':'教程已下架');await navigate('tutorials')}finally{if(button.isConnected)button.disabled=false}return;
  }
  if(action==='delete-tutorial'){
   if(!confirm(`确定删除教程“${button.dataset.name||'该教程'}”？删除后客户端不再获取，且无法恢复。`))return;button.disabled=true;try{await api(`/api/admin/tutorials/${button.dataset.id}`,{method:'DELETE'});notice('教程已删除');await navigate('tutorials')}finally{if(button.isConnected)button.disabled=false}return;
  }
  if(action==='publish'||action==='unpublish'){
   const type=button.dataset.type;const id=button.dataset.id;const expected=action==='publish'?'published':'unpublished';
   const original=button.textContent;button.disabled=true;button.textContent='处理中…';
    try{await api(`/api/admin/${type}/${id}/${action}`,{method:'POST'});await verifyProductState(type,id,expected);state.productFilters[type]=expected;notice(action==='publish'?'已真实上架，客户端市场已确认可见':type==='skills'?'技能已真实下架，客户端市场已隐藏；绑定智能体保持原状态':'智能体已真实下架，客户端市场已隐藏');await navigate(type)}finally{button.disabled=false;button.textContent=original}return;
  }
   if(action==='permanent-delete'){
   if(!confirm(`永久删除“${button.dataset.name||'该资源'}”？数据库记录、全部版本和上传文件将立即清除，且无法恢复。`))return;
   const type=button.dataset.type;const id=button.dataset.id;const slug=button.dataset.slug||'';const original=button.textContent;button.disabled=true;button.textContent='永久删除中…';
   try{const result=await api(`/api/admin/${type}/${id}/permanent?confirm=${encodeURIComponent(slug)}`,{method:'DELETE'});await verifyProductGone(type,id);state.productFilters[type]='active';const detached=Number(result.affectedAgents?.length||0);notice(`已从数据库永久删除“${button.dataset.name||result.slug}”${result.removedVersions?`，清理 ${result.removedVersions} 个版本`:''}${detached?`；已从 ${detached} 个智能体配置中解除该技能，智能体发布状态未改变`:''}${result.cleanupWarnings?'；部分历史文件清理失败，请检查服务器日志':''}`,Boolean(result.cleanupWarnings));await navigate(type)}finally{button.disabled=false;button.textContent=original}return;
   }
   if(action==='delete-admin'){
    if(!confirm(`停用并移除管理员“${button.dataset.name||'该账号'}”？该账号将无法再登录后台。`))return;button.disabled=true;try{await api(`/api/admin/admins/${button.dataset.id}`,{method:'DELETE'});notice('管理员账号已停用并移除');await navigate('admins')}finally{button.disabled=false}return;
   }
   if(action==='clear-audit'){
    if(!confirm('确定清空现有管理员操作日志？清理后只保留本次清理记录。'))return;button.disabled=true;try{const result=await api('/api/admin/audit',{method:'DELETE'});notice(`已清理 ${Number(result.deletedCount||0)} 条操作日志`);await navigate('audit')}finally{button.disabled=false}return;
   }
   if(action==='clear-license-filter'){state.licenseMachineFilter='';await renderUsers();return}
   if(action==='revoke-license'){
    if(!confirm('确定吊销这条授权？已激活设备后续将无法再次验证。'))return;button.disabled=true;try{await api(`/api/admin/licenses/${button.dataset.id}/revoke`,{method:'POST'});notice('授权已吊销');await renderUsers()}finally{if(button.isConnected)button.disabled=false}return;
   }
   if(action==='delete-license'){
    if(!confirm('永久删除这条已吊销或已过期的授权记录？删除后无法恢复，但不会影响其他有效授权。'))return;const original=button.textContent;button.disabled=true;button.textContent='删除中…';try{await api(`/api/admin/licenses/${button.dataset.id}`,{method:'DELETE'});notice('历史授权记录已删除');await renderUsers()}finally{if(button.isConnected){button.disabled=false;button.textContent=original}}return;
   }
 }catch(error){notice(error.message,true)}
});

(async()=>{if(!state.token)return showLogin();try{const data=await api('/api/me');if(data.user?.role!=='admin')throw new Error('不是管理员');state.user=data.user;showApp()}catch{logout()}})();
