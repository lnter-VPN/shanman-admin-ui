import Fastify from 'fastify';
import cors from '@fastify/cors';
import jwt from '@fastify/jwt';
import multipart from '@fastify/multipart';
import { config } from './config.js';
import { migrate, pool, withPackageStorageFence } from './db.js';
import { ensureAdmin } from './auth.js';
import registerAdminStatic from './admin-static.js';
import { requireAuth, requireAdmin } from './middleware/auth.js';
import healthRoutes from './routes/health.js';
import authRoutes from './routes/auth.js';
import marketplaceRoutes from './routes/marketplace.js';
import licenseRoutes from './routes/licenses.js';
import adminRoutes from './routes/admin.js';
import telemetryRoutes from './routes/telemetry.js';
import tutorialRoutes from './routes/tutorials.js';
import { corsOriginPolicy, MARKETPLACE_EXPOSED_HEADERS } from './cors-origin.js';
import { formatByteLimit, multipartLimits } from './upload-policy.js';
import { cleanupStalePackageStaging, collectUnreferencedPackageDirectories } from './package-upload.js';
import { createBoundedShutdown } from './shutdown.js';

// Keep ordinary JSON/auth surfaces small. The marketplace upload route opts in
// to the larger package allowance explicitly, so a package-size setting cannot
// accidentally turn every API endpoint into a 512MB request surface.
const app = Fastify({ logger: true, bodyLimit: 4 * 1024 * 1024, trustProxy: config.trustProxy });
const packageStagingStartupBoundary = Date.now();
await app.register(cors, { origin: corsOriginPolicy(config.webOrigin), exposedHeaders: MARKETPLACE_EXPOSED_HEADERS });
await app.register(jwt, { secret: config.jwtSecret });
await app.register(multipart, { limits: multipartLimits(config.maxPackageBytes), throwFileSizeLimit: true });
app.decorate('requireAuth', requireAuth); app.decorate('requireAdmin', requireAdmin);
app.addHook('onSend', async (request, reply, payload) => {
  if (request.url.startsWith('/api/admin/') || request.url === '/api/me' || request.url.startsWith('/api/me/')) {
    reply.header('cache-control', 'no-store, max-age=0');
  }
  return payload;
});
// Register the handler before encapsulated route plugins so every API surface
// inherits the same actionable Chinese upload/auth error contract.
app.setErrorHandler((error, request, reply) => {
  const statusCode = Number(error.statusCode || (error.code === 'FST_REQ_FILE_TOO_LARGE' ? 413 : 500));
  if (statusCode >= 500) request.log.error(error); else request.log.warn({ code: error.code, message: error.message }, '请求被拒绝');
  const message = error.code === 'FST_REQ_FILE_TOO_LARGE'
    ? `上传包超过服务器允许的 ${formatByteLimit(config.maxPackageBytes)}，请精简文件或由管理员调整 MAX_PACKAGE_BYTES`
    : statusCode < 500 || statusCode === 503 || statusCode === 507 ? error.message : '服务器内部错误';
  reply.code(statusCode).send({ error: message });
});
await migrate(); await ensureAdmin(config);
const runPackageStorageGc = async () => {
  const staging = await cleanupStalePackageStaging(config.storagePath, {
    createdBeforeMs: packageStagingStartupBoundary,
    maxEntries: 2000
  });
  const cleanup = await collectUnreferencedPackageDirectories(config.storagePath, {
    // This callback runs while the content-addressed package directory lock is
    // held. Uploads keep a lease from staging through the DB commit, so a GC
    // pass either sees that lease or rechecks the committed row here. Never use
    // a process-start snapshot: it could delete a just-committed shared hash.
    withFence: withPackageStorageFence,
    isReferenced: async (packagePaths, transactionQuery) => {
      const reference = await transactionQuery(`SELECT EXISTS(
        SELECT 1 FROM agent_product_versions WHERE package_path = ANY($1::text[])
        UNION ALL SELECT 1 FROM skill_product_versions WHERE package_path = ANY($1::text[])
      ) AS present`, [packagePaths]);
      return Boolean(reference.rows[0]?.present);
    },
    maxDirectories: 2000
  });
  if (staging.removed || staging.capped) app.log.info(staging, '安装包崩溃残留清理完成');
  if (cleanup.removed || cleanup.skippedActive || cleanup.capped) app.log.info(cleanup, '安装包存储引用清理完成');
};
await registerAdminStatic(app, { root: config.adminStaticRoot });
await app.register(healthRoutes); await app.register(authRoutes); await app.register(marketplaceRoutes); await app.register(licenseRoutes); await app.register(adminRoutes); await app.register(tutorialRoutes); await app.register(telemetryRoutes);
let packageGcPromise = Promise.resolve();
let closing = false;
const shutdown = createBoundedShutdown({
  app, pool, timeoutMs: config.shutdownTimeoutMs,
  waitForBackground: () => packageGcPromise.catch(() => {})
});
const close = (signal) => {
  if (closing) {
    shutdown.force(`重复收到 ${signal} 关闭信号`);
    return;
  }
  closing = true;
  void shutdown.shutdown(signal);
};
process.on('SIGTERM', () => close('SIGTERM')); process.on('SIGINT', () => close('SIGINT'));
await app.listen({ host: '0.0.0.0', port: config.port });
// Storage GC is defensive maintenance. Run it only after health/licensing are
// available so a large historical package tree or transient disk error can
// never delay the server from accepting traffic.
setImmediate(() => {
  if (closing) return;
  packageGcPromise = runPackageStorageGc()
    .catch((error) => app.log.warn({ error: error.message }, '安装包存储引用清理跳过'));
});
