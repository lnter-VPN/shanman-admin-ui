import fs from 'node:fs/promises';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import {detectAvatarImage} from './avatar-storage.js';
import {TUTORIAL_IMAGE_URL_RE} from './tutorials.js';

export const MAX_TUTORIAL_IMAGE_BYTES=8*1024*1024;
const bad=(message,statusCode)=>Object.assign(new Error(message),{statusCode});
export function tutorialImagePath(storageRoot,filename){
  if(!TUTORIAL_IMAGE_URL_RE.test(`/api/tutorial-images/${filename}`))throw bad('图片路径无效',400);
  return path.join(path.resolve(storageRoot),'tutorial-images',filename);
}
export async function readTutorialImage(request){
  if(!request.isMultipart())throw bad('请选择要上传的图片',415);
  try{
    const part=await request.file({limits:{fileSize:MAX_TUTORIAL_IMAGE_BYTES,files:1,fields:0,parts:1}});
    if(!part)throw bad('请选择图片',400);
    const chunks=[];let size=0;
    for await(const chunk of part.file){size+=chunk.length;if(size>MAX_TUTORIAL_IMAGE_BYTES)throw bad('单张图片不能超过 8MB',413);chunks.push(chunk)}
    if(part.file.truncated)throw bad('单张图片不能超过 8MB',413);
    const buffer=Buffer.concat(chunks,size);const format=detectAvatarImage(buffer);
    if(!format)throw bad('仅支持真实的 PNG、JPG、WEBP 图片，不支持 SVG 或其他文件',415);
    return {buffer,filename:`${randomUUID()}.${format.extension}`,contentType:format.contentType,size};
  }catch(error){
    if(['FST_REQ_FILE_TOO_LARGE','FST_FILES_LIMIT','FST_PARTS_LIMIT'].includes(error.code))throw bad('一次上传一张图片，单张不能超过 8MB',413);
    throw error;
  }
}
export async function saveTutorialImage(storageRoot,image){
  const target=tutorialImagePath(storageRoot,image.filename);
  await fs.mkdir(path.dirname(target),{recursive:true});
  await fs.writeFile(target,image.buffer,{flag:'wx',mode:0o600});
  return target;
}
