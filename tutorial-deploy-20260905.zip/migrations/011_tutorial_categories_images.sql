CREATE TABLE IF NOT EXISTS tutorial_categories (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_tutorial_category_name ON tutorial_categories(lower(name));
INSERT INTO tutorial_categories(id,name) VALUES
 ('getting-started','新手入门'),('agents','智能体使用'),('skills-tools','技能与工具'),
 ('files-knowledge','文件与知识'),('company-collaboration','一人公司协作'),
 ('comic-workflow','漫剧工作流'),('models','模型配置'),('mobile','手机端连接'),('troubleshooting','故障排查')
ON CONFLICT DO NOTHING;
INSERT INTO tutorial_categories(id,name) SELECT DISTINCT category,category FROM tutorials
WHERE category NOT IN (SELECT id FROM tutorial_categories) ON CONFLICT DO NOTHING;
ALTER TABLE tutorials ADD COLUMN IF NOT EXISTS body TEXT NOT NULL DEFAULT '';
ALTER TABLE tutorials ADD COLUMN IF NOT EXISTS images JSONB NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE tutorials ADD CONSTRAINT tutorials_category_fk FOREIGN KEY (category) REFERENCES tutorial_categories(id);
CREATE TABLE IF NOT EXISTS tutorial_images (
  filename TEXT PRIMARY KEY,
  content_type TEXT NOT NULL,
  size_bytes INTEGER NOT NULL CHECK (size_bytes>0 AND size_bytes<=8388608),
  created_by UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
