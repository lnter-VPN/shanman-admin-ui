-- Preserve all published/draft tutorial content; only normalize legacy categories.
-- Existing custom categories named like the catalog are adopted, not duplicated.
INSERT INTO tutorial_categories(id,name) VALUES
 ('general','通用'),('comic','漫剧'),('design','设计'),('video','视频'),('software','软件'),
 ('writing','写作'),('operations','运营'),('ecommerce','电商'),('advanced','高级')
ON CONFLICT DO NOTHING;
-- Free conflicting legacy display names while retaining their rows for rollback.
UPDATE tutorial_categories SET name=name || '（旧分类）'
WHERE id NOT IN ('general','comic','design','video','software','writing','operations','ecommerce','advanced')
AND name IN ('通用','漫剧','设计','视频','软件','写作','运营','电商','高级');
INSERT INTO tutorial_categories(id,name) VALUES
 ('general','通用'),('comic','漫剧'),('design','设计'),('video','视频'),('software','软件'),
 ('writing','写作'),('operations','运营'),('ecommerce','电商'),('advanced','高级')
ON CONFLICT DO NOTHING;
UPDATE tutorials SET category='general'
WHERE category NOT IN ('general','comic','design','video','software','writing','operations','ecommerce','advanced');
