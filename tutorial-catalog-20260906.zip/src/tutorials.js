export const TUTORIAL_CATALOG=Object.freeze([
  ['general','通用'],['comic','漫剧'],['design','设计'],['video','视频'],['software','软件'],
  ['writing','写作'],['operations','运营'],['ecommerce','电商'],['advanced','高级']
].map(([id,name])=>Object.freeze({id,name})));
export const TUTORIAL_CATEGORIES=Object.freeze(TUTORIAL_CATALOG.map(item=>item.id));

export const TUTORIAL_ACTION_TARGETS=Object.freeze(['agents','market','skills','settings','settings-mobile']);

function text(value,label,max,{required=true}={}){
  const normalized=String(value??'').trim();
  if(required&&!normalized)throw Object.assign(new TypeError(`${label} 必填`),{statusCode:400});
  if(normalized.length>max)throw Object.assign(new TypeError(`${label} 不能超过 ${max} 字`),{statusCode:400});
  return normalized;
}

function stringList(value,label,maxItems=20,maxLength=1000){
  if(value===undefined||value===null)return [];
  if(!Array.isArray(value)||value.length>maxItems)throw Object.assign(new TypeError(`${label} 格式无效`),{statusCode:400});
  return value.map((item,index)=>text(item,`${label}第 ${index+1} 项`,maxLength)).filter(Boolean);
}

function steps(value){
  if(value===undefined)return [];
  if(!Array.isArray(value)||value.length>30)throw Object.assign(new TypeError('操作步骤最多 30 项'),{statusCode:400});
  return value.map((item,index)=>{
    if(!item||typeof item!=='object'||Array.isArray(item))throw Object.assign(new TypeError(`第 ${index+1} 个步骤格式无效`),{statusCode:400});
    return {
      title:text(item.title,`第 ${index+1} 个步骤标题`,120),
      body:text(item.body,`第 ${index+1} 个步骤内容`,4000),
      ...(item.images?.length?{images:tutorialImages(item.images)}:{}),
      ...(String(item.check??'').trim()?{check:text(item.check,`第 ${index+1} 个步骤验收提示`,1000)}:{})
    };
  });
}

export const TUTORIAL_IMAGE_URL_RE=/^\/api\/tutorial-images\/[0-9a-f-]{36}\.(?:png|jpg|webp)$/;
export function tutorialImages(value){
  if(value===undefined||value===null)return [];
  if(!Array.isArray(value)||value.length>12)throw Object.assign(new Error('每个内容区域最多 12 张图片'),{statusCode:400});
  return value.map(item=>{
    if(!item||typeof item!=='object'||!TUTORIAL_IMAGE_URL_RE.test(item.url||''))throw Object.assign(new Error('请使用后台上传的教程图片'),{statusCode:400});
    return {url:item.url,caption:text(item.caption,'图片说明',300,{required:false})};
  });
}

export function validateTutorialCategory(value){
  const name=text(value?.name,'分类名称',40);
  if(/[<>\x00-\x1f]/.test(name))throw Object.assign(new Error('分类名称包含无效字符'),{statusCode:400});
  return {name};
}

function action(value){
  if(value===undefined||value===null||value==='')return null;
  if(!value||typeof value!=='object'||Array.isArray(value))throw Object.assign(new TypeError('快捷操作格式无效'),{statusCode:400});
  const target=text(value.target,'快捷操作目标',40);
  if(!TUTORIAL_ACTION_TARGETS.includes(target))throw Object.assign(new TypeError('快捷操作目标无效'),{statusCode:400});
  return {label:text(value.label,'快捷操作文案',80),target};
}

export function validateTutorialDraft(value){
  const input=value&&typeof value==='object'&&!Array.isArray(value)?value:{};
  const category=text(input.category,'教程分类',80);
  if(!TUTORIAL_CATEGORIES.includes(category))throw Object.assign(new TypeError('请选择与智能体超市相同的教程分类'),{statusCode:400});
  const status=text(input.status??'draft','发布状态',20);
  if(!['draft','published','unpublished'].includes(status))throw Object.assign(new TypeError('发布状态无效'),{statusCode:400});
  const sortOrder=Number(input.sortOrder??0);
  if(!Number.isSafeInteger(sortOrder)||sortOrder<-100000||sortOrder>100000)throw Object.assign(new TypeError('排序必须是 -100000 到 100000 的整数'),{statusCode:400});
  const slug=text(input.slug,'教程标识',80).toLowerCase();
  if(!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug))throw Object.assign(new TypeError('教程标识只能使用小写英文、数字和中划线'),{statusCode:400});
  const body=text(input.body,'教程正文',30000,{required:false});
  const normalizedSteps=steps(input.steps);
  const images=tutorialImages(input.images);
  if(!body&&!normalizedSteps.length&&!images.length)throw Object.assign(new Error('请填写教程正文、操作步骤或上传图片'),{statusCode:400});
  if(images.length+normalizedSteps.reduce((sum,item)=>sum+(item.images?.length||0),0)>40)throw Object.assign(new Error('一篇教程最多 40 张图片'),{statusCode:400});
  return {
    slug,category,title:text(input.title,'教程标题',160),
    summary:text(input.summary,'教程简介',500),duration:text(input.duration??'约 3 分钟','预计时长',40),
    body,images,preparation:stringList(input.preparation,'开始前准备'),steps:normalizedSteps,tips:stringList(input.tips,'注意事项'),
    completion:stringList(input.completion,'完成标准'),action:action(input.action),sortOrder,status
  };
}

export function tutorialView(row){
  return {
    id:row.id,slug:row.slug,category:row.category,categoryName:row.category_name||'',title:row.title,summary:row.summary,duration:row.duration,
    body:row.body||'',images:Array.isArray(row.images)?row.images:[],
    preparation:Array.isArray(row.preparation)?row.preparation:[],steps:Array.isArray(row.steps)?row.steps:[],
    tips:Array.isArray(row.tips)?row.tips:[],completion:Array.isArray(row.completion)?row.completion:[],
    action:row.action&&typeof row.action==='object'?row.action:null,sortOrder:Number(row.sort_order)||0,status:row.status,
    createdAt:row.created_at,updatedAt:row.updated_at,publishedAt:row.published_at
  };
}
