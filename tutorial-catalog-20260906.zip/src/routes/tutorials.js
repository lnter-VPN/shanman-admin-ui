import {query,withTransaction} from '../db.js';
import {tutorialView,validateTutorialDraft,TUTORIAL_CATALOG} from '../tutorials.js';
import {requireAdvancedCategoryPassword} from '../marketplace-utils.js';
import fs from 'node:fs/promises';
import {config} from '../config.js';
import {readTutorialImage,saveTutorialImage,tutorialImagePath} from '../tutorial-images.js';

const UUID_RE=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
function tutorialId(value){const result=String(value||'').trim();if(!UUID_RE.test(result))throw Object.assign(new TypeError('教程 id 无效'),{statusCode:400});return result}
async function audit(tx,userId,action,entityId,metadata={}){await tx('INSERT INTO audit_logs(user_id,action,entity_type,entity_id,metadata) VALUES($1,$2,$3,$4,$5)',[userId,action,'tutorials',entityId,metadata])}
async function validateReferences(tx,draft){
  const category=await tx('SELECT id FROM tutorial_categories WHERE id=$1',[draft.category]);
  if(!category.rowCount)throw Object.assign(new Error('所选分类不存在，请先创建分类'),{statusCode:400});
  const filenames=[...new Set([...draft.images,...draft.steps.flatMap(step=>step.images||[])].map(image=>image.url.split('/').pop()))];
  if(filenames.length){const found=await tx('SELECT filename FROM tutorial_images WHERE filename=ANY($1::text[])',[filenames]);if(found.rowCount!==filenames.length)throw Object.assign(new Error('部分图片不存在，请重新上传'),{statusCode:400})}
}

export default async function tutorialRoutes(app){
  app.get('/api/admin/tutorial-categories',{preHandler:app.requireAdmin},async()=>({items:TUTORIAL_CATALOG}));
  const fixedCategories=async(_req,reply)=>reply.code(409).send({error:'教程分类与智能体超市、技能统一，请从现有分类中选择'});
  app.post('/api/admin/tutorial-categories',{preHandler:app.requireAdmin},fixedCategories);
  app.patch('/api/admin/tutorial-categories/:id',{preHandler:app.requireAdmin},fixedCategories);
  app.post('/api/admin/tutorial-images',{preHandler:app.requireAdmin},async(req,reply)=>{
    const image=await readTutorialImage(req);const target=await saveTutorialImage(config.storagePath,image);
    try{await withTransaction(async tx=>{await tx('INSERT INTO tutorial_images(filename,content_type,size_bytes,created_by) VALUES($1,$2,$3,$4)',[image.filename,image.contentType,image.size,req.user.sub]);await audit(tx,req.user.sub,'tutorials.image.upload',null,{filename:image.filename,size:image.size})})}
    catch(error){await fs.unlink(target).catch(()=>{});throw error}
    return reply.code(201).send({url:`/api/tutorial-images/${image.filename}`,caption:'',size:image.size});
  });
  const serveImage=admin=>async(req,reply)=>{
    const filename=req.params.filename;const target=tutorialImagePath(config.storagePath,filename);const url=`/api/tutorial-images/${filename}`;
    const result=await query('SELECT filename,content_type FROM tutorial_images WHERE filename=$1',[filename]);
    if(!result.rowCount)return reply.code(404).send({error:'图片不存在'});
    if(!admin){
      const references=await query(`SELECT id FROM tutorials WHERE status='published' AND
        (images @> $1::jsonb OR EXISTS (SELECT 1 FROM jsonb_array_elements(steps) step WHERE step->'images' @> $1::jsonb)) LIMIT 1`,[JSON.stringify([{url}])]);
      if(!references.rowCount)return reply.code(404).send({error:'图片未发布'});
    }
    try{const bytes=await fs.readFile(target);reply.header('cache-control','no-store').header('x-content-type-options','nosniff').header('content-security-policy',"default-src 'none'");return reply.type(result.rows[0].content_type).send(bytes)}
    catch(error){if(error.code==='ENOENT')return reply.code(404).send({error:'图片文件不存在'});throw error}
  };
  app.get('/api/admin/tutorial-images/:filename',{preHandler:app.requireAdmin},serveImage(true));
  app.get('/api/tutorial-images/:filename',serveImage(false));
  app.get('/api/tutorials',async(_request,reply)=>{
    reply.header('cache-control','no-store, max-age=0');
    const result=await query("SELECT * FROM tutorials WHERE status='published' ORDER BY category,sort_order,updated_at DESC,id");
    const categories=TUTORIAL_CATALOG;
    return {items:result.rows.map(row=>tutorialView({...row,category_name:categories.find(item=>item.id===row.category)?.name})),categories:categories.filter(item=>result.rows.some(row=>row.category===item.id))};
  });

  app.get('/api/admin/tutorials',{preHandler:app.requireAdmin},async()=>{
    const result=await query('SELECT * FROM tutorials ORDER BY updated_at DESC,id');
    const categories=TUTORIAL_CATALOG;
    return {items:result.rows.map(row=>tutorialView({...row,category_name:categories.find(item=>item.id===row.category)?.name})),categories};
  });

  app.post('/api/admin/tutorials',{preHandler:app.requireAdmin},async(req,reply)=>{
    const draft=validateTutorialDraft(req.body);
    requireAdvancedCategoryPassword(draft.category==='advanced'?'高级':'通用',req.body?.advancedCategoryPassword);
    try{
      const created=await withTransaction(async tx=>{
        await validateReferences(tx,draft);
        const result=await tx(`INSERT INTO tutorials
          (slug,category,title,summary,duration,preparation,steps,tips,completion,action,sort_order,status,created_by,published_at,body,images)
          VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,CASE WHEN $12='published' THEN now() ELSE NULL END,$14,$15) RETURNING *`,
          [draft.slug,draft.category,draft.title,draft.summary,draft.duration,JSON.stringify(draft.preparation),JSON.stringify(draft.steps),JSON.stringify(draft.tips),JSON.stringify(draft.completion),draft.action,draft.sortOrder,draft.status,req.user.sub,draft.body,JSON.stringify(draft.images)]);
        await audit(tx,req.user.sub,'tutorials.create',result.rows[0].id,{slug:draft.slug,status:draft.status});
        return result.rows[0];
      });
      return reply.code(201).send(tutorialView(created));
    }catch(error){if(error?.code==='23505')throw Object.assign(new Error('教程标识已存在'),{statusCode:409});throw error}
  });

  app.patch('/api/admin/tutorials/:id',{preHandler:app.requireAdmin},async(req,reply)=>{
    const id=tutorialId(req.params.id);
    const current=await query('SELECT * FROM tutorials WHERE id=$1',[id]);
    if(!current.rowCount)return reply.code(404).send({error:'教程不存在'});
    const row=tutorialView(current.rows[0]);
    const draft=validateTutorialDraft({...row,...(req.body||{})});
    requireAdvancedCategoryPassword(draft.category==='advanced'?'高级':'通用',req.body?.advancedCategoryPassword);
    try{
      const updated=await withTransaction(async tx=>{
        await validateReferences(tx,draft);
        const result=await tx(`UPDATE tutorials SET slug=$1,category=$2,title=$3,summary=$4,duration=$5,preparation=$6,
          steps=$7,tips=$8,completion=$9,action=$10,sort_order=$11,status=$12,
          body=$14,images=$15,published_at=CASE WHEN $12='published' THEN COALESCE(published_at,now()) ELSE published_at END,updated_at=now()
          WHERE id=$13 RETURNING *`,[draft.slug,draft.category,draft.title,draft.summary,draft.duration,JSON.stringify(draft.preparation),JSON.stringify(draft.steps),JSON.stringify(draft.tips),JSON.stringify(draft.completion),draft.action,draft.sortOrder,draft.status,id,draft.body,JSON.stringify(draft.images)]);
        await audit(tx,req.user.sub,'tutorials.update',id,{slug:draft.slug,status:draft.status});return result.rows[0];
      });
      return tutorialView(updated);
    }catch(error){if(error?.code==='23505')throw Object.assign(new Error('教程标识已存在'),{statusCode:409});throw error}
  });

  app.post('/api/admin/tutorials/:id/status',{preHandler:app.requireAdmin},async(req,reply)=>{
    const id=tutorialId(req.params.id);const status=String(req.body?.status||'');
    if(!['draft','published','unpublished'].includes(status))return reply.code(400).send({error:'发布状态无效'});
    if(status==='published'){
      const current=await query('SELECT * FROM tutorials WHERE id=$1',[id]);
      if(!current.rowCount)return reply.code(404).send({error:'教程不存在'});
      requireAdvancedCategoryPassword(current.rows[0].category==='advanced'?'高级':'通用',req.body?.advancedCategoryPassword);
    }
    const updated=await withTransaction(async tx=>{
      const result=await tx(`UPDATE tutorials SET status=$1,published_at=CASE WHEN $1='published' THEN COALESCE(published_at,now()) ELSE published_at END,updated_at=now() WHERE id=$2 RETURNING *`,[status,id]);
      if(result.rowCount)await audit(tx,req.user.sub,`tutorials.${status==='published'?'publish':'unpublish'}`,id,{status});return result.rows[0]||null;
    });
    if(!updated)return reply.code(404).send({error:'教程不存在'});return tutorialView(updated);
  });

  app.delete('/api/admin/tutorials/:id',{preHandler:app.requireAdmin},async(req,reply)=>{
    const id=tutorialId(req.params.id);
    const removed=await withTransaction(async tx=>{const result=await tx('DELETE FROM tutorials WHERE id=$1 RETURNING id,slug',[id]);if(result.rowCount)await audit(tx,req.user.sub,'tutorials.delete',id,{slug:result.rows[0].slug});return result.rows[0]||null});
    if(!removed)return reply.code(404).send({error:'教程不存在'});return {ok:true,id};
  });
}
