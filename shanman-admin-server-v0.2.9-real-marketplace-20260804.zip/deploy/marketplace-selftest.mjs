import crypto from 'node:crypto';

const baseUrl = process.env.SELFTEST_BASE_URL || 'http://127.0.0.1:8080';
const identifier = process.env.ADMIN_EMAIL || process.env.ADMIN_USERNAME;
const password = process.env.ADMIN_PASSWORD;
if (!identifier || !password) throw new Error('生产闭环测试缺少管理员环境变量');

async function request(path, { token, ...init } = {}) {
  const multipart = typeof FormData !== 'undefined' && init.body instanceof FormData;
  const response = await fetch(`${baseUrl}${path}`, {
    ...init,
    headers: {
      ...(multipart ? {} : init.body === undefined ? {} : { 'content-type': 'application/json' }),
      ...(token ? { authorization: `Bearer ${token}` } : {}),
      ...(init.headers || {})
    }
  });
  const text = await response.text();
  let body; try { body = text ? JSON.parse(text) : {}; } catch { body = { error: text }; }
  if (!response.ok) throw new Error(`${init.method || 'GET'} ${path} -> ${response.status}: ${body.error || text}`);
  return body;
}

const login = await request('/api/auth/login', {
  method: 'POST', body: JSON.stringify({ identifier, password })
});
const token = login.token;
const suffix = `${Date.now().toString(36)}-${crypto.randomBytes(3).toString('hex')}`;
let skill; let agent;

async function exists(type, id) {
  if (!id) return false;
  try { await request(`/api/admin/${type}/${id}`, { token }); return true; } catch { return false; }
}

async function destroy(type, product) {
  if (!product?.id || !(await exists(type, product.id))) return;
  await request(`/api/admin/${type}/${product.id}/permanent?confirm=${encodeURIComponent(product.slug)}`, { token, method: 'DELETE' });
}

try {
  const upload = new FormData();
  upload.append('publishMode', 'published');
  upload.append('skillName', '生命周期闭环测试技能');
  upload.append('skillSlug', `lifecycle-skill-${suffix}`);
  upload.append('skillCategory', '自动验收');
  upload.append('skillVersion', '1.0.0');
  upload.append('skillSummary', '验证文件上传、上架、下架和删除');
  upload.append('skillDescription', '该记录由生产部署自检创建并自动清理');
  upload.append('skillChangelog', '生产闭环测试');
  upload.append('package', new Blob([JSON.stringify({
    manifest: { type: 'skill', slug: 'must-be-overridden', name: '包内旧名称', version: '0.0.1' },
    skillMarkdown: '# 生命周期闭环测试技能\n\n所有结论必须可以核验。'
  })], { type: 'application/json' }), 'skill.json');
  const uploaded = await request('/api/admin/skills/upload', { token, method: 'POST', body: upload });
  skill = uploaded.product;
  if (skill.status !== 'published' || skill.name !== '生命周期闭环测试技能' || skill.slug !== `lifecycle-skill-${suffix}`) {
    throw new Error('技能上传覆盖字段或直接上架未真实写入');
  }
  if (!(await request('/api/marketplace/skills')).items.some((item) => item.id === skill.id)) throw new Error('技能上架后公共目录不可见');

  agent = await request('/api/admin/agents', { token, method: 'POST', body: JSON.stringify({
    slug: `lifecycle-agent-${suffix}`, name: '生命周期闭环测试智能体', category: '自动验收',
    role: '生产生命周期与数据一致性验证员', summary: '验证一句话简介真实同步', description: '该记录由生产部署自检创建并自动清理',
    icon: 'bot', avatar: '', version: '1.0.0', status: 'published',
    systemPrompt: '你是生产生命周期验证员，只报告真实可核验的数据。', welcomeMessage: '开始验证',
    workspace: { goal: '验证完整发布链路', roleRules: '不得虚构', outputDirectory: 'outputs', memoryEnabled: true, allowWeb: false, allowFiles: true, allowTerminal: false },
    skillIds: [skill.id], changelog: '生产闭环测试'
  }) });
  const agentPublic = (await request('/api/marketplace/agents')).items.find((item) => item.id === agent.id);
  if (!agentPublic) throw new Error('智能体上架后公共目录不可见');
  const agentVersion = await request(`/api/marketplace/agents/${agent.id}/versions/${agentPublic.latestVersion.version}`);
  if (agentVersion.manifest.role !== '生产生命周期与数据一致性验证员' || agentVersion.manifest.summary !== '验证一句话简介真实同步') {
    throw new Error('智能体角色或一句话简介未进入公共 manifest');
  }

  const down = await request(`/api/admin/skills/${skill.id}/unpublish`, { token, method: 'POST' });
  if (down.status !== 'unpublished') throw new Error('技能下架状态未写入');
  if ((await request('/api/marketplace/skills')).items.some((item) => item.id === skill.id)) throw new Error('技能下架后仍在公共目录');
  const agentAfterDown = await request(`/api/admin/agents/${agent.id}`, { token });
  if (agentAfterDown.status !== 'published') throw new Error('技能下架错误级联修改了智能体');

  await request(`/api/admin/skills/${skill.id}/publish`, { token, method: 'POST' });
  const deletedSkill = await request(`/api/admin/skills/${skill.id}/permanent?confirm=${encodeURIComponent(skill.slug)}`, { token, method: 'DELETE' });
  if (!deletedSkill.permanentlyDeleted || !deletedSkill.affectedAgents.includes(agent.id)) throw new Error('技能真实删除或依赖解绑失败');
  skill = null;
  const agentAfterDelete = await request(`/api/admin/agents/${agent.id}`, { token });
  if (agentAfterDelete.status !== 'published' || agentAfterDelete.skillIds.length !== 0 || agentAfterDelete.latestVersion.manifest.skills.length !== 0) {
    throw new Error('技能删除后智能体状态或 manifest 不一致');
  }

  await destroy('agents', agent); agent = null;
  console.log('PRODUCTION_MARKETPLACE_E2E_OK role summary upload publish unpublish direct-delete dependency-detach');
} finally {
  await destroy('skills', skill).catch(() => {});
  await destroy('agents', agent).catch(() => {});
}
