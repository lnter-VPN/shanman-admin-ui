export default async function healthRoutes(app) {
  app.get('/health', async () => ({ ok: true, service: 'shanman-api', version: '0.2.9', time: new Date().toISOString() }));
}
