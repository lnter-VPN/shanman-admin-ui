import { query } from '../db.js';

export async function requireAuth(request, reply) {
  try { await request.jwtVerify(); }
  catch { return reply.code(401).send({ error: '未登录或登录已过期' }); }
}

export function makeRequireAdmin(queryFn = query) {
  return async function requireAdminHandler(request, reply) {
    await requireAuth(request, reply);
    if (reply.sent) return;
    const result = await queryFn('SELECT role FROM users WHERE id=$1', [request.user?.sub]);
    if (!result.rowCount) return reply.code(401).send({ error: '用户不存在或已停用' });
    if (result.rows[0].role !== 'admin') return reply.code(403).send({ error: '需要管理员权限' });
  };
}

export const requireAdmin = makeRequireAdmin();
