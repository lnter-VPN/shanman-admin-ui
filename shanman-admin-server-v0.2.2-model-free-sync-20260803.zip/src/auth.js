﻿import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
import { query } from './db.js';

export const normalizeEmail = (email) => String(email || '').trim().toLowerCase();
export const normalizeUsername = (username) => String(username || '').trim().toLowerCase();
export const hashPassword = (password) => bcrypt.hash(password, 12);
export const verifyPassword = (password, hash) => bcrypt.compare(password, hash);
export const hashToken = (token) => crypto.createHash('sha256').update(token).digest('hex');

export async function ensureAdmin(config, queryFn = query) {
  if (!config.adminEmail || !config.adminPassword) return;
  const username = normalizeUsername(config.adminUsername || 'admin') || 'admin';
  const hash = await hashPassword(config.adminPassword);
  await queryFn(`INSERT INTO users(username,email,password_hash,role) VALUES($1,$2,$3,'admin')
    ON CONFLICT(email) DO UPDATE SET username=EXCLUDED.username,password_hash=EXCLUDED.password_hash,role='admin'`, [username, config.adminEmail, hash]);
}


