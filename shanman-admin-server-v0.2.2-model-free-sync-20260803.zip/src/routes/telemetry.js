import crypto from 'node:crypto';
import { query, withTransaction } from '../db.js';

export const TELEMETRY_EVENTS = new Set(['app_started', 'agent_created', 'agent_installed', 'skill_enabled', 'skill_disabled', 'chat_completed', 'chat_failed', 'channel_connected', 'channel_failed']);
const PROPERTY_KEYS = new Set(['appVersion', 'source', 'target', 'agentType', 'templateId', 'skillId', 'skillSource', 'provider', 'engine', 'channel', 'latencyBucket', 'errorCode']);
const FORBIDDEN_KEY = /(chat|message|prompt|content|api.?key|token|secret|password|credential)/i;

const bad = (message) => Object.assign(new TypeError(message), { statusCode: 400 });

export function installationHash(value) { return crypto.createHash('sha256').update(value).digest('hex'); }

export function validateTelemetryPayload(body, now = Date.now()) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) throw bad('body 必须是 JSON 对象');
  if (Object.keys(body).some((key) => !['installationId', 'events'].includes(key))) throw bad('body 含有未允许字段');
  const installationId = String(body.installationId || '');
  if (!/^[A-Za-z0-9._:-]{1,64}$/.test(installationId)) throw bad('installationId 必须是 1-64 位安全字符');
  if (!Array.isArray(body.events) || body.events.length < 1 || body.events.length > 50) throw bad('events 必须包含 1-50 条事件');
  const ids = new Set();
  const events = body.events.map((event) => {
    if (!event || typeof event !== 'object' || Array.isArray(event)) throw bad('事件格式无效');
    if (Object.keys(event).some((key) => !['id', 'name', 'occurredAt', 'properties'].includes(key))) throw bad('事件含有未允许字段');
    const id = String(event.id || ''); const name = String(event.name || '');
    if (!/^[A-Za-z0-9._:-]{1,64}$/.test(id)) throw bad('事件 id 必须是 1-64 位安全字符');
    if (ids.has(id)) throw bad('同一批次事件 id 不能重复'); ids.add(id);
    if (!TELEMETRY_EVENTS.has(name)) throw bad('事件 name 不受支持');
    const occurredMs = Date.parse(event.occurredAt);
    if (!Number.isFinite(occurredMs) || typeof event.occurredAt !== 'string') throw bad('occurredAt 必须是 ISO 时间');
    if (occurredMs > now + 5 * 60_000 || occurredMs < now - 90 * 86400_000) throw bad('occurredAt 超出允许时间范围');
    const properties = event.properties ?? {};
    if (!properties || typeof properties !== 'object' || Array.isArray(properties)) throw bad('properties 必须是对象');
    const entries = Object.entries(properties);
    if (entries.length > 16) throw bad('properties 字段过多');
    for (const [key, value] of entries) {
      if (!PROPERTY_KEYS.has(key) || FORBIDDEN_KEY.test(key)) throw bad(`properties.${key} 不允许上报`);
      const validNumber = typeof value === 'number' && Number.isFinite(value) && Math.abs(value) <= 1_000_000;
      const validString = typeof value === 'string' && value.length <= 120 && !/[\r\n\0]/.test(value);
      if (typeof value !== 'boolean' && !validNumber && !validString) throw bad(`properties.${key} 仅允许短字符串、有限数字或布尔值`);
    }
    return { id, name, occurredAt: new Date(occurredMs).toISOString(), properties };
  });
  return { installationHash: installationHash(installationId), events };
}

export async function optionalTelemetryAuth(request, reply) {
  const authorization = request.headers.authorization;
  if (!authorization) { request.user = null; return; }
  if (!authorization.startsWith('Bearer ')) return reply.code(401).send({ error: 'Authorization 格式无效' });
  try { await request.jwtVerify(); } catch { return reply.code(401).send({ error: '登录已过期' }); }
}

export function createTelemetryHandler({ queryFn = query, transactionFn = withTransaction } = {}) {
  return async function telemetryHandler(request, reply) {
    const payload = validateTelemetryPayload(request.body);
    let userId = request.user?.sub || null;
    if (userId) {
      const user = await queryFn('SELECT id FROM users WHERE id=$1', [userId]);
      if (!user.rowCount) return reply.code(401).send({ error: '用户不存在' });
    }
    const accepted = await transactionFn(async (tx) => {
      let count = 0;
      for (const event of payload.events) {
        const result = await tx(`INSERT INTO telemetry_events(installation_hash,event_id,user_id,name,occurred_at,properties)
          VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT(installation_hash,event_id) DO NOTHING`,
        [payload.installationHash, event.id, userId, event.name, event.occurredAt, event.properties]);
        count += result.rowCount;
      }
      return count;
    });
    return reply.code(202).send({ accepted });
  };
}

export default async function telemetryRoutes(app) {
  app.post('/api/telemetry/events', { preHandler: optionalTelemetryAuth }, createTelemetryHandler());
}
