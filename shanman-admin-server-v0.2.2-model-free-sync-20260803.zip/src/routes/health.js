export default async function healthRoutes(app) {
  app.get('/health', async () => ({ ok: true, service: 'shanman-api', time: new Date().toISOString() }));
}
