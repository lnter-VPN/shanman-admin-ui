import pg from 'pg';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { config } from './config.js';

const { Pool } = pg;
export const pool = new Pool({ connectionString: config.databaseUrl, max: 10 });

export async function migrate() {
  const here = path.dirname(fileURLToPath(import.meta.url));
  const dir = path.join(here, '..', 'migrations');
  const files = (await fs.readdir(dir)).filter((file) => file.endsWith('.sql')).sort();
  await pool.query('CREATE TABLE IF NOT EXISTS schema_migrations (filename TEXT PRIMARY KEY, applied_at TIMESTAMPTZ NOT NULL DEFAULT now())');
  for (const file of files) {
    const existing = await pool.query('SELECT 1 FROM schema_migrations WHERE filename=$1', [file]);
    if (existing.rowCount) continue;
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      // PostgreSQL treats an UTF-8 BOM as part of the first token. Strip it so
      // migrations saved by Windows editors cannot crash production startup.
      const sql = (await fs.readFile(path.join(dir, file), 'utf8')).replace(/^\uFEFF/, '');
      await client.query(sql);
      await client.query('INSERT INTO schema_migrations(filename) VALUES($1)', [file]);
      await client.query('COMMIT');
    } catch (error) { await client.query('ROLLBACK'); throw error; }
    finally { client.release(); }
  }
}

export async function query(text, params) { return pool.query(text, params); }

export async function withTransaction(operation) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await operation((text, params) => client.query(text, params));
    await client.query('COMMIT');
    return result;
  } catch (error) { await client.query('ROLLBACK'); throw error; }
  finally { client.release(); }
}
