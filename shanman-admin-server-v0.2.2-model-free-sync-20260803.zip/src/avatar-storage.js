import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { resolveStoragePath } from './package-upload.js';

export const MAX_AVATAR_BYTES = 3 * 1024 * 1024;
const AVATAR_FILE_RE = /^agent-[0-9a-f-]{36}\.(?:png|jpe?g|webp)$/i;

export function detectAvatarImage(buffer) {
  if (!Buffer.isBuffer(buffer) || buffer.length < 12) return null;
  if (buffer.subarray(0, 8).equals(Buffer.from([0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a]))) {
    return { extension: 'png', contentType: 'image/png' };
  }
  if (buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) {
    return { extension: 'jpg', contentType: 'image/jpeg' };
  }
  if (buffer.subarray(0, 4).toString('ascii') === 'RIFF' && buffer.subarray(8, 12).toString('ascii') === 'WEBP') {
    return { extension: 'webp', contentType: 'image/webp' };
  }
  return null;
}

export function validateAvatarFilename(value) {
  const filename = String(value || '').trim();
  if (!AVATAR_FILE_RE.test(filename)) throw Object.assign(new TypeError('头像文件名无效'), { statusCode: 400 });
  return filename;
}

export function avatarRelativePath(filename) {
  return `avatars/${validateAvatarFilename(filename)}`;
}

export function avatarPublicUrl(filename) {
  return `/api/marketplace/assets/avatars/${validateAvatarFilename(filename)}`;
}

export async function storeAgentAvatar(buffer, storagePath) {
  if (!Buffer.isBuffer(buffer) || !buffer.length) throw Object.assign(new TypeError('请选择头像图片'), { statusCode: 400 });
  if (buffer.length > MAX_AVATAR_BYTES) throw Object.assign(new TypeError('头像不能超过 3MB'), { statusCode: 413 });
  const format = detectAvatarImage(buffer);
  if (!format) throw Object.assign(new TypeError('头像仅支持真实的 PNG、JPG 或 WEBP 图片'), { statusCode: 415 });
  const filename = `agent-${crypto.randomUUID()}.${format.extension}`;
  const relativePath = avatarRelativePath(filename);
  const absolutePath = resolveStoragePath(storagePath, relativePath);
  await fs.mkdir(path.dirname(absolutePath), { recursive: true });
  await fs.writeFile(absolutePath, buffer, { mode: 0o600 });
  return { filename, relativePath, url: avatarPublicUrl(filename), contentType: format.contentType, size: buffer.length };
}
