import fastifyStatic from '@fastify/static';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export default async function registerAdminStatic(app, { root } = {}) {
  const here = path.dirname(fileURLToPath(import.meta.url));
  const staticRoot = path.resolve(root || path.join(here, '..', 'public', 'admin'));
  app.get('/admin', async (_request, reply) => reply.redirect('/admin/'));
  await app.register(fastifyStatic, {
    root: staticRoot,
    prefix: '/admin/',
    redirect: true,
    serveDotFiles: false,
    index: ['index.html'],
    setHeaders(reply, filePath) {
      reply.header('x-content-type-options', 'nosniff');
      reply.header('referrer-policy', 'no-referrer');
      reply.header('x-frame-options', 'DENY');
      reply.header('permissions-policy', 'camera=(), microphone=(), geolocation=()');
      reply.header('content-security-policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
      reply.header('cache-control', filePath.endsWith('.html') ? 'no-store' : 'public, max-age=3600');
    }
  });
}
