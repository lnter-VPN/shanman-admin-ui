import crypto from 'node:crypto';
import fs from 'node:fs';

export const CLIENT_PUBLIC_KEY_PEM = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAS4hgFiP7YcpscdEPBy68vBa+hON39EsyRabSXBvoz4g=
-----END PUBLIC KEY-----`;

const b64url = (value) => Buffer.from(value).toString('base64url');
const decode = (value) => Buffer.from(value, 'base64url');
const normalizePem = (value) => String(value || '').replace(/\\n/g, '\n').trim();

export function loadPrivateKey(config) {
  if (config.licensePrivateKeyPem) return normalizePem(config.licensePrivateKeyPem);
  if (config.licensePrivateKeyPath) return fs.readFileSync(config.licensePrivateKeyPath, 'utf8').trim();
  return '';
}

export function publicKeyFingerprint(pem) {
  const key = pem instanceof crypto.KeyObject && pem.type === 'public' ? pem : crypto.createPublicKey(pem);
  const der = key.export({ type: 'spki', format: 'der' });
  return crypto.createHash('sha256').update(der).digest('hex');
}

export function createLicenseAuthority({ privateKeyPem = '', publicKeyPem = CLIENT_PUBLIC_KEY_PEM } = {}) {
  const publicKey = crypto.createPublicKey(normalizePem(publicKeyPem));
  const privateKey = privateKeyPem ? crypto.createPrivateKey(normalizePem(privateKeyPem)) : null;
  if (privateKey) {
    const derived = crypto.createPublicKey(privateKey);
    const expected = publicKey.export({ type: 'spki', format: 'der' });
    const actual = derived.export({ type: 'spki', format: 'der' });
    if (expected.length !== actual.length || !crypto.timingSafeEqual(expected, actual)) throw new Error('授权私钥与客户端内置公钥不匹配');
  }
  return {
    canSign: Boolean(privateKey),
    publicKeyFingerprint: publicKeyFingerprint(publicKey),
    sign(payload) {
      if (!privateKey) throw Object.assign(new Error('服务器未配置授权签名私钥'), { statusCode: 503 });
      const normalized = validateLicensePayload(payload);
      const payloadPart = b64url(JSON.stringify(normalized));
      return `${payloadPart}.${b64url(crypto.sign(null, Buffer.from(payloadPart), privateKey))}`;
    },
    verify(key, nowMs = Date.now()) {
      if (typeof key !== 'string' || key.length > 8192) return { ok: false, reason: '授权 Key 格式无效' };
      const parts = key.trim().split('.');
      if (parts.length !== 2 || !parts[0] || !parts[1]) return { ok: false, reason: '授权 Key 格式无效' };
      let payload;
      try { payload = JSON.parse(decode(parts[0]).toString('utf8')); } catch { return { ok: false, reason: '授权 Key 内容无法解析' }; }
      let valid = false;
      try { valid = crypto.verify(null, Buffer.from(parts[0]), publicKey, decode(parts[1])); } catch { valid = false; }
      if (!valid) return { ok: false, reason: '授权 Key 签名无效' };
      try { payload = validateLicensePayload(payload); } catch (error) { return { ok: false, reason: error.message }; }
      if (payload.exp > 0 && nowMs / 1000 > payload.exp) return { ok: false, reason: '授权 Key 已过期' };
      return { ok: true, payload };
    }
  };
}

export function validateMachineFingerprint(value) {
  const fingerprint = String(value || '').trim().toLowerCase();
  if (!/^[a-f0-9]{32}$/.test(fingerprint)) throw Object.assign(new TypeError('deviceFingerprint 必须是 32 位机器码'), { statusCode: 400 });
  return fingerprint;
}

export function validateLicensePayload(payload) {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) throw new TypeError('授权载荷无效');
  const sub = String(payload.sub || '').trim(); const name = String(payload.name || '').trim();
  const exp = Number(payload.exp); const ver = String(payload.ver || '').trim();
  if (!sub || sub.length > 128) throw new TypeError('授权主体无效');
  if (!name || name.length > 200) throw new TypeError('授权名称无效');
  if (!Number.isSafeInteger(exp) || exp < 0) throw new TypeError('授权有效期无效');
  if (ver !== 'shanman-ai-platform:1') throw new TypeError('授权版本不受支持');
  const result = { sub, name, exp, ver };
  if (payload.machine) result.machine = validateMachineFingerprint(payload.machine);
  return result;
}

export function expiryFromRequest(body, nowMs = Date.now()) {
  if (body?.permanent === true) return { exp: 0, expiresAt: null };
  if (body?.expiresAt) {
    const date = new Date(body.expiresAt);
    if (!Number.isFinite(date.getTime()) || date.getTime() <= nowMs) throw Object.assign(new TypeError('expiresAt 必须是未来时间'), { statusCode: 400 });
    return { exp: Math.floor(date.getTime() / 1000), expiresAt: date.toISOString() };
  }
  const days = Number(body?.days);
  if (!Number.isInteger(days) || days < 1 || days > 36500) throw Object.assign(new TypeError('days 必须是 1 到 36500 的整数；永久授权需显式传 permanent=true'), { statusCode: 400 });
  const exp = Math.floor(nowMs / 1000) + days * 86400;
  return { exp, expiresAt: new Date(exp * 1000).toISOString() };
}
