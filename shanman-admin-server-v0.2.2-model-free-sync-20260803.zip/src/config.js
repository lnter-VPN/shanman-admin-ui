﻿import 'dotenv/config';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const serverRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

export const config = {
  nodeEnv: process.env.NODE_ENV || 'development',
  port: Number(process.env.PORT || 8080),
  databaseUrl: process.env.DATABASE_URL || 'postgres://shanman:shanman@localhost:5432/shanman',
  jwtSecret: process.env.JWT_SECRET || 'dev-only-change-me',
  adminUsername: String(process.env.ADMIN_USERNAME || 'admin').trim().toLowerCase(),
  adminEmail: String(process.env.ADMIN_EMAIL || '').trim().toLowerCase(),
  adminPassword: process.env.ADMIN_PASSWORD || '',
  webOrigin: process.env.WEB_ORIGIN || '*',
  adminStaticRoot: path.resolve(process.env.ADMIN_STATIC_ROOT || path.join(serverRoot, 'public', 'admin')),
  storagePath: path.resolve(process.env.STORAGE_PATH || path.join(serverRoot, 'storage')),
  licensePrivateKeyPem: process.env.LICENSE_PRIVATE_KEY_PEM || '',
  licensePrivateKeyPath: process.env.LICENSE_PRIVATE_KEY_PATH || '',
  licensePublicKeyPem: process.env.LICENSE_PUBLIC_KEY_PEM || ''
};

if (config.nodeEnv === 'production') {
  const placeholder = (value) => /change[-_ ]?me|replace[-_ ]?with|dev[-_ ]?only/i.test(String(value || ''));
  if (config.jwtSecret.length < 32 || placeholder(config.jwtSecret)) throw new Error('JWT_SECRET must be a non-placeholder secret of at least 32 characters in production');
  if (!config.adminEmail || !/^\S+@\S+\.\S+$/.test(config.adminEmail)) throw new Error('ADMIN_EMAIL must be configured in production');
  if (!config.adminPassword || config.adminPassword.length < 8 || placeholder(config.adminPassword)) throw new Error('ADMIN_PASSWORD must be a non-placeholder password of at least 8 characters in production');
  if (placeholder(config.databaseUrl) || /postgres:\/\/shanman:shanman@/i.test(config.databaseUrl)) throw new Error('DATABASE_URL must not use placeholder credentials in production');
}
if (config.nodeEnv !== 'test' && config.licensePublicKeyPem) {
  throw new Error('LICENSE_PUBLIC_KEY_PEM is test-only; production must use the public key embedded in the desktop client');
}

