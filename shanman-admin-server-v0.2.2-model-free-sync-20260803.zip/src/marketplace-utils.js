import crypto from 'node:crypto';

const VERSION_RE = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/;
const SLUG_RE = /^[a-z0-9](?:[a-z0-9-]{0,62}[a-z0-9])?$/;

export function assertProductType(type) {
  if (type !== 'agents' && type !== 'skills') throw Object.assign(new TypeError('市场类型无效'), { statusCode: 400 });
  return type;
}

export function validateProductDraft(body, { partial = false } = {}) {
  const value = body && typeof body === 'object' && !Array.isArray(body) ? body : {};
  const result = {};
  if (!partial || value.slug !== undefined) {
    const slug = String(value.slug || '').trim().toLowerCase();
    if (!SLUG_RE.test(slug)) throw Object.assign(new TypeError('slug 需为 1-64 位小写英文、数字或连字符'), { statusCode: 400 });
    result.slug = slug;
  }
  for (const [field, max, required] of [['name', 120, true], ['summary', 500, false], ['description', 50_000, false]]) {
    if (partial && value[field] === undefined) continue;
    const text = String(value[field] ?? '').trim();
    if (required && !text) throw Object.assign(new TypeError(`${field} 必填`), { statusCode: 400 });
    if (text.length > max) throw Object.assign(new TypeError(`${field} 超过长度限制`), { statusCode: 400 });
    result[field] = text;
  }
  if (!partial || value.icon !== undefined) {
    const icon = String(value.icon || 'bot').trim();
    if (!icon || icon.length > 120) throw Object.assign(new TypeError('icon 无效'), { statusCode: 400 });
    result.icon = icon;
  }
  return result;
}

export function validateVersionDraft(body) {
  const value = body && typeof body === 'object' && !Array.isArray(body) ? body : {};
  const version = String(value.version || '').trim();
  if (!VERSION_RE.test(version)) throw Object.assign(new TypeError('version 必须使用 x.y.z 格式'), { statusCode: 400 });
  if (!value.manifest || typeof value.manifest !== 'object' || Array.isArray(value.manifest)) {
    throw Object.assign(new TypeError('manifest 必须是 JSON 对象'), { statusCode: 400 });
  }
  const canonical = canonicalJson(value.manifest);
  if (Buffer.byteLength(canonical, 'utf8') > 1024 * 1024) throw Object.assign(new TypeError('manifest 不能超过 1MB'), { statusCode: 413 });
  const changelog = String(value.changelog || '').trim();
  if (changelog.length > 20_000) throw Object.assign(new TypeError('changelog 不能超过 20000 字'), { statusCode: 400 });
  return { version, manifest: value.manifest, changelog, manifestSha256: sha256(canonical) };
}

export function canonicalJson(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(',')}]`;
  return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonicalJson(value[key])}`).join(',')}}`;
}

export function sha256(value) { return crypto.createHash('sha256').update(value).digest('hex'); }

export function compareVersions(left, right) {
  const a = String(left).split('.').map(Number); const b = String(right).split('.').map(Number);
  for (let index = 0; index < 3; index += 1) if (a[index] !== b[index]) return a[index] > b[index] ? 1 : -1;
  return 0;
}

export function assertVersionIsNewer(next, current) {
  if (current && compareVersions(next, current) <= 0) {
    throw Object.assign(new TypeError(`新版本 ${next} 必须高于当前版本 ${current}`), { statusCode: 409 });
  }
}

export function publicVersion(row, { includeManifest = true } = {}) {
  if (!row) return null;
  const manifestSha256 = row.manifest_sha256 || sha256(canonicalJson(row.manifest || {}));
  return {
    id: row.id, version: row.version, ...(includeManifest ? { manifest: row.manifest || {} } : {}),
    changelog: row.changelog || '', manifestSha256,
    ...(row.package_sha256 ? { packageSha256: row.package_sha256, packageSize: row.package_size, packageFormat: row.package_format } : {}),
    createdAt: row.created_at
  };
}
