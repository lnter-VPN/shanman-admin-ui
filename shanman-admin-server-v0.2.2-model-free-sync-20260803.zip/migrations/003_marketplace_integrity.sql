ALTER TABLE agent_product_versions ADD COLUMN IF NOT EXISTS manifest_sha256 TEXT;
ALTER TABLE skill_product_versions ADD COLUMN IF NOT EXISTS manifest_sha256 TEXT;
ALTER TABLE agent_products ADD COLUMN IF NOT EXISTS published_at TIMESTAMPTZ;
ALTER TABLE skill_products ADD COLUMN IF NOT EXISTS published_at TIMESTAMPTZ;
ALTER TABLE agent_products ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMPTZ;
ALTER TABLE skill_products ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMPTZ;

ALTER TABLE agent_products DROP CONSTRAINT IF EXISTS agent_products_status_check;
ALTER TABLE agent_products ADD CONSTRAINT agent_products_status_check CHECK (status IN ('draft','published','unpublished','deleted'));
ALTER TABLE skill_products DROP CONSTRAINT IF EXISTS skill_products_status_check;
ALTER TABLE skill_products ADD CONSTRAINT skill_products_status_check CHECK (status IN ('draft','published','unpublished','deleted'));

ALTER TABLE agent_product_versions DROP CONSTRAINT IF EXISTS agent_product_versions_manifest_sha256_check;
ALTER TABLE agent_product_versions ADD CONSTRAINT agent_product_versions_manifest_sha256_check CHECK (manifest_sha256 IS NULL OR manifest_sha256 ~ '^[a-f0-9]{64}$');
ALTER TABLE skill_product_versions DROP CONSTRAINT IF EXISTS skill_product_versions_manifest_sha256_check;
ALTER TABLE skill_product_versions ADD CONSTRAINT skill_product_versions_manifest_sha256_check CHECK (manifest_sha256 IS NULL OR manifest_sha256 ~ '^[a-f0-9]{64}$');

CREATE INDEX IF NOT EXISTS idx_agent_versions_product_created ON agent_product_versions(product_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_skill_versions_product_created ON skill_product_versions(product_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_agent_products_deleted_at ON agent_products(deleted_at) WHERE deleted_at IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_skill_products_deleted_at ON skill_products(deleted_at) WHERE deleted_at IS NOT NULL;
