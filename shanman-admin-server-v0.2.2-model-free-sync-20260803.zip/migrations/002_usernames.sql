ALTER TABLE users ADD COLUMN IF NOT EXISTS username TEXT;

UPDATE users
SET username = CASE
  WHEN regexp_replace(split_part(email, '@', 1), '[^A-Za-z0-9_]', '', 'g') = ''
    THEN 'user_' || substr(md5(email), 1, 8)
  ELSE lower(regexp_replace(split_part(email, '@', 1), '[^A-Za-z0-9_]', '', 'g'))
END
WHERE username IS NULL;

WITH duplicates AS (
  SELECT id, username, row_number() OVER (PARTITION BY username ORDER BY created_at, id) AS seq
  FROM users
)
UPDATE users u
SET username = u.username || '_' || substr(replace(u.id::text, '-', ''), 1, 6)
FROM duplicates d
WHERE u.id = d.id AND d.seq > 1;

ALTER TABLE users ALTER COLUMN username SET NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS idx_users_username_unique ON users (lower(username));
ALTER TABLE users DROP CONSTRAINT IF EXISTS users_username_format;
ALTER TABLE users ADD CONSTRAINT users_username_format CHECK (username ~ '^[A-Za-z0-9_]{3,20}$');

