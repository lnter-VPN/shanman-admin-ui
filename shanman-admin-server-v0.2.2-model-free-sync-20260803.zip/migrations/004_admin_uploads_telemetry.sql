ALTER TABLE agent_product_versions ADD COLUMN IF NOT EXISTS package_path TEXT;
ALTER TABLE agent_product_versions ADD COLUMN IF NOT EXISTS content_path TEXT;
ALTER TABLE agent_product_versions ADD COLUMN IF NOT EXISTS package_sha256 TEXT;
ALTER TABLE agent_product_versions ADD COLUMN IF NOT EXISTS package_size INTEGER;
ALTER TABLE agent_product_versions ADD COLUMN IF NOT EXISTS package_format TEXT;
ALTER TABLE skill_product_versions ADD COLUMN IF NOT EXISTS package_path TEXT;
ALTER TABLE skill_product_versions ADD COLUMN IF NOT EXISTS content_path TEXT;
ALTER TABLE skill_product_versions ADD COLUMN IF NOT EXISTS package_sha256 TEXT;
ALTER TABLE skill_product_versions ADD COLUMN IF NOT EXISTS package_size INTEGER;
ALTER TABLE skill_product_versions ADD COLUMN IF NOT EXISTS package_format TEXT;

ALTER TABLE agent_product_versions ADD CONSTRAINT agent_versions_package_sha256_check CHECK (package_sha256 IS NULL OR package_sha256 ~ '^[a-f0-9]{64}$');
ALTER TABLE skill_product_versions ADD CONSTRAINT skill_versions_package_sha256_check CHECK (package_sha256 IS NULL OR package_sha256 ~ '^[a-f0-9]{64}$');
ALTER TABLE agent_product_versions ADD CONSTRAINT agent_versions_package_format_check CHECK (package_format IS NULL OR package_format IN ('zip','json'));
ALTER TABLE skill_product_versions ADD CONSTRAINT skill_versions_package_format_check CHECK (package_format IS NULL OR package_format IN ('zip','json'));
ALTER TABLE agent_product_versions ADD CONSTRAINT agent_versions_package_size_check CHECK (package_size IS NULL OR package_size BETWEEN 1 AND 10485760);
ALTER TABLE skill_product_versions ADD CONSTRAINT skill_versions_package_size_check CHECK (package_size IS NULL OR package_size BETWEEN 1 AND 10485760);

CREATE TABLE IF NOT EXISTS telemetry_events (
  id BIGSERIAL PRIMARY KEY,
  installation_hash TEXT NOT NULL CHECK (installation_hash ~ '^[a-f0-9]{64}$'),
  event_id TEXT NOT NULL CHECK (char_length(event_id) BETWEEN 1 AND 64),
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  name TEXT NOT NULL CHECK (name IN ('app_started','agent_created','agent_installed','skill_enabled','skill_disabled','chat_completed','chat_failed','channel_connected','channel_failed')),
  occurred_at TIMESTAMPTZ NOT NULL,
  properties JSONB NOT NULL DEFAULT '{}'::jsonb,
  received_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(installation_hash,event_id)
);
CREATE INDEX IF NOT EXISTS idx_telemetry_received_at ON telemetry_events(received_at DESC);
CREATE INDEX IF NOT EXISTS idx_telemetry_name_received ON telemetry_events(name,received_at DESC);
CREATE INDEX IF NOT EXISTS idx_telemetry_user_received ON telemetry_events(user_id,received_at DESC) WHERE user_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at DESC);
