ALTER TABLE agent_products ADD COLUMN IF NOT EXISTS category TEXT NOT NULL DEFAULT '通用';
ALTER TABLE agent_products ADD COLUMN IF NOT EXISTS avatar TEXT NOT NULL DEFAULT '';
ALTER TABLE agent_products ADD COLUMN IF NOT EXISTS builder_config JSONB NOT NULL DEFAULT '{}'::jsonb;

CREATE TABLE IF NOT EXISTS agent_product_skills (
  product_id UUID NOT NULL REFERENCES agent_products(id) ON DELETE CASCADE,
  skill_id UUID NOT NULL REFERENCES skill_products(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY(product_id, skill_id)
);

CREATE INDEX IF NOT EXISTS idx_agent_product_skills_skill ON agent_product_skills(skill_id);

