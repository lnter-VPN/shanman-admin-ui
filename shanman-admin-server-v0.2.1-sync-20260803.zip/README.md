# 闪漫 AI 服务端与单管理员后台

本目录提供登录、智能体/技能市场、安装包上传、授权签发、匿名使用统计和单管理员网页。OpenClaw 与模型仍运行在客户电脑，服务器不接收聊天正文、API Key、凭据或工作区文件。

## 入口

- 健康检查：`GET /health`
- 管理后台：`/admin/`
- 公开智能体市场：`GET /api/marketplace/agents`
- 公开技能市场：`GET /api/marketplace/skills`
- 匿名统计上报：`POST /api/telemetry/events`

后台使用 `.env` 中的 `ADMIN_USERNAME` / `ADMIN_EMAIL` / `ADMIN_PASSWORD` 登录。浏览器令牌只保存在 `sessionStorage`，关闭后台标签页后自动清除。

## 管理后台功能

- 概览：用户数、智能体/技能上架数、有效授权、匿名事件数和安装量。
- 技能：上传 JSON 或 ZIP、编辑元数据、上架、下架、软删除。
- 智能体：保留 JSON/ZIP 上传，同时可直接在网页新建、编辑和复制智能体。网页制作器可配置系统提示词、欢迎语、默认模型、温度、工作目标、角色规则、交付目录、记忆/联网/文件/终端权限和专属技能。
- 用户与授权：查看用户基础使用计数、签发授权、查看脱敏 Key 前缀、吊销授权。
- 操作与统计：管理员审计日志、最近 30 天匿名事件聚合。

所有 `/api/admin/*` 接口都在服务端校验当前数据库用户的 `role=admin`，不是只依靠前端隐藏按钮。

### 网页智能体 API

- `POST /api/admin/agents`：使用结构化表单创建智能体和首个版本。
- `GET /api/admin/agents/:id`：返回智能体、工作区配置、版本和已绑定技能。
- `PATCH /api/admin/agents/:id`：保存配置。网页创建的同版本草稿可继续修改；上传包版本需先提高 `x.y.z` 版本号。

后端会把网页字段同步生成市场 `manifest`，技能关联通过 `agent_product_skills` 维护，不会仅保存在浏览器。

## 上传包格式

单包最大 10MB。ZIP 解压后最大 20MB、最多 200 个条目，禁止路径穿越、符号链接、加密文件和可执行脚本。

### JSON 智能体包

```json
{
  "manifest": {
    "type": "agent",
    "slug": "writing-agent",
    "name": "写作智能体",
    "summary": "负责内容策划与改稿",
    "description": "可选详细说明",
    "icon": "bot",
    "version": "1.0.0",
    "changelog": "首个版本"
  },
  "systemPrompt": "你是一个专业写作智能体……"
}
```

### JSON 技能包

```json
{
  "manifest": {
    "type": "skill",
    "slug": "clear-writing",
    "name": "清晰写作",
    "summary": "提升文字清晰度",
    "version": "1.0.0"
  },
  "skillMarkdown": "# 清晰写作\n\n执行步骤……"
}
```

ZIP 包需在根目录或唯一子目录中包含 `manifest.json`，智能体另含 `system-prompt.md`，技能另含 `SKILL.md`。同一 slug 的新包会创建新版本，版本号必须是递增的 `x.y.z`。

## Docker 部署

```bash
cd server
cp .env.example .env
# 修改 .env：数据库密码、JWT、管理员密码、授权私钥等
docker compose up -d --build
docker compose ps
curl http://127.0.0.1:8080/health
```

持久化数据：

- PostgreSQL：Docker volume `postgres_data`
- 智能体/技能上传包：Docker volume `package_storage`

升级前应同时备份这两个 volume。生产环境不要把 `LICENSE_PRIVATE_KEY_PEM`、数据库密码或 JWT 密钥提交到 Git。

## HTTPS 与客户电脑

推荐把该服务部署在独立服务器，通过 Nginx/Caddy 绑定域名和 HTTPS，例如 `https://api.example.com`，后台入口为 `https://api.example.com/admin/`。桌面客户端构建时设置：

仓库内提供了 `deploy/nginx.conf.example`。先替换示例域名和证书路径，再放入服务器 Nginx 配置目录。Docker 默认只将 API 暴露到 `127.0.0.1:8080`，避免绕过 HTTPS 直接访问。

```bash
VITE_SHANMAN_API_BASE_URL=https://api.example.com npm run build
```

客户电脑只访问公开市场、账户、授权和匿名统计 API；管理员后台不要对普通客户提供账号。

GitHub 可以保存源码并通过 Actions 自动部署到服务器，但 **GitHub Pages 不能单独承载本后台**：上传、管理员鉴权、PostgreSQL、授权签名和统计 API 都需要服务端运行环境与持久化磁盘。

## 生产检查

1. 使用至少 32 位随机 `JWT_SECRET` 和至少 8 位管理员密码（正式项目仍建议 12 位以上）。
2. 配置 HTTPS，远程 HTTP 会被桌面客户端安全策略拒绝。
3. 将 `WEB_ORIGIN` 从 `*` 改为实际允许的 Web 来源。
4. 私钥只读挂载到容器外，设置 `LICENSE_PRIVATE_KEY_PATH`。
5. 定期执行 `npm test`、数据库备份和上传包 volume 备份。
