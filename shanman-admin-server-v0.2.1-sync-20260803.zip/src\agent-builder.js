import { publicVersion, validateProductDraft, validateVersionDraft } from './marketplace-utils.js';

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const STATUSES = new Set(['draft', 'published', 'unpublished']);

function inputObject(value) {
  return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
}

function text(value, field, max, { required = false } = {}) {
  const result = String(value ?? '').trim();
  if (required && !result) throw Object.assign(new TypeError(`${field} 必填`), { statusCode: 400 });
  if (result.length > max) throw Object.assign(new TypeError(`${field} 超过长度限制`), { statusCode: 400 });
  return result;
}

function boolean(value, fallback = false) {
  return value === undefined ? fallback : value === true;
}

export function validateAgentBuilderDraft(body, { partial = false } = {}) {
  const value = inputObject(body);
  const product = validateProductDraft(value, { partial });
  const result = { ...product };
  const optionalText = (field, max, fallback = '') => {
    if (partial && value[field] === undefined) return;
    result[field] = text(value[field] ?? fallback, field, max);
  };

  optionalText('category', 80, '通用');
  optionalText('avatar', 2048);
  optionalText('systemPrompt', 200_000);
  optionalText('welcomeMessage', 10_000);
  optionalText('provider', 120);
  optionalText('model', 160);

  if (!partial || value.temperature !== undefined) {
    const temperature = value.temperature === '' || value.temperature === undefined ? 0.7 : Number(value.temperature);
    if (!Number.isFinite(temperature) || temperature < 0 || temperature > 2) {
      throw Object.assign(new TypeError('temperature 必须在 0 到 2 之间'), { statusCode: 400 });
    }
    result.temperature = temperature;
  }

  if (!partial || value.workspace !== undefined) {
    const workspace = inputObject(value.workspace);
    result.workspace = {
      goal: text(workspace.goal, 'workspace.goal', 20_000),
      roleRules: text(workspace.roleRules, 'workspace.roleRules', 50_000),
      outputDirectory: text(workspace.outputDirectory || 'outputs', 'workspace.outputDirectory', 500),
      memoryEnabled: boolean(workspace.memoryEnabled, true),
      allowWeb: boolean(workspace.allowWeb, false),
      allowFiles: boolean(workspace.allowFiles, true),
      allowTerminal: boolean(workspace.allowTerminal, false)
    };
  }

  if (!partial || value.skillIds !== undefined) {
    const skillIds = Array.isArray(value.skillIds) ? value.skillIds.map((item) => String(item || '').trim()) : [];
    if (skillIds.length > 100 || skillIds.some((id) => !UUID_RE.test(id))) {
      throw Object.assign(new TypeError('skillIds 必须是最多 100 个有效技能 ID'), { statusCode: 400 });
    }
    result.skillIds = [...new Set(skillIds)];
  }

  if (!partial || value.version !== undefined) {
    result.version = text(value.version, 'version', 40, { required: true });
    validateVersionDraft({ version: result.version, manifest: {} });
  }
  if (!partial || value.changelog !== undefined) optionalText('changelog', 20_000);
  if (!partial || value.status !== undefined) {
    const status = String(value.status || 'draft').trim();
    if (!STATUSES.has(status)) throw Object.assign(new TypeError('status 无效'), { statusCode: 400 });
    result.status = status;
  }
  return result;
}

export function builderConfigFrom(draft, current = {}) {
  return {
    systemPrompt: draft.systemPrompt ?? current.systemPrompt ?? '',
    welcomeMessage: draft.welcomeMessage ?? current.welcomeMessage ?? '',
    provider: draft.provider ?? current.provider ?? '',
    model: draft.model ?? current.model ?? '',
    temperature: draft.temperature ?? current.temperature ?? 0.7,
    workspace: draft.workspace ?? current.workspace ?? {
      goal: '', roleRules: '', outputDirectory: 'outputs', memoryEnabled: true,
      allowWeb: false, allowFiles: true, allowTerminal: false
    }
  };
}

export function buildAgentManifest(product, builderConfig, skills, version) {
  return {
    type: 'agent',
    slug: product.slug,
    name: product.name,
    version,
    category: product.category || '通用',
    summary: product.summary || '',
    description: product.description || '',
    icon: product.icon || 'bot',
    avatar: product.avatar || '',
    systemPrompt: builderConfig.systemPrompt || '',
    welcomeMessage: builderConfig.welcomeMessage || '',
    model: {
      provider: builderConfig.provider || '',
      id: builderConfig.model || '',
      temperature: Number(builderConfig.temperature ?? 0.7)
    },
    workspace: builderConfig.workspace || {},
    skillIds: skills.map((skill) => skill.id),
    skills: skills.map((skill) => ({ id: skill.id, slug: skill.slug, name: skill.name, version: skill.version || null }))
  };
}

export function agentAdminView(row, { latestVersion = null, versions, skills = [] } = {}) {
  const config = inputObject(row.builder_config);
  const latest = latestVersion || row.latest_version || null;
  const manifest = inputObject(latest?.manifest);
  const manifestModel = inputObject(manifest.model);
  const workspace = Object.keys(inputObject(config.workspace)).length ? inputObject(config.workspace) : inputObject(manifest.workspace);
  return {
    id: row.id,
    slug: row.slug,
    name: row.name,
    category: row.category && row.category !== '通用' ? row.category : manifest.category || row.category || '通用',
    summary: row.summary || '',
    description: row.description || '',
    icon: row.icon || 'bot',
    avatar: row.avatar || manifest.avatar || '',
    status: row.status,
    systemPrompt: config.systemPrompt ?? manifest.systemPrompt ?? '',
    welcomeMessage: config.welcomeMessage ?? manifest.welcomeMessage ?? '',
    provider: config.provider ?? manifestModel.provider ?? '',
    model: config.model ?? manifestModel.id ?? '',
    temperature: Number(config.temperature ?? manifestModel.temperature ?? 0.7),
    workspace,
    skillIds: skills.map((skill) => skill.id),
    skills: skills.map((skill) => ({ id: skill.id, slug: skill.slug, name: skill.name, status: skill.status, version: skill.version || null })),
    latestVersion: publicVersion(latest),
    ...(versions ? { versions: versions.map((versionRow) => publicVersion(versionRow)) } : {}),
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    publishedAt: row.published_at,
    deletedAt: row.deleted_at
  };
}
