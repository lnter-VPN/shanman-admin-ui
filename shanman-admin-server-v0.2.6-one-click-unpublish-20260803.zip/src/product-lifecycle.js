import path from 'node:path';

export async function unpublishAgentsUsingSkill(tx, skillId) {
  const result = await tx(`UPDATE agent_products AS agent
    SET status='unpublished',updated_at=now()
    WHERE agent.status='published'
      AND EXISTS(
        SELECT 1 FROM agent_product_skills relation
        WHERE relation.product_id=agent.id AND relation.skill_id=$1
      )
    RETURNING agent.id,agent.slug,agent.name`, [skillId]);
  return result.rows || [];
}

export function storedVersionDirectories(rows = []) {
  const directories = new Set();
  for (const row of rows) {
    for (const value of [row?.package_path, row?.content_path]) {
      const normalized = String(value || '').replaceAll('\\', '/');
      if (!normalized || normalized.startsWith('/') || normalized.split('/').some((segment) => !segment || segment === '.' || segment === '..')) continue;
      const directory = path.posix.dirname(normalized);
      if (directory && directory !== '.') directories.add(directory);
    }
  }
  return [...directories];
}
