import crypto from 'node:crypto';
import { config } from '../config.js';
import { query, withTransaction } from '../db.js';
import { createLicenseAuthority, expiryFromRequest, loadPrivateKey, validateMachineFingerprint } from '../license-signing.js';
import { assertVersionIsNewer, publicVersion, validateProductDraft, validateVersionDraft } from '../marketplace-utils.js';
import { parseMarketplacePackage, removeStoredDirectory, writePackageToStorage } from '../package-upload.js';
import { agentAdminView, buildAgentManifest, builderConfigFrom, validateAgentBuilderDraft } from '../agent-builder.js';
import { MAX_AVATAR_BYTES, storeAgentAvatar } from '../avatar-storage.js';
import { storedVersionDirectories, unpublishAgentsUsingSkill } from '../product-lifecycle.js';

const PRODUCTS = {
  agents: { table: 'agent_products', versions: 'agent_product_versions', hasIcon: true, label: '智能体' },
  skills: { table: 'skill_products', versions: 'skill_product_versions', hasIcon: false, label: '技能' }
};
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const licenseAuthority = createLicenseAuthority({
  privateKeyPem: loadPrivateKey(config), publicKeyPem: config.nodeEnv === 'test' ? config.licensePublicKeyPem || undefined : undefined
});

function uuid(value, label = 'id') {
  const result = String(value || '').trim();
  if (!UUID_RE.test(result)) throw Object.assign(new TypeError(`${label} 无效`), { statusCode: 400 });
  return result;
}

async function audit(tx, userId, action, entityType, entityId, metadata = {}) {
  await tx('INSERT INTO audit_logs(user_id,action,entity_type,entity_id,metadata) VALUES($1,$2,$3,$4,$5)', [userId, action, entityType, entityId, metadata]);
}

function mapPgError(error) {
  if (error?.code === '23505') return Object.assign(new Error('slug、版本或授权 Key 已存在'), { statusCode: 409 });
  if (error?.code === '23503') return Object.assign(new Error('关联的用户或资源不存在'), { statusCode: 400 });
  return error;
}

async function loadAgentSkills(runQuery, productIds) {
  const ids = Array.isArray(productIds) ? productIds : [productIds];
  if (!ids.length) return new Map();
  const result = await runQuery(`SELECT aps.product_id,s.id,s.slug,s.name,s.status,
    (SELECT v.version FROM skill_product_versions v WHERE v.product_id=s.id ORDER BY v.created_at DESC LIMIT 1) version
    FROM agent_product_skills aps JOIN skill_products s ON s.id=aps.skill_id
    WHERE aps.product_id=ANY($1::uuid[]) ORDER BY s.name`, [ids]);
  const grouped = new Map(ids.map((id) => [id, []]));
  for (const row of result.rows) grouped.get(row.product_id)?.push(row);
  return grouped;
}

async function resolveAgentSkills(tx, skillIds) {
  if (!skillIds?.length) return [];
  const result = await tx(`SELECT s.id,s.slug,s.name,s.status,
    (SELECT v.version FROM skill_product_versions v WHERE v.product_id=s.id ORDER BY v.created_at DESC LIMIT 1) version
    FROM skill_products s WHERE s.id=ANY($1::uuid[]) AND s.status<>'deleted' ORDER BY s.name`, [skillIds]);
  if (result.rowCount !== skillIds.length) throw Object.assign(new Error('部分技能不存在或已删除'), { statusCode: 400 });
  return result.rows;
}

async function replaceAgentSkills(tx, productId, skills) {
  await tx('DELETE FROM agent_product_skills WHERE product_id=$1', [productId]);
  for (const skill of skills) await tx('INSERT INTO agent_product_skills(product_id,skill_id) VALUES($1,$2)', [productId, skill.id]);
}

async function createAgentFromBuilder(req, reply) {
  const draft = validateAgentBuilderDraft(req.body);
  try {
    const created = await withTransaction(async (tx) => {
      const skills = await resolveAgentSkills(tx, draft.skillIds);
      if (draft.status === 'published' && skills.some((skill) => skill.status !== 'published')) {
        throw Object.assign(new Error(`请先上架智能体绑定的技能：${skills.filter((skill) => skill.status !== 'published').map((skill) => skill.name).join('、')}`), { statusCode: 409 });
      }
      const builderConfig = builderConfigFrom(draft);
      const inserted = await tx(`INSERT INTO agent_products
        (slug,name,summary,description,icon,category,avatar,builder_config,status,created_by,published_at)
        VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,CASE WHEN $9='published' THEN now() ELSE NULL END) RETURNING *`,
        [draft.slug,draft.name,draft.summary,draft.description,draft.icon,draft.category,draft.avatar,builderConfig,draft.status,req.user.sub]);
      const product = inserted.rows[0];
      await replaceAgentSkills(tx, product.id, skills);
      const versionDraft = validateVersionDraft({
        version: draft.version,
        manifest: buildAgentManifest(product, builderConfig, skills, draft.version),
        changelog: draft.changelog || '网页创建智能体'
      });
      const version = await tx(`INSERT INTO agent_product_versions(product_id,version,manifest,changelog,manifest_sha256)
        VALUES($1,$2,$3,$4,$5) RETURNING *`, [product.id,versionDraft.version,versionDraft.manifest,versionDraft.changelog,versionDraft.manifestSha256]);
      await audit(tx, req.user.sub, 'agents.builder.create', 'agents', product.id, {
        slug: product.slug, version: versionDraft.version, skillIds: draft.skillIds, status: draft.status
      });
      return agentAdminView(product, { latestVersion: version.rows[0], versions: version.rows, skills });
    });
    return reply.code(201).send(created);
  } catch (error) { throw mapPgError(error); }
}

async function updateAgentFromBuilder(req, reply) {
  const id = uuid(req.params.id); const draft = validateAgentBuilderDraft(req.body, { partial: true });
  try {
    const updated = await withTransaction(async (tx) => {
      const current = await tx(`SELECT * FROM agent_products WHERE id=$1 AND status<>'deleted' FOR UPDATE`, [id]);
      if (!current.rowCount) return null;
      const row = current.rows[0];
      const latest = await tx('SELECT * FROM agent_product_versions WHERE product_id=$1 ORDER BY created_at DESC LIMIT 1 FOR UPDATE', [id]);
      const currentSkills = (await loadAgentSkills(tx, id)).get(id) || [];
      const skills = draft.skillIds === undefined ? currentSkills : await resolveAgentSkills(tx, draft.skillIds);
      const latestManifest = latest.rows[0]?.manifest || {};
      const storedConfig = row.builder_config && typeof row.builder_config === 'object' ? row.builder_config : {};
      const builderConfig = builderConfigFrom(draft, {
        systemPrompt: storedConfig.systemPrompt ?? latestManifest.systemPrompt ?? '',
        welcomeMessage: storedConfig.welcomeMessage ?? latestManifest.welcomeMessage ?? '',
        workspace: storedConfig.workspace ?? latestManifest.workspace ?? {}
      });
      const next = {
        ...row,
        slug: draft.slug ?? row.slug,
        name: draft.name ?? row.name,
        summary: draft.summary ?? row.summary,
        description: draft.description ?? row.description,
        icon: draft.icon ?? row.icon,
        category: draft.category ?? row.category,
        avatar: draft.avatar ?? row.avatar,
        status: draft.status ?? row.status
      };
      if (next.status === 'published' && skills.some((skill) => skill.status !== 'published')) {
        throw Object.assign(new Error(`请先上架智能体绑定的技能：${skills.filter((skill) => skill.status !== 'published').map((skill) => skill.name).join('、')}`), { statusCode: 409 });
      }
      const productResult = await tx(`UPDATE agent_products SET slug=$1,name=$2,summary=$3,description=$4,icon=$5,
        category=$6,avatar=$7,builder_config=$8,status=$9,
        published_at=CASE WHEN $9='published' THEN COALESCE(published_at,now()) ELSE published_at END,updated_at=now()
        WHERE id=$10 RETURNING *`, [next.slug,next.name,next.summary,next.description,next.icon,next.category,next.avatar,builderConfig,next.status,id]);
      if (draft.skillIds !== undefined) await replaceAgentSkills(tx, id, skills);
      const versionName = draft.version || latest.rows[0]?.version;
      if (!versionName) throw Object.assign(new Error('请填写版本号'), { statusCode: 400 });
      const versionDraft = validateVersionDraft({
        version: versionName,
        manifest: buildAgentManifest(productResult.rows[0], builderConfig, skills, versionName),
        changelog: draft.changelog ?? latest.rows[0]?.changelog ?? '网页编辑智能体'
      });
      let version;
      if (latest.rowCount && latest.rows[0].version === versionName) {
        if (latest.rows[0].package_path) throw Object.assign(new Error('该版本来自上传包，请提高版本号后再保存网页配置'), { statusCode: 409 });
        version = await tx(`UPDATE agent_product_versions SET manifest=$1,changelog=$2,manifest_sha256=$3
          WHERE id=$4 RETURNING *`, [versionDraft.manifest,versionDraft.changelog,versionDraft.manifestSha256,latest.rows[0].id]);
      } else {
        assertVersionIsNewer(versionName, latest.rows[0]?.version);
        version = await tx(`INSERT INTO agent_product_versions(product_id,version,manifest,changelog,manifest_sha256)
          VALUES($1,$2,$3,$4,$5) RETURNING *`, [id,versionDraft.version,versionDraft.manifest,versionDraft.changelog,versionDraft.manifestSha256]);
      }
      await audit(tx, req.user.sub, 'agents.builder.update', 'agents', id, {
        fields: Object.keys(draft), version: versionName, skillIds: skills.map((skill) => skill.id), status: next.status
      });
      const versions = await tx('SELECT * FROM agent_product_versions WHERE product_id=$1 ORDER BY created_at DESC', [id]);
      return agentAdminView(productResult.rows[0], { latestVersion: version.rows[0], versions: versions.rows, skills });
    });
    if (!updated) return reply.code(404).send({ error: '资源不存在' });
    return updated;
  } catch (error) { throw mapPgError(error); }
}

function productRoutes(app, type) {
  const spec = PRODUCTS[type]; const base = `/api/admin/${type}`;

  app.get(base, { preHandler: app.requireAdmin }, async (req) => {
    const status = req.query?.status ? String(req.query.status) : '';
    const allowed = new Set(['draft', 'published', 'unpublished', 'deleted']);
    if (status && !allowed.has(status)) throw Object.assign(new TypeError('status 无效'), { statusCode: 400 });
    const params = status ? [status] : [];
    const where = status ? 'WHERE p.status=$1' : '';
    const result = await query(`SELECT p.*, (SELECT row_to_json(v) FROM ${spec.versions} v WHERE v.product_id=p.id ORDER BY v.created_at DESC LIMIT 1) latest_version FROM ${spec.table} p ${where} ORDER BY p.updated_at DESC`, params);
    if (type === 'agents') {
      const groupedSkills = await loadAgentSkills(query, result.rows.map((row) => row.id));
      return { items: result.rows.map((row) => agentAdminView(row, { skills: groupedSkills.get(row.id) || [] })) };
    }
    return { items: result.rows.map((row) => {
      const latestVersion = publicVersion(row.latest_version);
      return { ...row, latestVersion, latest_version: latestVersion };
    }) };
  });

  app.get(`${base}/:id`, { preHandler: app.requireAdmin }, async (req, reply) => {
    const id = uuid(req.params.id); const product = await query(`SELECT * FROM ${spec.table} WHERE id=$1`, [id]);
    if (!product.rowCount) return reply.code(404).send({ error: '资源不存在' });
    const versions = await query(`SELECT * FROM ${spec.versions} WHERE product_id=$1 ORDER BY created_at DESC`, [id]);
    if (type === 'agents') {
      const skills = (await loadAgentSkills(query, id)).get(id) || [];
      return agentAdminView(product.rows[0], { latestVersion: versions.rows[0], versions: versions.rows, skills });
    }
    return { ...product.rows[0], latestVersion: publicVersion(versions.rows[0]), versions: versions.rows.map(publicVersion) };
  });

  app.post(base, { preHandler: app.requireAdmin }, async (req, reply) => {
    const builderFields = ['version','category','avatar','systemPrompt','welcomeMessage','workspace','skillIds','status','changelog'];
    if (type === 'agents' && !req.body?.manifest && builderFields.some((field) => req.body?.[field] !== undefined)) return createAgentFromBuilder(req, reply);
    const draft = validateProductDraft(req.body); const version = req.body?.version ? validateVersionDraft(req.body) : null;
    try {
      const product = await withTransaction(async (tx) => {
        const inserted = spec.hasIcon
          ? await tx(`INSERT INTO ${spec.table}(slug,name,summary,description,icon,created_by) VALUES($1,$2,$3,$4,$5,$6) RETURNING *`, [draft.slug,draft.name,draft.summary,draft.description,draft.icon,req.user.sub])
          : await tx(`INSERT INTO ${spec.table}(slug,name,summary,description,created_by) VALUES($1,$2,$3,$4,$5) RETURNING *`, [draft.slug,draft.name,draft.summary,draft.description,req.user.sub]);
        if (version) await tx(`INSERT INTO ${spec.versions}(product_id,version,manifest,changelog,manifest_sha256) VALUES($1,$2,$3,$4,$5)`, [inserted.rows[0].id,version.version,version.manifest,version.changelog,version.manifestSha256]);
        await audit(tx, req.user.sub, `${type}.create`, type, inserted.rows[0].id, { slug: draft.slug, version: version?.version || null });
        return inserted.rows[0];
      });
      return reply.code(201).send(product);
    } catch (error) { throw mapPgError(error); }
  });

  app.patch(`${base}/:id`, { preHandler: app.requireAdmin }, async (req, reply) => {
    const builderFields = ['version','slug','category','avatar','systemPrompt','welcomeMessage','workspace','skillIds','status','changelog'];
    if (type === 'agents' && builderFields.some((field) => req.body?.[field] !== undefined)) return updateAgentFromBuilder(req, reply);
    const id = uuid(req.params.id); const draft = validateProductDraft(req.body, { partial: true });
    try {
      const product = await withTransaction(async (tx) => {
        const current = await tx(`SELECT * FROM ${spec.table} WHERE id=$1 AND status<>'deleted' FOR UPDATE`, [id]);
        if (!current.rowCount) return null;
        const row = current.rows[0];
        const result = spec.hasIcon
          ? await tx(`UPDATE ${spec.table} SET name=$1,summary=$2,description=$3,icon=$4,updated_at=now() WHERE id=$5 RETURNING *`, [draft.name??row.name,draft.summary??row.summary,draft.description??row.description,draft.icon??row.icon,id])
          : await tx(`UPDATE ${spec.table} SET name=$1,summary=$2,description=$3,updated_at=now() WHERE id=$4 RETURNING *`, [draft.name??row.name,draft.summary??row.summary,draft.description??row.description,id]);
        await audit(tx, req.user.sub, `${type}.update`, type, id, { fields: Object.keys(draft) });
        return result.rows[0];
      });
      if (!product) return reply.code(404).send({ error: '资源不存在' });
      return product;
    } catch (error) { throw mapPgError(error); }
  });

  app.post(`${base}/:id/versions`, { preHandler: app.requireAdmin }, async (req, reply) => {
    const id = uuid(req.params.id); const version = validateVersionDraft(req.body);
    try {
      const created = await withTransaction(async (tx) => {
        const product = await tx(`SELECT id,status FROM ${spec.table} WHERE id=$1 AND status<>'deleted' FOR UPDATE`, [id]);
        if (!product.rowCount) return null;
        const latest = await tx(`SELECT version FROM ${spec.versions} WHERE product_id=$1 ORDER BY created_at DESC LIMIT 1`, [id]);
        assertVersionIsNewer(version.version, latest.rows[0]?.version);
        const result = await tx(`INSERT INTO ${spec.versions}(product_id,version,manifest,changelog,manifest_sha256) VALUES($1,$2,$3,$4,$5) RETURNING *`, [id,version.version,version.manifest,version.changelog,version.manifestSha256]);
        await tx(`UPDATE ${spec.table} SET updated_at=now() WHERE id=$1`, [id]);
        await audit(tx, req.user.sub, `${type}.version.create`, type, id, { version: version.version, manifestSha256: version.manifestSha256 });
        return publicVersion(result.rows[0]);
      });
      if (!created) return reply.code(404).send({ error: '资源不存在' });
      return reply.code(201).send(created);
    } catch (error) { throw mapPgError(error); }
  });

  app.post(`${base}/:id/publish`, { preHandler: app.requireAdmin }, async (req, reply) => {
    const id = uuid(req.params.id);
    const result = await withTransaction(async (tx) => {
      const product = await tx(`SELECT id FROM ${spec.table} WHERE id=$1 AND status<>'deleted' FOR UPDATE`, [id]);
      if (!product.rowCount) return { missing: true };
      const version = await tx(`SELECT version,manifest_sha256 FROM ${spec.versions} WHERE product_id=$1 ORDER BY created_at DESC LIMIT 1`, [id]);
      if (!version.rowCount) return { noVersion: true };
      if (type === 'agents') {
        const unavailableSkills = await tx(`SELECT s.name,s.status FROM agent_product_skills aps
          JOIN skill_products s ON s.id=aps.skill_id WHERE aps.product_id=$1 AND s.status<>'published' ORDER BY s.name`, [id]);
        if (unavailableSkills.rowCount) return { unavailableSkills: unavailableSkills.rows };
      }
      const updated = await tx(`UPDATE ${spec.table} SET status='published',published_at=COALESCE(published_at,now()),updated_at=now() WHERE id=$1 RETURNING *`, [id]);
      await audit(tx, req.user.sub, `${type}.publish`, type, id, { version: version.rows[0].version, manifestSha256: version.rows[0].manifest_sha256 });
      return { product: updated.rows[0] };
    });
    if (result.missing) return reply.code(404).send({ error: '资源不存在' });
    if (result.noVersion) return reply.code(409).send({ error: `${spec.label}至少上传一个版本后才能上架` });
    if (result.unavailableSkills) return reply.code(409).send({ error: `请先上架智能体绑定的技能：${result.unavailableSkills.map((skill) => skill.name).join('、')}` });
    return result.product;
  });

  app.post(`${base}/:id/unpublish`, { preHandler: app.requireAdmin }, async (req, reply) => {
    const id = uuid(req.params.id); const result = await withTransaction(async (tx) => {
      const updated = await tx(`UPDATE ${spec.table} SET status='unpublished',updated_at=now() WHERE id=$1 AND status<>'deleted' RETURNING *`, [id]);
      if (!updated.rowCount) return null;
      const affectedAgents = type === 'skills' ? await unpublishAgentsUsingSkill(tx, id) : [];
      await audit(tx, req.user.sub, `${type}.unpublish`, type, id, { affectedAgentIds: affectedAgents.map((agent) => agent.id) });
      for (const agent of affectedAgents) await audit(tx, req.user.sub, 'agents.auto_unpublish', 'agents', agent.id, { reason: 'bound_skill_unpublished', skillId: id });
      return { product: updated.rows[0], affectedAgents };
    });
    if (!result) return reply.code(404).send({ error: '资源不存在' });
    return { ...result.product, affectedAgents: result.affectedAgents };
  });

  app.delete(`${base}/:id`, { preHandler: app.requireAdmin }, async (req, reply) => {
    const id = uuid(req.params.id); const result = await withTransaction(async (tx) => {
      const updated = await tx(`UPDATE ${spec.table} SET status='deleted',deleted_at=now(),updated_at=now() WHERE id=$1 AND status<>'deleted' RETURNING id,slug`, [id]);
      if (!updated.rowCount) return null;
      const affectedAgents = type === 'skills' ? await unpublishAgentsUsingSkill(tx, id) : [];
      await audit(tx, req.user.sub, `${type}.delete`, type, id, { affectedAgentIds: affectedAgents.map((agent) => agent.id) });
      for (const agent of affectedAgents) await audit(tx, req.user.sub, 'agents.auto_unpublish', 'agents', agent.id, { reason: 'bound_skill_deleted', skillId: id });
      return { product: updated.rows[0], affectedAgents };
    });
    if (!result) return reply.code(404).send({ error: '资源不存在' });
    return { ok: true, id: result.product.id, status: 'deleted', affectedAgents: result.affectedAgents };
  });

  app.delete(`${base}/:id/permanent`, { preHandler: app.requireAdmin }, async (req, reply) => {
    const id = uuid(req.params.id); const result = await withTransaction(async (tx) => {
      const current = await tx(`SELECT id,slug,status FROM ${spec.table} WHERE id=$1 FOR UPDATE`, [id]);
      if (!current.rowCount) return { missing: true };
      if (current.rows[0].status !== 'deleted') return { conflict: true };
      const versions = await tx(`SELECT package_path,content_path FROM ${spec.versions} WHERE product_id=$1`, [id]);
      const affectedAgents = type === 'skills' ? await unpublishAgentsUsingSkill(tx, id) : [];
      await tx(`DELETE FROM ${spec.table} WHERE id=$1`, [id]);
      await audit(tx, req.user.sub, `${type}.permanent_delete`, type, id, {
        slug: current.rows[0].slug, versionCount: versions.rowCount,
        affectedAgentIds: affectedAgents.map((agent) => agent.id)
      });
      for (const agent of affectedAgents) await audit(tx, req.user.sub, 'agents.auto_unpublish', 'agents', agent.id, { reason: 'bound_skill_permanently_deleted', skillId: id });
      return { slug: current.rows[0].slug, versionCount: versions.rowCount, directories: storedVersionDirectories(versions.rows), affectedAgents };
    });
    if (result.missing) return reply.code(404).send({ error: '资源不存在' });
    if (result.conflict) return reply.code(409).send({ error: `请先将${spec.label}移入回收站，再执行永久删除` });
    let cleanupWarnings = 0;
    for (const directory of result.directories) {
      try { await removeStoredDirectory(config.storagePath, directory); } catch { cleanupWarnings += 1; }
    }
    return {
      ok: true, permanentlyDeleted: true, slug: result.slug, removedVersions: result.versionCount,
      removedStorageDirectories: result.directories.length - cleanupWarnings, cleanupWarnings,
      affectedAgents: result.affectedAgents
    };
  });

  app.post(`${base}/upload`, { preHandler: app.requireAdmin }, async (req, reply) => {
    if (!req.isMultipart()) return reply.code(415).send({ error: '请使用 multipart/form-data 上传 JSON 或 ZIP 文件' });
    const file = await req.file();
    if (!file) return reply.code(400).send({ error: '请选择上传文件' });
    const buffer = await file.toBuffer();
    if (file.file.truncated) return reply.code(413).send({ error: '上传包不能超过 10MB' });
    const packageData = await parseMarketplacePackage(buffer, { type, filename: file.filename });
    const stored = await writePackageToStorage(packageData, config.storagePath);
    try {
      const created = await withTransaction(async (tx) => {
        const existing = await tx(`SELECT * FROM ${spec.table} WHERE slug=$1 FOR UPDATE`, [packageData.product.slug]);
        let product;
        if (existing.rowCount) {
          product = existing.rows[0];
          if (product.status === 'deleted') throw Object.assign(new Error('同名资源已删除，请更换 slug'), { statusCode: 409 });
          const latest = await tx(`SELECT version FROM ${spec.versions} WHERE product_id=$1 ORDER BY created_at DESC LIMIT 1`, [product.id]);
          assertVersionIsNewer(packageData.version.version, latest.rows[0]?.version);
          const draft = packageData.product;
          const updated = spec.hasIcon
            ? await tx(`UPDATE ${spec.table} SET name=$1,summary=$2,description=$3,icon=$4,updated_at=now() WHERE id=$5 RETURNING *`, [draft.name,draft.summary,draft.description,draft.icon,product.id])
            : await tx(`UPDATE ${spec.table} SET name=$1,summary=$2,description=$3,updated_at=now() WHERE id=$4 RETURNING *`, [draft.name,draft.summary,draft.description,product.id]);
          product = updated.rows[0];
        } else {
          const draft = packageData.product;
          const inserted = spec.hasIcon
            ? await tx(`INSERT INTO ${spec.table}(slug,name,summary,description,icon,created_by) VALUES($1,$2,$3,$4,$5,$6) RETURNING *`, [draft.slug,draft.name,draft.summary,draft.description,draft.icon,req.user.sub])
            : await tx(`INSERT INTO ${spec.table}(slug,name,summary,description,created_by) VALUES($1,$2,$3,$4,$5) RETURNING *`, [draft.slug,draft.name,draft.summary,draft.description,req.user.sub]);
          product = inserted.rows[0];
        }
        const version = await tx(`INSERT INTO ${spec.versions}
          (product_id,version,manifest,changelog,manifest_sha256,package_path,content_path,package_sha256,package_size,package_format)
          VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`, [
          product.id,packageData.version.version,packageData.version.manifest,packageData.version.changelog,
          packageData.version.manifestSha256,stored.packagePath,stored.contentPath,packageData.packageSha256,
          packageData.packageSize,packageData.format
        ]);
        await audit(tx, req.user.sub, `${type}.package.upload`, type, product.id, {
          slug: product.slug, version: packageData.version.version, packageSha256: packageData.packageSha256,
          packageSize: packageData.packageSize, packageFormat: packageData.format
        });
        return { product, version: publicVersion(version.rows[0]) };
      });
      return reply.code(201).send(created);
    } catch (error) {
      await removeStoredDirectory(config.storagePath, stored.directory).catch(() => {});
      throw mapPgError(error);
    }
  });
}

function numberValue(row, key) { return Number(row?.[key] || 0); }
function boundedInt(value, fallback, max) {
  const parsed = Number(value);
  return Number.isInteger(parsed) && parsed >= 1 ? Math.min(max, parsed) : fallback;
}

async function dashboard() {
  const [users, agents, skills, licenses, telemetry] = await Promise.all([
    query('SELECT count(*) AS total FROM users'),
    query(`SELECT count(*) FILTER (WHERE status<>'deleted') AS total,
      count(*) FILTER (WHERE status='published') AS published,
      count(*) FILTER (WHERE status='draft') AS draft,
      count(*) FILTER (WHERE status='unpublished') AS unpublished,
      count(*) FILTER (WHERE status='deleted') AS deleted FROM agent_products`),
    query(`SELECT count(*) FILTER (WHERE status<>'deleted') AS total,
      count(*) FILTER (WHERE status='published') AS published,
      count(*) FILTER (WHERE status='draft') AS draft,
      count(*) FILTER (WHERE status='unpublished') AS unpublished,
      count(*) FILTER (WHERE status='deleted') AS deleted FROM skill_products`),
    query("SELECT count(*) FILTER (WHERE status='active' AND (expires_at IS NULL OR expires_at>now())) AS active FROM licenses"),
    query("SELECT count(*) FILTER (WHERE received_at>now()-interval '24 hours') AS events_24h,count(DISTINCT installation_hash) FILTER (WHERE received_at>now()-interval '30 days') AS installations_30d FROM telemetry_events")
  ]);
  return {
    users: numberValue(users.rows[0], 'total'),
    agents: {
      total: numberValue(agents.rows[0], 'total'), published: numberValue(agents.rows[0], 'published'),
      draft: numberValue(agents.rows[0], 'draft'), unpublished: numberValue(agents.rows[0], 'unpublished'),
      deleted: numberValue(agents.rows[0], 'deleted')
    },
    skills: {
      total: numberValue(skills.rows[0], 'total'), published: numberValue(skills.rows[0], 'published'),
      draft: numberValue(skills.rows[0], 'draft'), unpublished: numberValue(skills.rows[0], 'unpublished'),
      deleted: numberValue(skills.rows[0], 'deleted')
    },
    activeLicenses: numberValue(licenses.rows[0], 'active'),
    events24h: numberValue(telemetry.rows[0], 'events_24h'),
    installations30d: numberValue(telemetry.rows[0], 'installations_30d')
  };
}

export default async function adminRoutes(app) {
  app.post('/api/admin/agents/avatar', { preHandler: app.requireAdmin }, async (req, reply) => {
    if (!req.isMultipart()) return reply.code(415).send({ error: '请使用 multipart/form-data 上传头像' });
    const file = await req.file();
    if (!file) return reply.code(400).send({ error: '请选择头像图片' });
    const buffer = await file.toBuffer();
    if (file.file.truncated || buffer.length > MAX_AVATAR_BYTES) return reply.code(413).send({ error: '头像不能超过 3MB' });
    const stored = await storeAgentAvatar(buffer, config.storagePath);
    await withTransaction((tx) => audit(tx, req.user.sub, 'agents.avatar.upload', 'agents', null, {
      filename: stored.filename, contentType: stored.contentType, size: stored.size
    }));
    return reply.code(201).send(stored);
  });
  productRoutes(app, 'agents'); productRoutes(app, 'skills');
  app.get('/api/admin/dashboard', { preHandler: app.requireAdmin }, dashboard);
  app.get('/api/admin/users', { preHandler: app.requireAdmin }, async (req) => {
    const limit = boundedInt(req.query?.limit, 100, 200);
    const result = await query(`SELECT u.id,u.username,u.email,u.role,u.created_at,
      (SELECT count(*) FROM licenses l WHERE l.user_id=u.id) AS license_count,
      (SELECT count(*) FROM telemetry_events t WHERE t.user_id=u.id) AS event_count,
      (SELECT max(t.received_at) FROM telemetry_events t WHERE t.user_id=u.id) AS last_seen_at
      FROM users u ORDER BY u.created_at DESC LIMIT $1`, [limit]);
    return { items: result.rows.map((row) => ({ ...row, license_count: Number(row.license_count), event_count: Number(row.event_count) })) };
  });
  app.get('/api/admin/licenses', { preHandler: app.requireAdmin }, async (req) => {
    const limit = boundedInt(req.query?.limit, 100, 200);
    const result = await query(`SELECT l.id,l.user_id,
      CASE WHEN l.status='active' AND l.expires_at IS NOT NULL AND l.expires_at<=now() THEN 'expired' ELSE l.status END AS status,
      l.expires_at,l.max_devices,l.created_at,l.updated_at,l.display_name,l.machine_fingerprint,l.activated_at,l.replaced_by_license_id,
      CASE WHEN char_length(l.license_key)>18 THEN left(l.license_key,18)||'…' ELSE l.license_key END AS license_key_prefix,
      u.username,u.email,(SELECT count(*) FROM license_devices d WHERE d.license_id=l.id) AS device_count
      FROM licenses l LEFT JOIN users u ON u.id=l.user_id ORDER BY l.created_at DESC LIMIT $1`, [limit]);
    return { items: result.rows.map((row) => ({ ...row, device_count: Number(row.device_count) })) };
  });
  app.get('/api/admin/licenses/capabilities', { preHandler: app.requireAdmin }, async () => ({
    canSign: licenseAuthority.canSign,
    publicKeyFingerprint: licenseAuthority.publicKeyFingerprint,
    storage: 'postgresql'
  }));
  app.get('/api/admin/licenses/device/:machine', { preHandler: app.requireAdmin }, async (req) => {
    const machine = validateMachineFingerprint(req.params.machine);
    const result = await query(`SELECT l.id,l.license_key,l.user_id,
      CASE WHEN l.status='active' AND l.expires_at IS NOT NULL AND l.expires_at<=now() THEN 'expired' ELSE l.status END AS status,
      l.expires_at,l.max_devices,l.created_at,l.updated_at,l.display_name,l.machine_fingerprint,l.activated_at,l.replaced_by_license_id,
      u.username,u.email,(SELECT count(*) FROM license_devices d WHERE d.license_id=l.id) AS device_count
      FROM licenses l LEFT JOIN users u ON u.id=l.user_id
      WHERE l.machine_fingerprint=$1 ORDER BY l.created_at DESC`, [machine]);
    return {
      machine,
      items: result.rows.map(({ license_key: licenseKey, ...row }) => ({ ...row, licenseKey, device_count: Number(row.device_count) }))
    };
  });
  app.post('/api/admin/licenses/:id/revoke', { preHandler: app.requireAdmin }, async (req, reply) => {
    const licenseId = uuid(req.params.id, 'licenseId');
    const result = await withTransaction(async (tx) => {
      const updated = await tx("UPDATE licenses SET status='revoked',updated_at=now() WHERE id=$1 AND status<>'revoked' RETURNING id,status", [licenseId]);
      if (updated.rowCount) await audit(tx, req.user.sub, 'licenses.revoke', 'licenses', licenseId);
      return updated.rows[0] || null;
    });
    if (!result) return reply.code(404).send({ error: '授权不存在或已吊销' });
    return result;
  });
  app.get('/api/admin/audit', { preHandler: app.requireAdmin }, async (req) => {
    const limit = boundedInt(req.query?.limit, 100, 300);
    const result = await query(`SELECT a.id,a.action,a.entity_type,a.entity_id,a.metadata,a.created_at,u.username,u.email
      FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.created_at DESC LIMIT $1`, [limit]);
    return { items: result.rows };
  });
  app.get('/api/admin/telemetry', { preHandler: app.requireAdmin }, async (req) => {
    const days = boundedInt(req.query?.days, 30, 90);
    const [byEvent, byDay] = await Promise.all([
      query(`SELECT name,count(*) AS count,count(DISTINCT installation_hash) AS installations FROM telemetry_events WHERE received_at>now()-($1::int*interval '1 day') GROUP BY name ORDER BY count(*) DESC`, [days]),
      query(`SELECT date_trunc('day',received_at)::date AS day,count(*) AS count,count(DISTINCT installation_hash) AS installations FROM telemetry_events WHERE received_at>now()-($1::int*interval '1 day') GROUP BY 1 ORDER BY 1`, [days])
    ]);
    return { days, byEvent: byEvent.rows.map((row) => ({ ...row, count: Number(row.count), installations: Number(row.installations) })), byDay: byDay.rows.map((row) => ({ ...row, count: Number(row.count), installations: Number(row.installations) })) };
  });
  app.post('/api/admin/licenses', { preHandler: app.requireAdmin }, async (req, reply) => {
    const body = req.body || {}; const machine = body.machine ? validateMachineFingerprint(body.machine) : '';
    if (!machine && body.allowUnbound !== true) return reply.code(400).send({ error: '机器码必填；确需非绑定授权时显式传 allowUnbound=true' });
    const { exp, expiresAt } = expiryFromRequest(body);
    const name = String(body.name || '').trim();
    if (!name || name.length > 200) return reply.code(400).send({ error: 'name 必填且不能超过 200 字' });
    const userId = body.userId ? uuid(body.userId, 'userId') : null;
    const sub = String(body.sub || userId || `license-${crypto.randomUUID()}`).trim();
    const payload = { sub, name, exp, ver: 'shanman-ai-platform:1', ...(machine ? { machine } : {}) };
    const key = licenseAuthority.sign(payload); const maxDevices = machine ? 1 : Number(body.maxDevices || 1);
    if (!Number.isInteger(maxDevices) || maxDevices < 1 || maxDevices > 100) return reply.code(400).send({ error: 'maxDevices 必须是 1 到 100 的整数' });
    try {
      const result = await withTransaction(async (tx) => {
        const replaced = machine ? await tx(`UPDATE licenses SET status='revoked',updated_at=now()
          WHERE machine_fingerprint=$1 AND status='active' RETURNING id`, [machine]) : { rows: [] };
        const inserted = await tx(`INSERT INTO licenses
          (license_key,user_id,expires_at,max_devices,machine_fingerprint,display_name)
          VALUES($1,$2,$3,$4,$5,$6)
          RETURNING id,user_id,status,expires_at,max_devices,machine_fingerprint,display_name,activated_at,created_at,updated_at`,
          [key,userId,expiresAt,maxDevices,machine || null,name]);
        if (replaced.rows.length) {
          await tx('UPDATE licenses SET replaced_by_license_id=$1 WHERE id=ANY($2::uuid[])', [inserted.rows[0].id, replaced.rows.map((row) => row.id)]);
        }
        await audit(tx, req.user.sub, 'licenses.create', 'licenses', inserted.rows[0].id, {
          sub, name, machineBound: Boolean(machine), machineSuffix: machine ? machine.slice(-8) : null,
          replaced: replaced.rows.length, exp, publicKeyFingerprint: licenseAuthority.publicKeyFingerprint
        });
        return inserted.rows[0];
      });
      return reply.code(201).send({ ...result, licenseKey: key, payload });
    } catch (error) { throw mapPgError(error); }
  });
}
