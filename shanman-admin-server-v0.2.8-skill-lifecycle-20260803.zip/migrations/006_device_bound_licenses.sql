ALTER TABLE licenses ADD COLUMN IF NOT EXISTS machine_fingerprint TEXT;
ALTER TABLE licenses ADD COLUMN IF NOT EXISTS display_name TEXT NOT NULL DEFAULT '';
ALTER TABLE licenses ADD COLUMN IF NOT EXISTS activated_at TIMESTAMPTZ;
ALTER TABLE licenses ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ NOT NULL DEFAULT now();
ALTER TABLE licenses ADD COLUMN IF NOT EXISTS replaced_by_license_id UUID REFERENCES licenses(id) ON DELETE SET NULL;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='licenses_machine_fingerprint_format') THEN
    ALTER TABLE licenses ADD CONSTRAINT licenses_machine_fingerprint_format
      CHECK(machine_fingerprint IS NULL OR machine_fingerprint ~ '^[a-f0-9]{32}$');
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS licenses_machine_fingerprint_idx
  ON licenses(machine_fingerprint, created_at DESC)
  WHERE machine_fingerprint IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS licenses_one_active_key_per_machine_idx
  ON licenses(machine_fingerprint)
  WHERE machine_fingerprint IS NOT NULL AND status='active';

