import fs from 'node:fs';
import fsp from 'node:fs/promises';
import { config } from '../config.js';
import { query } from '../db.js';
import { publicVersion, sha256 } from '../marketplace-utils.js';
import { resolveStoragePath } from '../package-upload.js';
import { avatarRelativePath, detectAvatarImage, validateAvatarFilename } from '../avatar-storage.js';

const PRODUCTS = {
  agents: { table: 'agent_products', versions: 'agent_product_versions', label: '智能体' },
  skills: { table: 'skill_products', versions: 'skill_product_versions', label: '技能' }
};
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function id(value) {
  const result = String(value || '').trim();
  if (!UUID_RE.test(result)) throw Object.assign(new TypeError('资源 id 无效'), { statusCode: 400 });
  return result;
}

function publicProduct(row) {
  return {
    id: row.id, slug: row.slug, name: row.name, summary: row.summary, description: row.description,
    ...(row.icon !== undefined ? { icon: row.icon } : {}),
    ...(row.category !== undefined ? { category: row.category || '通用' } : {}),
    ...(row.avatar !== undefined ? { avatar: row.avatar || '' } : {}),
    status: row.status, updatedAt: row.updated_at, publishedAt: row.published_at,
    latestVersion: publicVersion(row.latest_version, { includeManifest: false })
  };
}

async function listProducts(spec) {
  const result = await query(`SELECT p.*, (SELECT row_to_json(v) FROM ${spec.versions} v WHERE v.product_id=p.id ORDER BY v.created_at DESC LIMIT 1) latest_version FROM ${spec.table} p WHERE p.status='published' AND EXISTS(SELECT 1 FROM ${spec.versions} ready WHERE ready.product_id=p.id) ORDER BY p.updated_at DESC`);
  return { items: result.rows.map(publicProduct) };
}

async function productDetail(spec, productId) {
  const product = await query(`SELECT p.*, (SELECT row_to_json(v) FROM ${spec.versions} v WHERE v.product_id=p.id ORDER BY v.created_at DESC LIMIT 1) latest_version FROM ${spec.table} p WHERE p.id=$1 AND p.status='published'`, [productId]);
  if (!product.rowCount) return null;
  const versions = await query(`SELECT * FROM ${spec.versions} WHERE product_id=$1 ORDER BY created_at DESC`, [productId]);
  return { ...publicProduct(product.rows[0]), versions: versions.rows.map((row) => publicVersion(row, { includeManifest: false })) };
}

async function versionDetail(spec, productId, version) {
  const result = await query(`SELECT v.* FROM ${spec.versions} v JOIN ${spec.table} p ON p.id=v.product_id WHERE p.id=$1 AND p.status='published' AND v.version=$2`, [productId, version]);
  return result.rows[0] ? publicVersion(result.rows[0]) : null;
}

async function packageDetail(spec, productId, version) {
  const result = await query(`SELECT v.package_path,v.package_sha256,v.package_size,v.package_format,p.slug
    FROM ${spec.versions} v JOIN ${spec.table} p ON p.id=v.product_id
    WHERE p.id=$1 AND p.status='published' AND v.version=$2`, [productId, version]);
  return result.rows[0] || null;
}

async function skillContentDetail(productId, version) {
  const result = await query(`SELECT v.content_path,v.manifest_sha256,p.slug
    FROM skill_product_versions v JOIN skill_products p ON p.id=v.product_id
    WHERE p.id=$1 AND p.status='published' AND v.version=$2`, [productId, version]);
  return result.rows[0] || null;
}

export default async function marketplaceRoutes(app) {
  app.get('/api/marketplace/assets/avatars/:filename', async (request, reply) => {
    let filename;
    try { filename = validateAvatarFilename(request.params.filename); }
    catch { return reply.code(404).send({ error: '头像不存在' }); }
    const absolute = resolveStoragePath(config.storagePath, avatarRelativePath(filename));
    let stat;
    try { stat = await fsp.stat(absolute); } catch { return reply.code(404).send({ error: '头像不存在' }); }
    if (!stat.isFile() || stat.size > 3 * 1024 * 1024) return reply.code(404).send({ error: '头像不存在' });
    const header = Buffer.alloc(12);
    const handle = await fsp.open(absolute, 'r');
    try { await handle.read(header, 0, header.length, 0); } finally { await handle.close(); }
    const format = detectAvatarImage(header);
    if (!format) return reply.code(415).send({ error: '头像格式无效' });
    reply.type(format.contentType);
    reply.header('cache-control', 'public, max-age=31536000, immutable');
    return reply.send(fs.createReadStream(absolute));
  });

  for (const [type, spec] of Object.entries(PRODUCTS)) {
    app.get(`/api/marketplace/${type}`, async (request, reply) => {
      reply.header('cache-control', 'no-store, max-age=0');
      return listProducts(spec);
    });
    app.get(`/api/marketplace/${type}/:id`, async (request, reply) => {
      const product = await productDetail(spec, id(request.params.id));
      if (!product) return reply.code(404).send({ error: `${spec.label}不存在` });
      return product;
    });
    app.get(`/api/marketplace/${type}/:id/versions/:version`, async (request, reply) => {
      const version = String(request.params.version || '').trim();
      if (!/^\d+\.\d+\.\d+$/.test(version)) return reply.code(400).send({ error: '版本号无效' });
      const item = await versionDetail(spec, id(request.params.id), version);
      if (!item) return reply.code(404).send({ error: '版本不存在' });
      const etag = `"sha256-${item.manifestSha256}"`;
      reply.header('etag', etag);
      reply.header('cache-control', 'public, max-age=300');
      if (request.headers['if-none-match'] === etag) return reply.code(304).send();
      return {
        ...item,
        ...(item.packageSha256 ? { packageUrl: `/api/marketplace/${type}/${request.params.id}/versions/${version}/package` } : {}),
        ...(type === 'skills' ? { contentUrl: `/api/marketplace/skills/${request.params.id}/versions/${version}/content` } : {})
      };
    });
    app.get(`/api/marketplace/${type}/:id/versions/:version/package`, async (request, reply) => {
      const version = String(request.params.version || '').trim();
      if (!/^\d+\.\d+\.\d+$/.test(version)) return reply.code(400).send({ error: '版本号无效' });
      const item = await packageDetail(spec, id(request.params.id), version);
      if (!item?.package_path || !item.package_sha256) return reply.code(404).send({ error: '该版本没有可下载的安装包' });
      const absolute = resolveStoragePath(config.storagePath, item.package_path);
      let stat;
      try { stat = await fsp.stat(absolute); } catch { return reply.code(404).send({ error: '安装包文件不存在' }); }
      if (!stat.isFile() || stat.size !== Number(item.package_size)) return reply.code(409).send({ error: '安装包文件校验失败' });
      const extension = item.package_format === 'zip' ? 'zip' : 'json';
      reply.header('etag', `"sha256-${item.package_sha256}"`);
      reply.header('cache-control', 'public, max-age=300');
      reply.header('content-disposition', `attachment; filename="${item.slug}-${version}.${extension}"`);
      reply.type(extension === 'zip' ? 'application/zip' : 'application/json; charset=utf-8');
      if (request.headers['if-none-match'] === `"sha256-${item.package_sha256}"`) return reply.code(304).send();
      return reply.send(fs.createReadStream(absolute));
    });
  }

  app.get('/api/marketplace/skills/:id/versions/:version/content', async (request, reply) => {
    const version = String(request.params.version || '').trim();
    if (!/^\d+\.\d+\.\d+$/.test(version)) return reply.code(400).send({ error: '版本号无效' });
    const item = await skillContentDetail(id(request.params.id), version);
    if (!item?.content_path) return reply.code(404).send({ error: '该版本没有可安装的技能内容' });
    const absolute = resolveStoragePath(config.storagePath, item.content_path);
    let stat;
    try { stat = await fsp.stat(absolute); } catch { return reply.code(404).send({ error: '技能内容文件不存在' }); }
    if (!stat.isFile() || stat.size > 2 * 1024 * 1024) return reply.code(409).send({ error: '技能内容文件校验失败' });
    reply.header('etag', `"sha256-${item.manifest_sha256}"`);
    reply.header('cache-control', 'public, max-age=300');
    reply.type('text/markdown; charset=utf-8');
    if (request.headers['if-none-match'] === `"sha256-${item.manifest_sha256}"`) return reply.code(304).send();
    return reply.send(fs.createReadStream(absolute));
  });

  app.get('/api/marketplace/updates', async (request, reply) => {
    const load = async (spec) => {
      const result = await query(`SELECT p.id,p.slug,p.status,p.updated_at,p.deleted_at,(SELECT row_to_json(v) FROM ${spec.versions} v WHERE v.product_id=p.id ORDER BY v.created_at DESC LIMIT 1) latest_version FROM ${spec.table} p ORDER BY p.updated_at DESC`);
      return result.rows.map((row) => ({
        id: row.id, slug: row.slug, status: row.status, updatedAt: row.updated_at, deletedAt: row.deleted_at,
        latestVersion: publicVersion(row.latest_version, { includeManifest: false })
      }));
    };
    const [agents, skills] = await Promise.all([load(PRODUCTS.agents), load(PRODUCTS.skills)]);
    const digestSource = JSON.stringify({ agents, skills });
    const etag = `W/"sha256-${sha256(digestSource)}"`;
    reply.header('etag', etag); reply.header('cache-control', 'public, max-age=60');
    if (request.headers['if-none-match'] === etag) return reply.code(304).send();
    return { agents, skills, checkedAt: new Date().toISOString() };
  });
}
