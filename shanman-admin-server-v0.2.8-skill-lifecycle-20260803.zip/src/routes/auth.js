﻿import crypto from 'node:crypto';
import { query } from '../db.js';
import { hashPassword, normalizeEmail, normalizeUsername, validatePasswordChange, verifyPassword } from '../auth.js';

const publicUser = (u) => ({ id: u.id, username: u.username, email: u.email, role: u.role, createdAt: u.created_at });

export default async function authRoutes(app) {
  app.post('/api/auth/register', async (request, reply) => {
    const username = normalizeUsername(request.body?.username);
    const email = normalizeEmail(request.body?.email || `${username}@local.shanman`);
    const password = String(request.body?.password || '');
    const passwordConfirm = String(request.body?.passwordConfirm || '');
    if (!/^[A-Za-z0-9_]{3,20}$/.test(username)) return reply.code(400).send({ error: '用户名需为 3-20 位英文、数字或下划线，不能包含中文或空格' });
    if (password.length < 8) return reply.code(400).send({ error: '密码至少需要 8 位' });
    if (!passwordConfirm || password !== passwordConfirm) return reply.code(400).send({ error: '两次输入的密码不一致' });
    const existing = await query('SELECT id FROM users WHERE lower(username)=$1 OR lower(email)=$2', [username, email]);
    if (existing.rowCount) return reply.code(409).send({ error: '用户名或邮箱已存在，请换一个' });
    const result = await query('INSERT INTO users(username,email,password_hash) VALUES($1,$2,$3) RETURNING *', [username, email, await hashPassword(password)]);
    const user = result.rows[0];
    const token = app.jwt.sign({ sub: user.id, email: user.email, role: user.role }, { expiresIn: '30d' });
    return reply.code(201).send({ token, user: publicUser(user) });
  });

  app.post('/api/auth/login', async (request, reply) => {
    const identifier = String(request.body?.identifier || request.body?.email || request.body?.username || '').trim().toLowerCase();
    const password = String(request.body?.password || '');
    const result = await query('SELECT * FROM users WHERE lower(username)=$1 OR lower(email)=$1', [identifier]);
    const user = result.rows[0];
    if (!user || !(await verifyPassword(password, user.password_hash))) return reply.code(401).send({ error: '邮箱或密码错误' });
    const token = app.jwt.sign({ sub: user.id, email: user.email, role: user.role }, { expiresIn: '30d' });
    return { token, user: publicUser(user) };
  });

  app.post('/api/auth/logout', async () => ({ ok: true }));
  app.get('/api/me', { preHandler: app.requireAuth }, async (request, reply) => {
    const result = await query('SELECT * FROM users WHERE id=$1', [request.user.sub]);
    if (!result.rowCount) return reply.code(401).send({ error: '用户不存在' });
    return { user: publicUser(result.rows[0]) };
  });

  app.patch('/api/me/profile', { preHandler: app.requireAuth }, async (request, reply) => {
    const currentResult = await query('SELECT * FROM users WHERE id=$1', [request.user.sub]);
    if (!currentResult.rowCount) return reply.code(401).send({ error: '用户不存在' });
    const current = currentResult.rows[0];
    const username = request.body?.username === undefined ? current.username : normalizeUsername(request.body.username);
    const requestedEmail = request.body?.email === undefined ? undefined : normalizeEmail(request.body.email);
    const email = requestedEmail || current.email;
    if (!/^[A-Za-z0-9_]{3,20}$/.test(username)) return reply.code(400).send({ error: '用户名需为 3-20 位英文、数字或下划线' });
    if (email.length > 254 || !email.includes('@')) return reply.code(400).send({ error: '邮箱格式无效' });
    const duplicate = await query('SELECT id FROM users WHERE id<>$1 AND (lower(username)=$2 OR lower(email)=$3)', [request.user.sub, username, email]);
    if (duplicate.rowCount) return reply.code(409).send({ error: '用户名或邮箱已被其他账户使用' });
    const result = await query('UPDATE users SET username=$1,email=$2 WHERE id=$3 RETURNING *', [username, email, request.user.sub]);
    return { user: publicUser(result.rows[0]) };
  });

  app.post('/api/me/password', { preHandler: app.requireAuth }, async (request, reply) => {
    let input;
    try { input = validatePasswordChange(request.body?.currentPassword, request.body?.newPassword, request.body?.newPasswordConfirm); }
    catch (error) { return reply.code(400).send({ error: error.message }); }
    const result = await query('SELECT * FROM users WHERE id=$1', [request.user.sub]);
    const user = result.rows[0];
    if (!user) return reply.code(401).send({ error: '用户不存在' });
    if (!(await verifyPassword(input.currentPassword, user.password_hash))) return reply.code(401).send({ error: '当前密码错误' });
    await query('UPDATE users SET password_hash=$1 WHERE id=$2', [await hashPassword(input.newPassword), request.user.sub]);
    return { ok: true };
  });
}

