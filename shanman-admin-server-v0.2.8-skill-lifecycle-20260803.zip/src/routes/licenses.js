import { config } from '../config.js';
import { withTransaction } from '../db.js';
import { CLIENT_PUBLIC_KEY_PEM, createLicenseAuthority, validateMachineFingerprint } from '../license-signing.js';

const authority = createLicenseAuthority({ publicKeyPem: config.nodeEnv === 'test' ? config.licensePublicKeyPem || CLIENT_PUBLIC_KEY_PEM : CLIENT_PUBLIC_KEY_PEM });

export default async function licenseRoutes(app) {
  app.post('/api/licenses/activate', async (request, reply) => {
    const key = String(request.body?.licenseKey || '').trim();
    if (!key) return reply.code(400).send({ error: 'licenseKey 必填' });
    let fingerprint;
    try { fingerprint = validateMachineFingerprint(request.body?.deviceFingerprint); }
    catch (error) { return reply.code(error.statusCode || 400).send({ error: error.message }); }
    const verified = authority.verify(key);
    if (!verified.ok) return reply.code(403).send({ error: verified.reason });
    if (verified.payload.machine && verified.payload.machine !== fingerprint) return reply.code(403).send({ error: '该授权 Key 已绑定其他设备' });

    const result = await withTransaction(async (tx) => {
      const licenses = await tx("SELECT * FROM licenses WHERE license_key=$1 AND status='active' AND (expires_at IS NULL OR expires_at>now()) FOR UPDATE", [key]);
      if (!licenses.rowCount) return { error: '授权 Key 无效、已吊销或已过期' };
      const license = licenses.rows[0];
      if (license.machine_fingerprint && license.machine_fingerprint !== fingerprint) return { error: '该授权 Key 已绑定其他设备' };
      const devices = await tx('SELECT * FROM license_devices WHERE license_id=$1 ORDER BY id FOR UPDATE', [license.id]);
      const found = devices.rows.find((device) => device.device_fingerprint === fingerprint);
      if (!found && devices.rowCount >= license.max_devices) return { error: '已达到设备数量上限' };
      if (found) await tx('UPDATE license_devices SET last_seen_at=now() WHERE id=$1', [found.id]);
      else await tx('INSERT INTO license_devices(license_id,device_fingerprint) VALUES($1,$2)', [license.id, fingerprint]);
      await tx('UPDATE licenses SET activated_at=COALESCE(activated_at,now()),updated_at=now() WHERE id=$1', [license.id]);
      return { license };
    });
    if (result.error) return reply.code(403).send({ error: result.error });
    return {
      valid: true,
      license: {
        id: result.license.id, expiresAt: result.license.expires_at, maxDevices: result.license.max_devices,
        subject: verified.payload.sub, name: verified.payload.name, machineBound: Boolean(verified.payload.machine)
      }
    };
  });
}
