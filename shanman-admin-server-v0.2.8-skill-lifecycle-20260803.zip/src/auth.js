﻿import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
import { query } from './db.js';

export const normalizeEmail = (email) => String(email || '').trim().toLowerCase();
export const normalizeUsername = (username) => String(username || '').trim().toLowerCase();
export const hashPassword = (password) => bcrypt.hash(password, 12);
export const verifyPassword = (password, hash) => bcrypt.compare(password, hash);
export const hashToken = (token) => crypto.createHash('sha256').update(token).digest('hex');

export function validatePasswordChange(currentPassword, newPassword, newPasswordConfirm) {
  const current = String(currentPassword || '');
  const next = String(newPassword || '');
  const confirm = String(newPasswordConfirm || '');
  if (!current) throw new TypeError('请输入当前密码');
  if (next.length < 8) throw new TypeError('新密码至少需要 8 位');
  if (next.length > 200) throw new TypeError('新密码过长');
  if (next !== confirm) throw new TypeError('两次输入的新密码不一致');
  if (next === current) throw new TypeError('新密码不能与当前密码相同');
  return { currentPassword: current, newPassword: next };
}

export async function ensureAdmin(config, queryFn = query) {
  if (!config.adminEmail || !config.adminPassword) return;
  const username = normalizeUsername(config.adminUsername || 'admin') || 'admin';
  const hash = await hashPassword(config.adminPassword);
  await queryFn(`INSERT INTO users(username,email,password_hash,role) VALUES($1,$2,$3,'admin')
    ON CONFLICT(email) DO UPDATE SET username=EXCLUDED.username,password_hash=EXCLUDED.password_hash,role='admin'`, [username, config.adminEmail, hash]);
}


