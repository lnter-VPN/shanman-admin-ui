export function corsOriginPolicy(value) {
  const configured = String(value || '*').trim();
  const allowed = new Set(configured.split(',').map((item) => item.trim().replace(/\/$/, '')).filter(Boolean));
  return (origin, callback) => {
    const raw = String(origin || '').trim();
    const normalized = raw.replace(/\/+$/, '');
    const permitted = configured === '*' || !raw || raw === 'null' || raw.startsWith('file:') || allowed.has(normalized);
    callback(null, permitted);
  };
}
