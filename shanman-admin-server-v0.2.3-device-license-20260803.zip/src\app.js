import Fastify from 'fastify';
import cors from '@fastify/cors';
import jwt from '@fastify/jwt';
import multipart from '@fastify/multipart';
import { config } from './config.js';
import { migrate, pool } from './db.js';
import { ensureAdmin } from './auth.js';
import { MAX_PACKAGE_BYTES } from './package-upload.js';
import registerAdminStatic from './admin-static.js';
import { requireAuth, requireAdmin } from './middleware/auth.js';
import healthRoutes from './routes/health.js';
import authRoutes from './routes/auth.js';
import marketplaceRoutes from './routes/marketplace.js';
import licenseRoutes from './routes/licenses.js';
import adminRoutes from './routes/admin.js';
import telemetryRoutes from './routes/telemetry.js';
import { corsOriginPolicy } from './cors-origin.js';

const app = Fastify({ logger: true, bodyLimit: 4 * 1024 * 1024 });
await app.register(cors, { origin: corsOriginPolicy(config.webOrigin) });
await app.register(jwt, { secret: config.jwtSecret });
await app.register(multipart, {
  limits: { fileSize: MAX_PACKAGE_BYTES, files: 1, fields: 8, parts: 9 },
  throwFileSizeLimit: true
});
app.decorate('requireAuth', requireAuth); app.decorate('requireAdmin', requireAdmin);
await migrate(); await ensureAdmin(config);
await registerAdminStatic(app, { root: config.adminStaticRoot });
await app.register(healthRoutes); await app.register(authRoutes); await app.register(marketplaceRoutes); await app.register(licenseRoutes); await app.register(adminRoutes); await app.register(telemetryRoutes);
app.setErrorHandler((error, request, reply) => {
  const statusCode = Number(error.statusCode || (error.code === 'FST_REQ_FILE_TOO_LARGE' ? 413 : 500));
  if (statusCode >= 500) request.log.error(error); else request.log.warn({ code: error.code, message: error.message }, '请求被拒绝');
  const message = statusCode === 413 ? '上传包不能超过 10MB' : statusCode < 500 ? error.message : '服务器内部错误';
  reply.code(statusCode).send({ error: message });
});
const close = async () => { await app.close(); await pool.end(); process.exit(0); };
process.on('SIGTERM', close); process.on('SIGINT', close);
await app.listen({ host: '0.0.0.0', port: config.port });
